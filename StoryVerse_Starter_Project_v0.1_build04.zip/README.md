# StoryVerse — Build 04

Flutter source project for a cinematic reading and writing app.

## Android cloud build
The source archive contains the Flutter app code. The GitHub Actions workflow generates Android platform files before compiling:

```bash
flutter create --platforms=android --project-name storyverse .
flutter pub get
flutter build apk --debug
```

## Author Studio
The Create tab supports persistent projects, project workspaces, chapter creation and manuscript editing. Text autosaves after a short pause and when leaving the editor. Chapter data and queries are scoped to the active project.

See `BUILD_NOTES.md` and `STORYVERSE_CONTINUITY.md` for implementation status and next steps. Sample reader books remain placeholders. Book import, reading, online discovery, AI, character management and worldbuilding are not yet implemented.

# StoryVerse — Build 03

Flutter starter for a cinematic reading and writing app.

## Run
Requires Flutter and Android toolchain. From the project folder:
```bash
flutter pub get
flutter run
```

## Author Studio
The Create tab now supports persistent projects, project workspaces, chapter creation and manuscript editing. Text autosaves after a short pause and when leaving the editor. Chapter queries are scoped by the active project ID.

See `BUILD_NOTES.md` and `STORYVERSE_CONTINUITY.md` for implemented status and next steps. Sample reader books remain placeholders; book import, reading, online discovery, AI, character management and worldbuilding are not yet implemented.

# StoryVerse Continuity Record — Build 03

Read this file and BUILD_NOTES.md before continuing.

## Product north star
Premium cinematic mobile app combining a local-first reading library/reader and structured authoring studio. Android first; core features should work without paid AI or backend.

## UX
Main tabs: Home, Library, Discover, Create, Profile. Distinct Library, immersive Reader and organized Author Studio environments. Dark and intentionally designed Light themes.

## Build history
- Build 01: Flutter Material 3 shell, themes and navigation.
- Build 02: richer foundation screens; import, project creation and online discovery were placeholders.
- Build 03: SQLite persistence foundation, project creation/list, project workspace, chapter creation/editor, autosave and project-scoped chapter search.

## Architecture
Flutter UI; SQLite via sqflite in app documents directory; UUID primary keys; repository layer; every project-owned record and query must be scoped by project_id. AI must remain optional and replaceable.

## Tables
projects(id, title, premise, created_at, updated_at)
chapters(id, project_id, title, content, position, updated_at)
characters(id, project_id, name, role, description, updated_at)
notes(id, project_id, title, content, updated_at)

## Next milestones
1. Run flutter pub get, flutter analyze, Android build and device tests.
2. Improve search to display matching chapters/snippets and open selected results.
3. Implement character CRUD with strict project isolation.
4. Implement project notes CRUD.
5. Add chapter rename/reorder/delete and project delete UI.
6. Add worldbuilding and plot/timeline modules.
7. Build local book import and reading engine.

## Release honesty
Do not claim compilation or device testing unless actually performed. Build 03 has not been compiled in this environment.

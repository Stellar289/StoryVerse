import 'package:flutter/material.dart';
import 'create/author_studio.dart';

class ScreenShell extends StatelessWidget {
  final String eyebrow;
  final String title;
  final String subtitle;
  final Widget? child;

  const ScreenShell({
    super.key,
    required this.eyebrow,
    required this.title,
    required this.subtitle,
    this.child,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Padding(
      padding: const EdgeInsets.fromLTRB(20, 22, 20, 12),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(eyebrow.toUpperCase(),
              style: theme.textTheme.labelMedium?.copyWith(
                color: theme.colorScheme.primary,
                letterSpacing: 1.7,
                fontWeight: FontWeight.w700,
              )),
          const SizedBox(height: 8),
          Text(title,
              style: theme.textTheme.headlineMedium?.copyWith(
                fontWeight: FontWeight.w800,
                letterSpacing: -0.8,
              )),
          const SizedBox(height: 7),
          Text(subtitle, style: theme.textTheme.bodyMedium?.copyWith(
            color: theme.colorScheme.onSurfaceVariant,
          )),
          const SizedBox(height: 24),
          if (child != null) Expanded(child: child!),
        ],
      ),
    );
  }
}

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return ScreenShell(
      eyebrow: 'StoryVerse • Your literary world',
      title: 'Stories are waiting.',
      subtitle: 'A little reading. A little creating. A world of possibility.',
      child: ListView(
        padding: const EdgeInsets.only(bottom: 20),
        children: [
          _ContinueReadingCard(
            title: 'The Midnight Library',
            author: 'Matt Haig',
            chapter: 'Chapter 4 · The Other Life',
            progress: 0.38,
          ),
          const SizedBox(height: 28),
          _SectionHeading(
            title: 'Your creative desk',
            action: 'Open studio',
            onTap: () {},
          ),
          const SizedBox(height: 12),
          _WritingProjectCard(
            title: 'Attack on Our School',
            detail: 'Last worked on · Chapter 2',
            progress: 0.24,
          ),
          const SizedBox(height: 28),
          _SectionHeading(title: 'Explore your library', action: 'See all', onTap: () {}),
          const SizedBox(height: 12),
          SizedBox(
            height: 186,
            child: ListView(
              scrollDirection: Axis.horizontal,
              children: const [
                _BookTile(title: 'The Silent Patient', author: 'Alex Michaelides', colors: [Color(0xFF263B4A), Color(0xFF101A25)], symbol: 'S'),
                _BookTile(title: 'Dune', author: 'Frank Herbert', colors: [Color(0xFFB66B36), Color(0xFF38241E)], symbol: 'D'),
                _BookTile(title: 'Pride & Prejudice', author: 'Jane Austen', colors: [Color(0xFF66735C), Color(0xFF26372F)], symbol: 'P'),
              ],
            ),
          ),
          const SizedBox(height: 28),
          Container(
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              color: theme.colorScheme.surfaceContainerHighest.withValues(alpha: 0.55),
              borderRadius: BorderRadius.circular(24),
              border: Border.all(color: theme.colorScheme.outlineVariant.withValues(alpha: 0.45)),
            ),
            child: Row(
              children: [
                Container(
                  width: 46, height: 46,
                  decoration: BoxDecoration(
                    color: theme.colorScheme.primary.withValues(alpha: 0.13),
                    borderRadius: BorderRadius.circular(15),
                  ),
                  child: Icon(Icons.auto_awesome, color: theme.colorScheme.primary),
                ),
                const SizedBox(width: 14),
                const Expanded(
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text('A space for every story', style: TextStyle(fontWeight: FontWeight.w700)),
                    SizedBox(height: 4),
                    Text('Your reading and writing worlds, together.', style: TextStyle(fontSize: 12)),
                  ]),
                ),
                Icon(Icons.arrow_forward_ios_rounded, size: 15, color: theme.colorScheme.onSurfaceVariant),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class LibraryScreen extends StatefulWidget {
  const LibraryScreen({super.key});

  @override
  State<LibraryScreen> createState() => _LibraryScreenState();
}

class _LibraryScreenState extends State<LibraryScreen> {
  String _filter = 'All';
  final _searchController = TextEditingController();

  final _books = const [
    _BookData('The Midnight Library', 'Matt Haig', 'Novel', [Color(0xFF263D56), Color(0xFF111C2A)], 'M'),
    _BookData('The Silent Patient', 'Alex Michaelides', 'Thriller', [Color(0xFF40515A), Color(0xFF18232A)], 'S'),
    _BookData('Dune', 'Frank Herbert', 'Science fiction', [Color(0xFFB66B36), Color(0xFF38241E)], 'D'),
    _BookData('Pride & Prejudice', 'Jane Austen', 'Classic', [Color(0xFF66735C), Color(0xFF26372F)], 'P'),
  ];

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final filtered = _books.where((book) {
      final matchesFilter = _filter == 'All' || book.category == _filter;
      final q = _searchController.text.toLowerCase();
      final matchesSearch = book.title.toLowerCase().contains(q) || book.author.toLowerCase().contains(q);
      return matchesFilter && matchesSearch;
    }).toList();

    return ScreenShell(
      eyebrow: 'Your collection',
      title: 'The Library',
      subtitle: 'A home for the worlds you love.',
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          TextField(
            controller: _searchController,
            onChanged: (_) => setState(() {}),
            decoration: InputDecoration(
              hintText: 'Search your library',
              prefixIcon: const Icon(Icons.search_rounded),
              filled: true,
              fillColor: theme.colorScheme.surfaceContainerHighest.withValues(alpha: 0.55),
              border: OutlineInputBorder(borderRadius: BorderRadius.circular(18), borderSide: BorderSide.none),
            ),
          ),
          const SizedBox(height: 16),
          SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            child: Row(children: [
              for (final item in ['All', 'Novel', 'Thriller', 'Science fiction', 'Classic'])
                Padding(
                  padding: const EdgeInsets.only(right: 8),
                  child: ChoiceChip(
                    label: Text(item),
                    selected: _filter == item,
                    onSelected: (_) => setState(() => _filter = item),
                  ),
                ),
            ]),
          ),
          const SizedBox(height: 18),
          Row(
            children: [
              Text('${filtered.length} books', style: theme.textTheme.titleSmall?.copyWith(fontWeight: FontWeight.w700)),
              const Spacer(),
              TextButton.icon(onPressed: () {}, icon: const Icon(Icons.add_rounded), label: const Text('Import')),
            ],
          ),
          const SizedBox(height: 8),
          Expanded(
            child: filtered.isEmpty
                ? const Center(child: Text('No matching books yet.'))
                : GridView.builder(
                    itemCount: filtered.length,
                    gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                      crossAxisCount: 2,
                      crossAxisSpacing: 14,
                      mainAxisSpacing: 18,
                      childAspectRatio: 0.64,
                    ),
                    itemBuilder: (context, index) {
                      final book = filtered[index];
                      return Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Expanded(child: _CoverArt(title: book.title, colors: book.colors, symbol: book.symbol)),
                          const SizedBox(height: 9),
                          Text(book.title, maxLines: 1, overflow: TextOverflow.ellipsis,
                            style: const TextStyle(fontWeight: FontWeight.w700)),
                          const SizedBox(height: 3),
                          Text(book.author, maxLines: 1, overflow: TextOverflow.ellipsis,
                            style: theme.textTheme.bodySmall?.copyWith(color: theme.colorScheme.onSurfaceVariant)),
                        ],
                      );
                    },
                  ),
          ),
        ],
      ),
    );
  }
}

class DiscoverScreen extends StatelessWidget {
  const DiscoverScreen({super.key});
  @override
  Widget build(BuildContext context) => ScreenShell(
    eyebrow: 'Explore',
    title: 'Discover stories',
    subtitle: 'Find public-domain books, free legal works and places to get the stories you love.',
    child: ListView(children: const [
      _DiscoverCategory(icon: Icons.auto_stories, title: 'Classics', subtitle: 'Timeless works in the public domain'),
      _DiscoverCategory(icon: Icons.menu_book, title: 'Novels & novellas', subtitle: 'Find your next long read'),
      _DiscoverCategory(icon: Icons.draw, title: 'Comics & graphic stories', subtitle: 'Visual storytelling from trusted sources'),
      _DiscoverCategory(icon: Icons.travel_explore, title: 'Open libraries', subtitle: 'Explore legitimate digital collections'),
    ]),
  );
}

class ProfileScreen extends StatelessWidget {
  final ThemeMode themeMode;
  final ValueChanged<ThemeMode> onThemeChanged;

  const ProfileScreen({super.key, required this.themeMode, required this.onThemeChanged});

  @override
  Widget build(BuildContext context) {
    return ScreenShell(
      eyebrow: 'You',
      title: 'Profile & settings',
      subtitle: 'Make StoryVerse feel like your own.',
      child: ListView(
        children: [
          const Text('Appearance', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
          const SizedBox(height: 12),
          SegmentedButton<ThemeMode>(
            segments: const [
              ButtonSegment(value: ThemeMode.light, label: Text('Light'), icon: Icon(Icons.light_mode_outlined)),
              ButtonSegment(value: ThemeMode.dark, label: Text('Dark'), icon: Icon(Icons.dark_mode_outlined)),
              ButtonSegment(value: ThemeMode.system, label: Text('System'), icon: Icon(Icons.phone_android_rounded)),
            ],
            selected: {themeMode},
            onSelectionChanged: (value) => onThemeChanged(value.first),
          ),
          const SizedBox(height: 24),
          const _DiscoverCategory(icon: Icons.bookmark_border, title: 'Saved items', subtitle: 'Your bookmarks, notes and passages'),
          const _DiscoverCategory(icon: Icons.translate, title: 'Vocabulary', subtitle: 'Words you have saved while reading'),
          const _DiscoverCategory(icon: Icons.storage_outlined, title: 'Storage & offline', subtitle: 'Manage books and local files'),
        ],
      ),
    );
  }
}

class _ContinueReadingCard extends StatelessWidget {
  final String title, author, chapter;
  final double progress;
  const _ContinueReadingCard({required this.title, required this.author, required this.chapter, required this.progress});

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Container(
      height: 226,
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(28),
        gradient: const LinearGradient(
          begin: Alignment.topLeft, end: Alignment.bottomRight,
          colors: [Color(0xFF283C55), Color(0xFF171B2A), Color(0xFF111116)],
        ),
        boxShadow: [BoxShadow(color: Colors.black.withValues(alpha: 0.16), blurRadius: 22, offset: const Offset(0, 10))],
      ),
      child: Row(children: [
        Expanded(
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Text('PICK UP WHERE YOU LEFT OFF', style: TextStyle(color: Color(0xFFC7B9F4), fontSize: 9, letterSpacing: 1.5, fontWeight: FontWeight.bold)),
            const Spacer(),
            Text(title, maxLines: 2, style: const TextStyle(color: Colors.white, fontSize: 22, fontWeight: FontWeight.w800)),
            const SizedBox(height: 4),
            Text(author, style: const TextStyle(color: Colors.white70, fontSize: 12)),
            const SizedBox(height: 12),
            Text(chapter, style: const TextStyle(color: Colors.white70, fontSize: 10)),
            const SizedBox(height: 8),
            ClipRRect(
              borderRadius: BorderRadius.circular(8),
              child: LinearProgressIndicator(value: progress, minHeight: 4, backgroundColor: Colors.white24, color: const Color(0xFFC7B9F4)),
            ),
          ]),
        ),
        const SizedBox(width: 18),
        Container(
          width: 104,
          height: 154,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(12),
            gradient: const LinearGradient(colors: [Color(0xFF7C789B), Color(0xFF24283C)], begin: Alignment.topLeft, end: Alignment.bottomRight),
            boxShadow: [BoxShadow(color: Colors.black.withValues(alpha: 0.3), blurRadius: 15, offset: const Offset(5, 8))],
          ),
          child: const Center(child: Icon(Icons.auto_stories_rounded, color: Colors.white70, size: 42)),
        ),
      ]),
    );
  }
}

class _WritingProjectCard extends StatelessWidget {
  final String title, detail;
  final double progress;
  const _WritingProjectCard({required this.title, required this.detail, required this.progress});

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: theme.colorScheme.surfaceContainerHighest.withValues(alpha: 0.55),
        borderRadius: BorderRadius.circular(22),
        border: Border.all(color: theme.colorScheme.outlineVariant.withValues(alpha: 0.4)),
      ),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          Container(width: 42, height: 42, decoration: BoxDecoration(color: theme.colorScheme.primary.withValues(alpha: 0.13), borderRadius: BorderRadius.circular(14)), child: Icon(Icons.edit_note_rounded, color: theme.colorScheme.primary)),
          const SizedBox(width: 12),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(title, style: const TextStyle(fontWeight: FontWeight.w700)),
            const SizedBox(height: 3),
            Text(detail, style: theme.textTheme.bodySmall),
          ])),
          const Icon(Icons.arrow_forward_ios_rounded, size: 14),
        ]),
        const SizedBox(height: 16),
        LinearProgressIndicator(value: progress, minHeight: 5, borderRadius: BorderRadius.circular(8)),
        const SizedBox(height: 6),
        Text('${(progress * 100).round()}% project progress', style: theme.textTheme.labelSmall),
      ]),
    );
  }
}

class _SectionHeading extends StatelessWidget {
  final String title, action;
  final VoidCallback onTap;
  const _SectionHeading({required this.title, required this.action, required this.onTap});
  @override
  Widget build(BuildContext context) => Row(children: [
    Expanded(child: Text(title, style: Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.w800))),
    TextButton(onPressed: onTap, child: Text(action)),
  ]);
}

class _BookTile extends StatelessWidget {
  final String title, author, symbol;
  final List<Color> colors;
  const _BookTile({required this.title, required this.author, required this.colors, required this.symbol});
  @override
  Widget build(BuildContext context) => SizedBox(
    width: 116,
    child: Padding(
      padding: const EdgeInsets.only(right: 14),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Expanded(child: _CoverArt(title: title, colors: colors, symbol: symbol)),
        const SizedBox(height: 7),
        Text(title, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 12)),
        Text(author, maxLines: 1, overflow: TextOverflow.ellipsis, style: Theme.of(context).textTheme.bodySmall),
      ]),
    ),
  );
}

class _CoverArt extends StatelessWidget {
  final String title, symbol;
  final List<Color> colors;
  const _CoverArt({required this.title, required this.colors, required this.symbol});
  @override
  Widget build(BuildContext context) => Container(
    width: double.infinity,
    decoration: BoxDecoration(
      borderRadius: BorderRadius.circular(16),
      gradient: LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight, colors: colors),
      boxShadow: [BoxShadow(color: colors.last.withValues(alpha: 0.22), blurRadius: 12, offset: const Offset(0, 6))],
    ),
    child: Stack(children: [
      Positioned(right: -12, top: -18, child: Container(width: 90, height: 90, decoration: BoxDecoration(shape: BoxShape.circle, color: Colors.white.withValues(alpha: 0.07)))),
      Center(child: Text(symbol, style: const TextStyle(color: Colors.white, fontSize: 58, fontWeight: FontWeight.w200, fontFamily: 'serif'))),
      Positioned(left: 10, right: 10, bottom: 12, child: Text(title.toUpperCase(), maxLines: 2, textAlign: TextAlign.center, style: const TextStyle(color: Colors.white, fontSize: 9, letterSpacing: 1.2, fontWeight: FontWeight.w800))),
    ]),
  );
}

class _DiscoverCategory extends StatelessWidget {
  final IconData icon;
  final String title, subtitle;
  const _DiscoverCategory({required this.icon, required this.title, required this.subtitle});
  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: theme.colorScheme.surfaceContainerHighest.withValues(alpha: 0.45),
        borderRadius: BorderRadius.circular(18),
      ),
      child: Row(children: [
        Icon(icon, color: theme.colorScheme.primary, size: 24),
        const SizedBox(width: 14),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(title, style: const TextStyle(fontWeight: FontWeight.w700)),
          const SizedBox(height: 3),
          Text(subtitle, style: theme.textTheme.bodySmall),
        ])),
        const Icon(Icons.chevron_right_rounded),
      ]),
    );
  }
}

class _BookData {
  final String title, author, category, symbol;
  final List<Color> colors;
  const _BookData(this.title, this.author, this.category, this.colors, this.symbol);
}

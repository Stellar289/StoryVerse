import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';
import 'package:sqflite/sqflite.dart';

class StoryVerseDatabase {
  StoryVerseDatabase._();
  static final StoryVerseDatabase instance = StoryVerseDatabase._();
  Database? _database;

  Future<Database> get database async {
    if (_database != null) return _database!;
    final directory = await getApplicationDocumentsDirectory();
    final dbPath = p.join(directory.path, 'storyverse.db');
    _database = await openDatabase(dbPath, version: 1,
      onConfigure: (db) async { await db.execute('PRAGMA foreign_keys = ON'); },
      onCreate: (db, version) async {
        await db.execute('CREATE TABLE projects (id TEXT PRIMARY KEY, title TEXT NOT NULL, premise TEXT NOT NULL DEFAULT \'\', created_at TEXT NOT NULL, updated_at TEXT NOT NULL)');
        await db.execute('CREATE TABLE chapters (id TEXT PRIMARY KEY, project_id TEXT NOT NULL, title TEXT NOT NULL, content TEXT NOT NULL DEFAULT \'\', position INTEGER NOT NULL DEFAULT 0, updated_at TEXT NOT NULL, FOREIGN KEY(project_id) REFERENCES projects(id) ON DELETE CASCADE)');
        await db.execute('CREATE INDEX chapters_project_idx ON chapters(project_id)');
        await db.execute('CREATE TABLE characters (id TEXT PRIMARY KEY, project_id TEXT NOT NULL, name TEXT NOT NULL, role TEXT NOT NULL DEFAULT \'\', description TEXT NOT NULL DEFAULT \'\', updated_at TEXT NOT NULL, FOREIGN KEY(project_id) REFERENCES projects(id) ON DELETE CASCADE)');
        await db.execute('CREATE INDEX characters_project_idx ON characters(project_id)');
        await db.execute('CREATE TABLE notes (id TEXT PRIMARY KEY, project_id TEXT NOT NULL, title TEXT NOT NULL, content TEXT NOT NULL DEFAULT \'\', updated_at TEXT NOT NULL, FOREIGN KEY(project_id) REFERENCES projects(id) ON DELETE CASCADE)');
        await db.execute('CREATE INDEX notes_project_idx ON notes(project_id)');
      });
    return _database!;
  }
}

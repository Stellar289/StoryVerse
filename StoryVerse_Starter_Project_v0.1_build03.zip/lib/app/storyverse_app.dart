import 'package:flutter/material.dart';
import '../navigation/main_navigation.dart';
import 'theme/app_theme.dart';

class StoryVerseApp extends StatefulWidget {
  const StoryVerseApp({super.key});

  @override
  State<StoryVerseApp> createState() => _StoryVerseAppState();
}

class _StoryVerseAppState extends State<StoryVerseApp> {
  ThemeMode _themeMode = ThemeMode.system;

  void _setThemeMode(ThemeMode mode) {
    setState(() => _themeMode = mode);
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'StoryVerse',
      debugShowCheckedModeBanner: false,
      theme: StoryVerseTheme.light(),
      darkTheme: StoryVerseTheme.dark(),
      themeMode: _themeMode,
      home: MainNavigation(
        themeMode: _themeMode,
        onThemeChanged: _setThemeMode,
      ),
    );
  }
}

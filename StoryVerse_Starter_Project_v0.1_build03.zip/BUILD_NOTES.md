# StoryVerse 0.1 — Build 03

## Carried forward
- Flutter Material 3 shell, five-tab navigation and Light/Dark/System themes.
- Cinematic Home and Library presentation; demonstration book data remains placeholder content.
- Discover screen categories.

## Implemented in this source build
- SQLite database created in the app documents directory.
- Persistent story projects with UUID identifiers.
- Project-owned chapter, character and note tables with foreign keys and project indexes.
- Create project dialog (title + optional premise) and persistent project listing.
- New projects automatically receive Chapter 1.
- Project workspace with project-scoped chapter loading.
- Add chapter and edit manuscript screens.
- Debounced autosave while typing and save-on-editor-exit.
- Repository methods for project-scoped chapter search and word count.
- Project deletion repository method (no UI yet).

## Still planned / incomplete
- Character and notes CRUD screens (tables only).
- Worldbuilding, plot, timeline, scenes and research.
- Search result snippets and direct result navigation need refinement.
- Chapter rename/reorder/delete and project deletion UI.
- EPUB/PDF/TXT import and reading engine.
- Legal online discovery integrations.
- AI assistant and project canon retrieval.

## Dependencies added
- sqflite, path, path_provider, uuid

## Verification
The source archive was inspected and modified. Flutter compilation, `flutter pub get`, analyzer, APK generation and physical-device testing have NOT been run in this environment.

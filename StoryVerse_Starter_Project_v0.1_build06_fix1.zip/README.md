# StoryVerse — Build 05

A Flutter reading and writing app prototype with a cinematic literary interface.

## Build
The GitHub Actions workflow generates the Android platform scaffold, resolves Flutter dependencies and builds a debug APK:

```bash
flutter create --platforms=android --project-name storyverse .
flutter pub get
flutter build apk --debug
```

## Included in this milestone
Animated cover introduction, cinematic Home, curated book shelves, Library search/filter, Discover categories, book details, reader UI demonstration, theme selection, and the existing SQLite-based Author Studio foundation.

## Current limitations
Catalogue and reader text are sample/demo content. Real EPUB/PDF/TXT import, licensed/free online catalogue integrations, persistent reader progress, full reader annotations, AI assistance and complete authoring modules are not yet implemented. See BUILD_NOTES.md and STORYVERSE_CONTINUITY.md.

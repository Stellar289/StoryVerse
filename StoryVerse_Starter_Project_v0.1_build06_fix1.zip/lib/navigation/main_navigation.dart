import 'package:flutter/material.dart';
import '../features/foundation_screens.dart';
import '../features/create/author_studio.dart';
import '../features/books/working_book_screens.dart';

class MainNavigation extends StatefulWidget {
  final ThemeMode themeMode;
  final ValueChanged<ThemeMode> onThemeChanged;
  const MainNavigation({super.key, required this.themeMode, required this.onThemeChanged});
  @override
  State<MainNavigation> createState() => _MainNavigationState();
}

class _MainNavigationState extends State<MainNavigation> {
  int _index = 0;
  @override
  Widget build(BuildContext context) {
    final pages = <Widget>[
      const WorkingHomeScreen(), const WorkingLibraryScreen(), const WorkingDiscoverScreen(),
      const CreateScreen(), ProfileScreen(themeMode: widget.themeMode, onThemeChanged: widget.onThemeChanged),
    ];
    return Scaffold(
      body: IndexedStack(index: _index, children: pages),
      bottomNavigationBar: NavigationBar(
        height: 68,
        backgroundColor: Theme.of(context).colorScheme.surface.withValues(alpha: .97),
        indicatorColor: Theme.of(context).colorScheme.primary.withValues(alpha: .16),
        selectedIndex: _index,
        onDestinationSelected: (value) => setState(() => _index = value),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home_rounded), label: 'Home'),
          NavigationDestination(icon: Icon(Icons.local_library_outlined), selectedIcon: Icon(Icons.local_library_rounded), label: 'Library'),
          NavigationDestination(icon: Icon(Icons.explore_outlined), selectedIcon: Icon(Icons.explore_rounded), label: 'Discover'),
          NavigationDestination(icon: Icon(Icons.edit_outlined), selectedIcon: Icon(Icons.edit_rounded), label: 'Create'),
          NavigationDestination(icon: Icon(Icons.person_outline_rounded), selectedIcon: Icon(Icons.person_rounded), label: 'Profile'),
        ],
      ),
    );
  }
}

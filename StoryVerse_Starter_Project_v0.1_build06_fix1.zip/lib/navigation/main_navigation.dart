import 'package:flutter/material.dart';
import '../features/foundation_screens.dart';
import '../features/create/author_studio.dart';
import '../features/books/working_book_screens.dart';
import '../features/visual_experience.dart';

class MainNavigation extends StatefulWidget {
  final ThemeMode themeMode;
  final ValueChanged<ThemeMode> onThemeChanged;
  const MainNavigation({super.key,required this.themeMode,required this.onThemeChanged});
  @override State<MainNavigation> createState()=>_MainNavigationState();
}
class _MainNavigationState extends State<MainNavigation>{
 int _index=0;
 @override Widget build(BuildContext context){
  final pages=<Widget>[
   const WorkingHomeScreen(),const CinematicDiscoverScreen(),const WorkingLibraryScreen(),
   const CreateScreen(),PremiumProfileScreen(themeMode:widget.themeMode,onThemeChanged:widget.onThemeChanged)
  ];
  return Scaffold(body:IndexedStack(index:_index,children:pages),bottomNavigationBar:NavigationBar(
   height:72,backgroundColor:Theme.of(context).colorScheme.surface,
   indicatorColor:Theme.of(context).colorScheme.primary.withValues(alpha:.15),
   selectedIndex:_index,onDestinationSelected:(v)=>setState(()=>_index=v),
   destinations:const [
    NavigationDestination(icon:Icon(Icons.home_outlined),selectedIcon:Icon(Icons.home_rounded),label:'Home'),
    NavigationDestination(icon:Icon(Icons.explore_outlined),selectedIcon:Icon(Icons.explore_rounded),label:'Discover'),
    NavigationDestination(icon:Icon(Icons.local_library_outlined),selectedIcon:Icon(Icons.local_library_rounded),label:'Library'),
    NavigationDestination(icon:Icon(Icons.edit_outlined),selectedIcon:Icon(Icons.edit_rounded),label:'Create'),
    NavigationDestination(icon:Icon(Icons.person_outline),selectedIcon:Icon(Icons.person),label:'Profile')
   ]));
 }
}

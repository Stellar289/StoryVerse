import 'package:flutter/material.dart';
import 'app/storyverse_app.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const StoryVerseApp());
}


import 'dart:async';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:file_picker/file_picker.dart';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';
import 'books/book_catalogue_service.dart';
import 'books/book_model.dart';
import 'books/working_book_screens.dart';

class StoryVerseLaunch extends StatefulWidget {
  final VoidCallback onFinished;
  final bool showWelcome;
  const StoryVerseLaunch({super.key, required this.onFinished, this.showWelcome = true});
  @override State<StoryVerseLaunch> createState() => _StoryVerseLaunchState();
}
class _StoryVerseLaunchState extends State<StoryVerseLaunch> with TickerProviderStateMixin {
  late final AnimationController _intro = AnimationController(vsync:this,duration:const Duration(milliseconds:2300))..forward();
  bool _welcome = false;
  @override void initState(){super.initState();_intro.addStatusListener((s){if(s==AnimationStatus.completed&&mounted){if(widget.showWelcome)setState(()=>_welcome=true);else widget.onFinished();}});}
  @override void dispose(){_intro.dispose();super.dispose();}
  @override Widget build(BuildContext context){
    const navy=Color(0xFF102B49), blue=Color(0xFF78D5F1), amber=Color(0xFFF4A653);
    return Scaffold(backgroundColor:const Color(0xFF08182A),body:AnimatedSwitcher(duration:const Duration(milliseconds:650),child:_welcome
      ? SafeArea(key:const ValueKey('welcome'),child:Padding(padding:const EdgeInsets.fromLTRB(26,18,26,24),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
        Align(alignment:Alignment.topRight,child:TextButton(onPressed:widget.onFinished,child:const Text('SKIP',style:TextStyle(color:Colors.white70,letterSpacing:1.4)))),
        const Spacer(),
        Expanded(flex:7,child:ClipRRect(borderRadius:BorderRadius.circular(28),child:Stack(fit:StackFit.expand,children:[
          const DecoratedBox(decoration:BoxDecoration(gradient:LinearGradient(begin:Alignment.topLeft,end:Alignment.bottomRight,colors:[Color(0xFF244C70),Color(0xFF0C1E33),Color(0xFF071321)]))),
          Positioned(right:-28,top:0,bottom:0,width:210,child:Transform.rotate(angle:-.12,child:const Icon(Icons.auto_stories_rounded,size:220,color:Color(0x3378D5F1)))),
          Positioned(left:20,right:20,bottom:25,child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
            const Text('A WORLD OF STORIES,\nWITHIN REACH.',style:TextStyle(color:Colors.white,fontSize:27,height:1.08,fontWeight:FontWeight.w900,letterSpacing:-.7)),
            const SizedBox(height:12),const Text('Read novels, explore comics and build stories of your own.',style:TextStyle(color:Color(0xFFD7E5EF),fontSize:14,height:1.4)),
            const SizedBox(height:20),Row(children:[_feature(Icons.menu_book,'Read'),const SizedBox(width:18),_feature(Icons.explore,'Discover'),const SizedBox(width:18),_feature(Icons.edit_note,'Create')])
          ]))
        ]))),
        const SizedBox(height:24),SizedBox(width:double.infinity,height:54,child:FilledButton(style:FilledButton.styleFrom(backgroundColor:blue,foregroundColor:navy,shape:RoundedRectangleBorder(borderRadius:BorderRadius.circular(16))),onPressed:widget.onFinished,child:const Text('Get started',style:TextStyle(fontWeight:FontWeight.w800,fontSize:16)))),
        const SizedBox(height:10),Center(child:TextButton(onPressed:widget.onFinished,child:const Text('Continue as guest',style:TextStyle(color:Colors.white70)))),
      ])))
      : AnimatedBuilder(animation:_intro,builder:(context,_) {final t=Curves.easeOutCubic.transform(_intro.value);return Stack(children:[
        const DecoratedBox(decoration:BoxDecoration(gradient:RadialGradient(center:Alignment(0,-.2),radius:1.1,colors:[Color(0xFF193B5B),Color(0xFF08182A)])),child:SizedBox.expand()),
        Center(child:SizedBox(width:320,height:390,child:Stack(alignment:Alignment.center,children:[
          for(int i=0;i<14;i++) _MosaicCover(index:i,t:t),
          Transform.scale(scale:.65+t*.35,child:Container(width:84,height:84,decoration:BoxDecoration(color:const Color(0xFF78D5F1),borderRadius:BorderRadius.circular(23),boxShadow:[BoxShadow(color:const Color(0xFF78D5F1).withOpacity(.22),blurRadius:28)]),child:const Icon(Icons.auto_stories_rounded,size:43,color:Color(0xFF102B49))))
        ]))),
        Positioned(bottom:70,left:0,right:0,child:Column(children:[Text('STORYVERSE',style:TextStyle(color:Colors.white.withOpacity(t),fontSize:23,fontWeight:FontWeight.w900,letterSpacing:5)),const SizedBox(height:9),Text('Every cover opens a universe.',style:TextStyle(color:Colors.white.withOpacity(t*.8),fontSize:13,letterSpacing:.5))]))
      ]);})
    ));
  }
  static Widget _feature(IconData icon,String label)=>Row(mainAxisSize:MainAxisSize.min,children:[Icon(icon,color:const Color(0xFF78D5F1),size:19),const SizedBox(width:5),Text(label,style:const TextStyle(color:Colors.white,fontSize:12,fontWeight:FontWeight.w600))]);
}

class _MosaicCover extends StatelessWidget {
  final int index;
  final double t;
  const _MosaicCover({required this.index, required this.t});

  @override
  Widget build(BuildContext context) {
    const palettes = [
      [Color(0xFF2C6484), Color(0xFF132C49)],
      [Color(0xFFB86F3B), Color(0xFF563C36)],
      [Color(0xFF557C83), Color(0xFF20394B)],
      [Color(0xFF8C6A45), Color(0xFF43372F)],
      [Color(0xFF4E7595), Color(0xFF182E4B)],
    ];
    const titles = ['THE\nJOURNEY', 'NEW\nWORLDS', 'AFTER\nDARK', 'WILD\nHEART', 'THE\nUNKNOWN'];
    final offset = Offset((index % 4 - 1.5) * 70 * (1 - t), ((index * 37) % 100 - 50) * 1.7 * (1 - t));
    final cover = Container(
      width: 88,
      height: 126,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(8),
        gradient: LinearGradient(colors: palettes[index % palettes.length]),
        boxShadow: [BoxShadow(color: Colors.black.withOpacity(.35), blurRadius: 15, offset: const Offset(4, 8))],
      ),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          const Padding(padding: EdgeInsets.only(top: 10), child: Icon(Icons.auto_stories, color: Colors.white70, size: 17)),
          Text(titles[index % titles.length], textAlign: TextAlign.center,
            style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w900, fontSize: 11, letterSpacing: .7)),
          Container(height: 3, width: 28, color: const Color(0xFF78D5F1)),
          const SizedBox(height: 5),
        ],
      ),
    );
    return Transform.translate(
      offset: offset,
      child: Transform.rotate(
        angle: (index % 5 - 2) * .09 * (1 - t),
        child: Transform.scale(
          scale: .8 + t * .2,
          child: Opacity(opacity: (.65 + t * .35).clamp(0.0, 1.0).toDouble(), child: cover),
        ),
      ),
    );
  }
}



class CinematicDiscoverScreen extends StatefulWidget {
  const CinematicDiscoverScreen({super.key});
  @override State<CinematicDiscoverScreen> createState() => _CinematicDiscoverScreenState();
}

class _CinematicDiscoverScreenState extends State<CinematicDiscoverScreen> {
  List<StoryBook> _books = [];
  bool _busy = true;
  String? _error;
  final _search = TextEditingController();
  int _active = 0;

  @override void initState() { super.initState(); _load(); }
  @override void dispose() { _search.dispose(); super.dispose(); }

  Future<void> _load([String q = '']) async {
    setState(() => _busy = true);
    try {
      var rows = await BookCatalogueService.instance.searchGoogle(q.isEmpty ? 'subject:fiction' : q);
      if (rows.isEmpty) rows = await BookCatalogueService.instance.searchPublicDomain(q);
      if (mounted) setState(() => _books = rows);
    } catch (_) {
      if (mounted) setState(() => _error = 'We could not reach the story catalogues. Your saved Library remains available offline.');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final c = Theme.of(context).colorScheme;
    final featured = _books.take(6).toList();
    return Scaffold(
      body: RefreshIndicator(
        onRefresh: () => _load(_search.text),
        child: CustomScrollView(slivers: [
          SliverToBoxAdapter(
            child: Padding(
              padding: const EdgeInsets.fromLTRB(20, 18, 20, 10),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Row(children: [
                  Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text('STORYVERSE', style: TextStyle(color: c.primary, fontSize: 11, fontWeight: FontWeight.w900, letterSpacing: 2.5)),
                    const SizedBox(height: 5),
                    const Text('Discover', style: TextStyle(fontSize: 30, fontWeight: FontWeight.w900, letterSpacing: -.8)),
                  ])),
                  IconButton(onPressed: () => _load(_search.text), icon: const Icon(Icons.refresh_rounded)),
                ]),
                const SizedBox(height: 14),
                TextField(
                  controller: _search,
                  onSubmitted: (value) => _load(value),
                  decoration: InputDecoration(
                    hintText: 'Search books, authors and worlds',
                    prefixIcon: const Icon(Icons.search),
                    filled: true,
                    fillColor: c.surfaceContainerHighest,
                    border: OutlineInputBorder(borderRadius: BorderRadius.circular(16), borderSide: BorderSide.none),
                  ),
                ),
                const SizedBox(height: 16),
                Row(children: [
                  _chip('For you', true),
                  const SizedBox(width: 8),
                  _chip('Trending', false),
                  const SizedBox(width: 8),
                  _chip('New releases', false),
                  const Spacer(),
                  TextButton(
                    onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const CinematicComicsScreen())),
                    child: const Text('Comics  ›'),
                  ),
                ]),
              ]),
            ),
          ),
          if (featured.isNotEmpty) SliverToBoxAdapter(child: _stackedCarousel(featured)),
          if (_busy) const SliverToBoxAdapter(child: Padding(padding: EdgeInsets.all(22), child: Center(child: CircularProgressIndicator()))),
          if (_error != null) SliverToBoxAdapter(child: Padding(padding: const EdgeInsets.all(20), child: Text(_error!, style: TextStyle(color: c.onSurfaceVariant)))),
          _shelf('Popular stories', _books.take(12).toList()),
          _shelf('Explore more worlds', _books.reversed.take(12).toList()),
          SliverToBoxAdapter(
            child: Padding(
              padding: const EdgeInsets.fromLTRB(20, 18, 20, 30),
              child: OutlinedButton.icon(
                onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const CinematicComicsScreen())),
                icon: const Icon(Icons.auto_awesome_mosaic),
                label: const Text('Explore Comics & Graphic Stories'),
              ),
            ),
          ),
        ]),
      ),
    );
  }


  void _moveCarousel(int direction, int count) {
    final next = (_active + direction).clamp(0, count - 1);
    if (next != _active) setState(() => _active = next);
  }

  Widget _stackedCarousel(List<StoryBook> books) {
    return LayoutBuilder(builder: (context, constraints) {
      final width = constraints.maxWidth;
      final previous = _active > 0 ? books[_active - 1] : null;
      final next = _active + 1 < books.length ? books[_active + 1] : null;
      return GestureDetector(
        onHorizontalDragEnd: (details) {
          final velocity = details.primaryVelocity ?? 0;
          if (velocity < -120) _moveCarousel(1, books.length);
          if (velocity > 120) _moveCarousel(-1, books.length);
        },
        child: SizedBox(
          height: 350,
          child: Stack(clipBehavior: Clip.hardEdge, children: [
            if (previous != null)
              Positioned(
                left: 8, top: 28, width: width * .70, height: 292,
                child: GestureDetector(
                  onTap: () => _moveCarousel(-1, books.length),
                  child: _peekCard(previous),
                ),
              ),
            if (next != null)
              Positioned(
                right: 8, top: 28, width: width * .70, height: 292,
                child: GestureDetector(
                  onTap: () => _moveCarousel(1, books.length),
                  child: _peekCard(next),
                ),
              ),
            Positioned(
              left: width * .09, right: width * .09, top: 0, height: 330,
              child: AnimatedSwitcher(
                duration: const Duration(milliseconds: 420),
                switchInCurve: Curves.easeOutCubic,
                switchOutCurve: Curves.easeInCubic,
                transitionBuilder: (child, animation) => FadeTransition(
                  opacity: animation,
                  child: ScaleTransition(scale: Tween<double>(begin: .94, end: 1).animate(animation), child: child),
                ),
                child: _FeaturedStoryCard(
                  key: ValueKey(books[_active].id),
                  book: books[_active],
                  rank: _active + 1,
                ),
              ),
            ),
            Positioned(
              bottom: 3, left: 0, right: 0,
              child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                for (int i = 0; i < books.length; i++)
                  AnimatedContainer(
                    duration: const Duration(milliseconds: 220),
                    margin: const EdgeInsets.symmetric(horizontal: 3),
                    width: i == _active ? 19 : 6,
                    height: 6,
                    decoration: BoxDecoration(
                      color: i == _active ? Theme.of(context).colorScheme.secondary : Theme.of(context).colorScheme.outlineVariant,
                      borderRadius: BorderRadius.circular(8),
                    ),
                  ),
              ]),
            ),
          ]),
        ),
      );
    });
  }

  Widget _peekCard(StoryBook book) {
    return ClipRRect(
      borderRadius: BorderRadius.circular(23),
      child: Stack(fit: StackFit.expand, children: [
        if (book.coverUrl.isNotEmpty)
          Image.network(book.coverUrl, fit: BoxFit.cover, errorBuilder: (_, __, ___) => const ColoredBox(color: Color(0xFF173B5B)))
        else
          const ColoredBox(color: Color(0xFF173B5B)),
        const DecoratedBox(decoration: BoxDecoration(gradient: LinearGradient(
          begin: Alignment.topCenter, end: Alignment.bottomCenter,
          colors: [Colors.transparent, Color(0xDD08182A)],
        ))),
        Positioned(left: 12, right: 12, bottom: 12, child: Text(
          book.title, maxLines: 2, overflow: TextOverflow.ellipsis,
          style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w800, fontSize: 11),
        )),
      ]),
    );
  }

  Widget _chip(String label, bool selected) => Container(
    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
    decoration: BoxDecoration(
      color: selected ? Theme.of(context).colorScheme.primary : Theme.of(context).colorScheme.surfaceContainerHighest,
      borderRadius: BorderRadius.circular(30),
    ),
    child: Text(label, style: TextStyle(
      color: selected ? Theme.of(context).colorScheme.onPrimary : Theme.of(context).colorScheme.onSurface,
      fontWeight: FontWeight.w700, fontSize: 11,
    )),
  );

  Widget _shelf(String title, List<StoryBook> books) => SliverToBoxAdapter(
    child: Padding(
      padding: const EdgeInsets.only(top: 12, bottom: 12),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 20),
          child: Row(children: [
            Expanded(child: Text(title, style: const TextStyle(fontSize: 19, fontWeight: FontWeight.w900))),
            Text('See all  ›', style: TextStyle(color: Theme.of(context).colorScheme.primary, fontSize: 12, fontWeight: FontWeight.bold)),
          ]),
        ),
        const SizedBox(height: 13),
        SizedBox(
          height: 188,
          child: ListView.separated(
            padding: const EdgeInsets.symmetric(horizontal: 20),
            scrollDirection: Axis.horizontal,
            itemCount: books.length,
            separatorBuilder: (_, __) => const SizedBox(width: 12),
            itemBuilder: (context, i) => SizedBox(
              width: 112,
              child: InkWell(
                onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => CatalogueBookDetail(book: books[i]))),
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Expanded(child: _cover(books[i].coverUrl, 112)),
                  const SizedBox(height: 6),
                  Text(books[i].title, maxLines: 2, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 11)),
                ]),
              ),
            ),
          ),
        ),
      ]),
    ),
  );
}

class _FeaturedStoryCard extends StatelessWidget{final StoryBook book;final int rank;const _FeaturedStoryCard({required this.book,required this.rank});
 @override Widget build(BuildContext context){final c=Theme.of(context).colorScheme;return Padding(padding:const EdgeInsets.symmetric(horizontal:8,vertical:8),child:ClipRRect(borderRadius:BorderRadius.circular(25),child:Stack(fit:StackFit.expand,children:[
 Container(color:c.surfaceContainerHighest),if(book.coverUrl.isNotEmpty)Image.network(book.coverUrl,fit:BoxFit.cover,errorBuilder:(_,__,___)=>_fallback(c)),
 DecoratedBox(decoration:BoxDecoration(gradient:LinearGradient(begin:Alignment.topCenter,end:Alignment.bottomCenter,colors:[Colors.black.withOpacity(.04),Colors.black.withOpacity(.22),Colors.black.withOpacity(.92)],stops:const [0,.45,1]))),
 Positioned(left:17,top:17,child:Container(padding:const EdgeInsets.symmetric(horizontal:12,vertical:7),decoration:BoxDecoration(color:const Color(0xFF102B49),borderRadius:BorderRadius.circular(20)),child:Text(rank==1?'FEATURED':'TRENDING  •  $rank',style:const TextStyle(color:Colors.white,fontSize:10,fontWeight:FontWeight.w900,letterSpacing:1)))),
 Positioned(left:18,right:18,bottom:19,child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text(book.title,maxLines:2,overflow:TextOverflow.ellipsis,style:const TextStyle(color:Colors.white,fontSize:24,fontWeight:FontWeight.w900,height:1.05)),const SizedBox(height:6),Text(book.author,style:const TextStyle(color:Colors.white70,fontSize:12)),const SizedBox(height:12),Row(children:[FilledButton.icon(style:FilledButton.styleFrom(backgroundColor:const Color(0xFFF4A653),foregroundColor:const Color(0xFF102B49)),onPressed:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>CatalogueBookDetail(book:book))),icon:const Icon(Icons.menu_book,size:17),label:const Text('Explore story')),const SizedBox(width:9),IconButton.filledTonal(onPressed:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>CatalogueBookDetail(book:book))),icon:const Icon(Icons.add))])]))
 ])));}
 Widget _fallback(ColorScheme c)=>DecoratedBox(decoration:BoxDecoration(gradient:LinearGradient(colors:[c.primary,c.surfaceContainerHighest],begin:Alignment.topLeft,end:Alignment.bottomRight)),child:const Center(child:Icon(Icons.auto_stories,size:80,color:Colors.white54)));
}
Widget _cover(String url,double width)=>ClipRRect(borderRadius:BorderRadius.circular(12),child:Container(width:width,color:const Color(0xFF193B5B),child:url.isEmpty?const Center(child:Icon(Icons.menu_book,color:Colors.white70)):Image.network(url,fit:BoxFit.cover,errorBuilder:(_,__,___)=>const Center(child:Icon(Icons.menu_book,color:Colors.white70)))));

class CinematicComicsScreen extends StatefulWidget{const CinematicComicsScreen({super.key});@override State<CinematicComicsScreen> createState()=>_CinematicComicsScreenState();}
class _CinematicComicsScreenState extends State<CinematicComicsScreen>{
 List<StoryBook> _items=[];bool _busy=true;String _genre='All';final _genres=['All','Manga','Superhero','Fantasy','Graphic novels'];
 @override void initState(){super.initState();_load();}
 Future<void> _load()async{setState(()=>_busy=true);try{final q=_genre=='All'?'comics graphic novels':_genre=='Manga'?'manga graphic novel': '$_genre comics graphic novels';final rows=await BookCatalogueService.instance.searchGoogle(q);if(mounted)setState(()=>_items=rows);}catch(_){if(mounted)setState(()=>_items=[]);}finally{if(mounted)setState(()=>_busy=false);}}
 @override Widget build(BuildContext context){final c=Theme.of(context).colorScheme;return Scaffold(appBar:AppBar(title:const Text('Comics Universe',style:TextStyle(fontWeight:FontWeight.w900)),leading:const BackButton()),body:RefreshIndicator(onRefresh:_load,child:CustomScrollView(slivers:[
 SliverToBoxAdapter(child:Padding(padding:const EdgeInsets.fromLTRB(18,8,18,12),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[ClipRRect(borderRadius:BorderRadius.circular(24),child:SizedBox(height:235,width:double.infinity,child:Stack(fit:StackFit.expand,children:[const DecoratedBox(decoration:BoxDecoration(gradient:LinearGradient(colors:[Color(0xFF17476C),Color(0xFF0B1A2B)],begin:Alignment.topLeft,end:Alignment.bottomRight))),const Positioned(right:-8,top:-18,child:Icon(Icons.auto_awesome,size:180,color:Color(0x3378D5F1))),Positioned(left:20,bottom:22,right:20,child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[const Text('PANEL BY PANEL.\nWORLD BY WORLD.',style:TextStyle(color:Colors.white,fontWeight:FontWeight.w900,fontSize:25,height:1.05)),const SizedBox(height:8),const Text('Manga, heroes and graphic storytelling.',style:TextStyle(color:Colors.white70)),const SizedBox(height:13),FilledButton(onPressed:()=>_load(),style:FilledButton.styleFrom(backgroundColor:const Color(0xFFF4A653),foregroundColor:const Color(0xFF102B49)),child:const Text('Explore collection'))]))]))),const SizedBox(height:18),SingleChildScrollView(scrollDirection:Axis.horizontal,child:Row(children:_genres.map((g)=>Padding(padding:const EdgeInsets.only(right:8),child:ChoiceChip(label:Text(g),selected:_genre==g,onSelected:(_){setState(()=>_genre=g);_load();}))).toList()))]))),
 if(_busy)const SliverToBoxAdapter(child:Padding(padding:EdgeInsets.all(30),child:Center(child:CircularProgressIndicator()))),
 if(!_busy&&_items.isEmpty)SliverToBoxAdapter(child:Padding(padding:const EdgeInsets.all(24),child:Text('No comics catalogue results are available right now. Try another category when you are online.',style:TextStyle(color:c.onSurfaceVariant)))),
 SliverPadding(padding:const EdgeInsets.fromLTRB(18,8,18,28),sliver:SliverGrid(delegate:SliverChildBuilderDelegate((context,i)=>InkWell(onTap:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>CatalogueBookDetail(book:_items[i]))),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Expanded(child:_cover(_items[i].coverUrl,double.infinity)),const SizedBox(height:7),Text(_items[i].title,maxLines:2,overflow:TextOverflow.ellipsis,style:const TextStyle(fontWeight:FontWeight.w800,fontSize:12)),Text(_items[i].author,maxLines:1,overflow:TextOverflow.ellipsis,style:TextStyle(color:c.onSurfaceVariant,fontSize:10))])),childCount:_items.length),gridDelegate:const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount:3,mainAxisSpacing:16,crossAxisSpacing:12,childAspectRatio:.55)))
 ])));}
}

class PremiumProfileScreen extends StatefulWidget{final ThemeMode themeMode;final ValueChanged<ThemeMode> onThemeChanged;const PremiumProfileScreen({super.key,required this.themeMode,required this.onThemeChanged});@override State<PremiumProfileScreen> createState()=>_PremiumProfileScreenState();}
class _PremiumProfileScreenState extends State<PremiumProfileScreen>{
 String _name='Your StoryVerse',_bio='Reader · Creator · Dreamer';int _goal=30;bool _notifications=true;String? _photo;
 @override void initState(){super.initState();_load();}
 Future<void> _load()async{final p=await SharedPreferences.getInstance();if(!mounted)return;setState((){_name=p.getString('profile_name')??_name;_bio=p.getString('profile_bio')??_bio;_goal=p.getInt('daily_reading_goal')??30;_notifications=p.getBool('notifications_enabled')??true;_photo=p.getString('profile_photo');});}
 Future<void> _edit(String key,String title,String initial)async{final c=TextEditingController(text:initial);final v=await showDialog<String>(context:context,builder:(ctx)=>AlertDialog(title:Text(title),content:TextField(controller:c,maxLines:key=='profile_bio'?3:1),actions:[TextButton(onPressed:()=>Navigator.pop(ctx),child:const Text('Cancel')),FilledButton(onPressed:()=>Navigator.pop(ctx,c.text.trim()),child:const Text('Save'))]));if(v==null||v.isEmpty)return;final p=await SharedPreferences.getInstance();await p.setString(key,v);if(mounted)setState(()=>key=='profile_name'?_name=v:_bio=v);}
 Future<void> _photoPick()async{try{final f=await FilePicker.pickFiles(type:FileType.image);if(f==null||f.files.isEmpty||f.files.single.path==null)return;final source=File(f.files.single.path!);final docs=await getApplicationDocumentsDirectory();final folder=Directory(p.join(docs.path,'profile'));if(!await folder.exists())await folder.create(recursive:true);final saved=await source.copy(p.join(folder.path,'avatar${p.extension(source.path)}'));final prefs=await SharedPreferences.getInstance();await prefs.setString('profile_photo',saved.path);if(mounted)setState(()=>_photo=saved.path);}catch(_){}}
 @override Widget build(BuildContext context){final c=Theme.of(context).colorScheme;final dark=widget.themeMode==ThemeMode.dark;return ListView(padding:const EdgeInsets.fromLTRB(20,24,20,36),children:[
 Text('YOUR ACCOUNT',style:TextStyle(color:c.primary,fontSize:11,fontWeight:FontWeight.w900,letterSpacing:2)),const SizedBox(height:5),const Text('Profile & settings',style:TextStyle(fontSize:28,fontWeight:FontWeight.w900,letterSpacing:-.7)),const SizedBox(height:20),
 Container(padding:const EdgeInsets.all(18),decoration:BoxDecoration(color:c.surface,borderRadius:BorderRadius.circular(23),border:Border.all(color:c.outlineVariant)),child:Row(children:[GestureDetector(onTap:_photoPick,child:CircleAvatar(radius:31,backgroundColor:c.primaryContainer,backgroundImage:_photo!=null&&File(_photo!).existsSync()?FileImage(File(_photo!)):null,child:_photo==null?Icon(Icons.person,color:c.onPrimaryContainer,size:30):null)),const SizedBox(width:14),Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text(_name,style:const TextStyle(fontSize:17,fontWeight:FontWeight.w900)),Text(_bio,maxLines:2,overflow:TextOverflow.ellipsis,style:TextStyle(color:c.onSurfaceVariant,fontSize:12))])),IconButton(onPressed:()=>_edit('profile_name','Display name',_name),icon:const Icon(Icons.edit_outlined))])),
 const SizedBox(height:22),_section('APPEARANCE'),Container(padding:const EdgeInsets.symmetric(horizontal:14,vertical:8),decoration:BoxDecoration(color:c.surface,borderRadius:BorderRadius.circular(18),border:Border.all(color:c.outlineVariant)),child:Row(children:[Icon(dark?Icons.dark_mode:Icons.light_mode,color:c.primary,size:25),const SizedBox(width:12),Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text(dark?'Dark appearance':'Light appearance',style:const TextStyle(fontWeight:FontWeight.w800)),Text(dark?'Midnight navy · Sky blue · Warm amber':'White · Blue · Warm orange',style:TextStyle(color:c.onSurfaceVariant,fontSize:11))])),FilledButton.icon(onPressed:()=>widget.onThemeChanged(dark?ThemeMode.light:ThemeMode.dark),icon:Icon(dark?Icons.light_mode:Icons.dark_mode,size:16),label:Text(dark?'Light':'Dark'))])), 
 const SizedBox(height:20),_section('READING'),_tile(Icons.flag_outlined,'Daily reading goal','$_goal minutes',()=>_goalDialog()),SwitchListTile(contentPadding:const EdgeInsets.symmetric(horizontal:4),value:_notifications,onChanged:(v)async{final p=await SharedPreferences.getInstance();await p.setBool('notifications_enabled',v);setState(()=>_notifications=v);},title:const Text('Notifications',style:TextStyle(fontWeight:FontWeight.w700)),subtitle:const Text('Reading reminders and updates')),
 const SizedBox(height:20),_section('PERSONAL DETAILS'),_tile(Icons.person_outline,'Edit display name',_name,()=>_edit('profile_name','Display name',_name)),_tile(Icons.notes_outlined,'Edit bio',_bio,()=>_edit('profile_bio','About you',_bio)),_tile(Icons.photo_outlined,'Change profile picture','Choose an image from your device',_photoPick),
 const SizedBox(height:20),_section('APP'),_tile(Icons.download_outlined,'Downloads & storage','Manage books in your Library',()=>ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('Open Library to manage your downloaded books.')))),_tile(Icons.info_outline,'About StoryVerse','Reading · Comics · Writing',()=>showAboutDialog(context:context,applicationName:'StoryVerse',applicationVersion:'0.1.0')),
 ]);}
 Widget _section(String s)=>Padding(padding:const EdgeInsets.only(bottom:9),child:Text(s,style:TextStyle(color:Theme.of(context).colorScheme.primary,fontSize:10,fontWeight:FontWeight.w900,letterSpacing:1.6)));
 Widget _tile(IconData i,String t,String sub,VoidCallback f)=>ListTile(contentPadding:const EdgeInsets.symmetric(horizontal:4),leading:Icon(i,color:Theme.of(context).colorScheme.primary),title:Text(t,style:const TextStyle(fontWeight:FontWeight.w700)),subtitle:Text(sub,maxLines:1,overflow:TextOverflow.ellipsis),trailing:const Icon(Icons.chevron_right),onTap:f);
 Future<void> _goalDialog()async{final c=TextEditingController(text:'$_goal');final v=await showDialog<int>(context:context,builder:(ctx)=>AlertDialog(title:const Text('Daily reading goal'),content:TextField(controller:c,keyboardType:TextInputType.number,decoration:const InputDecoration(suffixText:'minutes')),actions:[TextButton(onPressed:()=>Navigator.pop(ctx),child:const Text('Cancel')),FilledButton(onPressed:()=>Navigator.pop(ctx,int.tryParse(c.text)),child:const Text('Save'))]));if(v==null||v<1||v>1440)return;final p=await SharedPreferences.getInstance();await p.setInt('daily_reading_goal',v);if(mounted)setState(()=>_goal=v);}
}

import 'package:uuid/uuid.dart';
import '../../core/database/storyverse_database.dart';

class AuthorRepository {
  AuthorRepository._();
  static final AuthorRepository instance = AuthorRepository._();
  static const _uuid = Uuid();
  Future get _db async => StoryVerseDatabase.instance.database;

  Future<List<Map<String, Object?>>> projects() async {
    final db = await _db;
    return db.query('projects', orderBy: 'updated_at DESC');
  }

  Future<String> createProject(String title, String premise) async {
    final db = await _db;
    final id = _uuid.v4();
    final now = DateTime.now().toUtc().toIso8601String();
    await db.insert('projects', {'id': id, 'title': title.trim(), 'premise': premise.trim(), 'created_at': now, 'updated_at': now});
    await createChapter(id, 'Chapter 1');
    return id;
  }

  Future<void> deleteProject(String id) async {
    final db = await _db;
    await db.delete('projects', where: 'id = ?', whereArgs: [id]);
  }

  Future<List<Map<String, Object?>>> chapters(String projectId) async {
    final db = await _db;
    return db.query('chapters', where: 'project_id = ?', whereArgs: [projectId], orderBy: 'position ASC');
  }

  Future<String> createChapter(String projectId, String title) async {
    final db = await _db;
    final last = await db.query('chapters', columns: ['position'], where: 'project_id = ?', whereArgs: [projectId], orderBy: 'position DESC', limit: 1);
    final position = last.isEmpty ? 0 : (last.first['position'] as int) + 1;
    final id = _uuid.v4();
    final now = DateTime.now().toUtc().toIso8601String();
    await db.insert('chapters', {'id': id, 'project_id': projectId, 'title': title.trim(), 'content': '', 'position': position, 'updated_at': now});
    await db.update('projects', {'updated_at': now}, where: 'id = ?', whereArgs: [projectId]);
    return id;
  }

  Future<Map<String, Object?>?> chapter(String projectId, String chapterId) async {
    final db = await _db;
    final rows = await db.query('chapters', where: 'project_id = ? AND id = ?', whereArgs: [projectId, chapterId], limit: 1);
    return rows.isEmpty ? null : rows.first;
  }

  Future<void> saveChapter(String projectId, String chapterId, String title, String content) async {
    final db = await _db;
    final now = DateTime.now().toUtc().toIso8601String();
    await db.update('chapters', {'title': title, 'content': content, 'updated_at': now}, where: 'project_id = ? AND id = ?', whereArgs: [projectId, chapterId]);
    await db.update('projects', {'updated_at': now}, where: 'id = ?', whereArgs: [projectId]);
  }

  Future<List<Map<String, Object?>>> searchProject(String projectId, String query) async {
    final db = await _db;
    final q = '%${query.trim()}%';
    return db.query('chapters', where: 'project_id = ? AND (title LIKE ? OR content LIKE ?)', whereArgs: [projectId, q, q], orderBy: 'position ASC');
  }

  Future<int> wordCount(String projectId) async {
    final db = await _db;
    final rows = await db.rawQuery('SELECT content FROM chapters WHERE project_id = ?', [projectId]);
    return rows.fold<int>(0, (sum, row) {
      final value = (row['content'] as String).trim();
      return sum + (value.isEmpty ? 0 : value.split(RegExp(r'\s+')).length);
    });
  }
}

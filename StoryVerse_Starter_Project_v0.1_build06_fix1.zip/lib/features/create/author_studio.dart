import 'dart:async';
import 'package:flutter/material.dart';
import 'author_repository.dart';

class CreateScreen extends StatefulWidget {
  const CreateScreen({super.key});
  @override
  State<CreateScreen> createState() => _CreateScreenState();
}

class _CreateScreenState extends State<CreateScreen> {
  List<Map<String, Object?>> _projects = [];
  bool _loading = true;
  @override
  void initState() { super.initState(); _load(); }
  Future<void> _load() async {
    final rows = await AuthorRepository.instance.projects();
    if (mounted) setState(() { _projects = rows; _loading = false; });
  }

  Future<void> _create() async {
    final title = TextEditingController();
    final premise = TextEditingController();
    final ok = await showDialog<bool>(context: context, builder: (ctx) => AlertDialog(
      title: const Text('Create a story'),
      content: Column(mainAxisSize: MainAxisSize.min, children: [
        TextField(controller: title, autofocus: true, decoration: const InputDecoration(labelText: 'Story title')),
        const SizedBox(height: 12),
        TextField(controller: premise, maxLines: 3, decoration: const InputDecoration(labelText: 'Premise (optional)')),
      ]),
      actions: [
        TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancel')),
        FilledButton(onPressed: () { if (title.text.trim().isNotEmpty) Navigator.pop(ctx, true); }, child: const Text('Create')),
      ],
    ));
    if (ok == true) {
      final id = await AuthorRepository.instance.createProject(title.text, premise.text);
      await _load();
      if (mounted) _open(id, title.text.trim());
    }
    title.dispose(); premise.dispose();
  }

  void _open(String id, String title) {
    Navigator.push(context, MaterialPageRoute(builder: (_) => ProjectWorkspaceScreen(projectId: id, title: title))).then((_) => _load());
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Padding(padding: const EdgeInsets.fromLTRB(20, 22, 20, 12), child: Column(
      crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text('AUTHOR STUDIO', style: theme.textTheme.labelMedium?.copyWith(color: theme.colorScheme.primary, letterSpacing: 1.7, fontWeight: FontWeight.w700)),
        const SizedBox(height: 8),
        Text('Build a world.', style: theme.textTheme.headlineMedium?.copyWith(fontWeight: FontWeight.w800)),
        const SizedBox(height: 7),
        Text('Every story gets its own organized workspace.', style: theme.textTheme.bodyMedium?.copyWith(color: theme.colorScheme.onSurfaceVariant)),
        const SizedBox(height: 18),
        SizedBox(width: double.infinity, child: FilledButton.icon(onPressed: _create, icon: const Icon(Icons.add), label: const Text('Create new story'))),
        const SizedBox(height: 18),
        Text('YOUR PROJECTS', style: theme.textTheme.labelMedium?.copyWith(fontWeight: FontWeight.bold, letterSpacing: 1.2)),
        const SizedBox(height: 8),
        Expanded(child: _loading ? const Center(child: CircularProgressIndicator()) :
          _projects.isEmpty ? const Center(child: Text('Your next story starts here. Create a project to begin.')) :
          ListView.separated(itemCount: _projects.length, separatorBuilder: (_, __) => const SizedBox(height: 8),
            itemBuilder: (ctx, i) {
              final row = _projects[i]; final id = row['id'] as String; final title = row['title'] as String;
              final premise = row['premise'] as String? ?? '';
              return Card(child: ListTile(
                leading: const CircleAvatar(child: Icon(Icons.edit_note)),
                title: Text(title, style: const TextStyle(fontWeight: FontWeight.w700)),
                subtitle: Text(premise.isEmpty ? 'Open project workspace' : premise, maxLines: 2, overflow: TextOverflow.ellipsis),
                trailing: const Icon(Icons.chevron_right), onTap: () => _open(id, title),
              ));
            })),
        const SizedBox(height: 6),
        const _StudioItem(icon: Icons.people_alt_outlined, title: 'Characters', detail: 'Character profiles and arcs — coming next'),
        const _StudioItem(icon: Icons.public, title: 'World & settings', detail: 'Locations and story rules — coming next'),
        const _StudioItem(icon: Icons.timeline, title: 'Plot & timeline', detail: 'Events and structure — coming next'),
      ]));
  }
}

class ProjectWorkspaceScreen extends StatefulWidget {
  final String projectId, title;
  const ProjectWorkspaceScreen({super.key, required this.projectId, required this.title});
  @override
  State<ProjectWorkspaceScreen> createState() => _ProjectWorkspaceScreenState();
}

class _ProjectWorkspaceScreenState extends State<ProjectWorkspaceScreen> {
  List<Map<String, Object?>> _chapters = [];
  List<Map<String, Object?>>? _matches;
  bool _loading = true;
  @override
  void initState() { super.initState(); _load(); }
  Future<void> _load() async {
    final rows = await AuthorRepository.instance.chapters(widget.projectId);
    if (mounted) setState(() { _chapters = rows; _loading = false; });
  }
  Future<void> _addChapter() async {
    final title = TextEditingController(text: 'Chapter ${_chapters.length + 1}');
    final ok = await showDialog<bool>(context: context, builder: (ctx) => AlertDialog(
      title: const Text('New chapter'), content: TextField(controller: title, autofocus: true, decoration: const InputDecoration(labelText: 'Chapter title')),
      actions: [TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancel')),
        FilledButton(onPressed: () => Navigator.pop(ctx, title.text.trim().isNotEmpty), child: const Text('Add'))]));
    if (ok == true) { await AuthorRepository.instance.createChapter(widget.projectId, title.text); await _load(); }
    title.dispose();
  }
  Future<void> _search(String q) async {
    if (q.trim().isEmpty) { setState(() => _matches = null); return; }
    final rows = await AuthorRepository.instance.searchProject(widget.projectId, q);
    if (mounted) setState(() => _matches = rows);
  }
  void _edit(Map<String, Object?> row) {
    Navigator.push(context, MaterialPageRoute(builder: (_) => ChapterEditorScreen(projectId: widget.projectId, chapterId: row['id'] as String))).then((_) => _load());
  }
  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context); final shown = _matches ?? _chapters;
    return Scaffold(
      appBar: AppBar(title: Text(widget.title), actions: [
        IconButton(icon: const Icon(Icons.search), tooltip: 'Search this project', onPressed: () async {
          final q = await showSearch<String>(context: context, delegate: _ChapterSearch());
          if (q != null) _search(q);
        }),
      ]),
      floatingActionButton: FloatingActionButton.extended(onPressed: _addChapter, icon: const Icon(Icons.add), label: const Text('Chapter')),
      body: ListView(padding: const EdgeInsets.all(20), children: [
        Text('PROJECT WORKSPACE', style: theme.textTheme.labelMedium?.copyWith(color: theme.colorScheme.primary, letterSpacing: 1.3, fontWeight: FontWeight.bold)),
        const SizedBox(height: 8),
        Text('Your story, organized.', style: theme.textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.w800)),
        const SizedBox(height: 5),
        Text('All manuscript records shown here are scoped to this project.', style: theme.textTheme.bodySmall),
        const SizedBox(height: 18),
        FutureBuilder<int>(future: AuthorRepository.instance.wordCount(widget.projectId), builder: (_, snap) =>
          Card(child: Padding(padding: const EdgeInsets.all(16), child: Row(children: [
            const Icon(Icons.edit_note), const SizedBox(width: 10), Text('${snap.data ?? 0} words written'),
            const Spacer(), Text('${_chapters.length} chapters', style: theme.textTheme.bodySmall),
          ])))),
        const SizedBox(height: 18),
        Row(children: [Text('MANUSCRIPT', style: theme.textTheme.labelLarge?.copyWith(fontWeight: FontWeight.bold, letterSpacing: 1.2)), const Spacer(), TextButton(onPressed: _addChapter, child: const Text('Add chapter'))]),
        if (_loading) const Center(child: CircularProgressIndicator())
        else if (shown.isEmpty) const Text('No chapters match this search.')
        else ...shown.map((row) => Card(child: ListTile(
          leading: const Icon(Icons.article_outlined), title: Text(row['title'] as String),
          subtitle: Text((row['content'] as String).trim().isEmpty ? 'Start writing this chapter' : (row['content'] as String).trim(), maxLines: 2, overflow: TextOverflow.ellipsis),
          trailing: const Icon(Icons.chevron_right), onTap: () => _edit(row),
        ))),
        const SizedBox(height: 24),
        const _StudioItem(icon: Icons.people_alt_outlined, title: 'Characters', detail: 'Character database is planned for the next milestone'),
        const _StudioItem(icon: Icons.public, title: 'World & settings', detail: 'Worldbuilding tools are planned'),
        const _StudioItem(icon: Icons.timeline, title: 'Plot & timeline', detail: 'Plot tools are planned'),
        const SizedBox(height: 80),
      ]),
    );
  }
}

class _ChapterSearch extends SearchDelegate<String> {
  @override
  List<Widget> buildActions(BuildContext context) => [IconButton(onPressed: () => query = '', icon: const Icon(Icons.clear))];
  @override
  Widget buildLeading(BuildContext context) => IconButton(onPressed: () => close(context, ''), icon: const Icon(Icons.arrow_back));
  @override
  Widget buildResults(BuildContext context) => Center(child: FilledButton(onPressed: () => close(context, query), child: const Text('Search chapters')));
  @override
  Widget buildSuggestions(BuildContext context) => Center(child: Text('Search this project for “$query”'));
}

class ChapterEditorScreen extends StatefulWidget {
  final String projectId, chapterId;
  const ChapterEditorScreen({super.key, required this.projectId, required this.chapterId});
  @override
  State<ChapterEditorScreen> createState() => _ChapterEditorScreenState();
}
class _ChapterEditorScreenState extends State<ChapterEditorScreen> {
  final _title = TextEditingController(), _body = TextEditingController();
  Timer? _timer; bool _loading = true, _saving = false; String _lastSaved = '', _lastSavedTitle = '';
  @override
  void initState() { super.initState(); _load(); }
  Future<void> _load() async {
    final row = await AuthorRepository.instance.chapter(widget.projectId, widget.chapterId);
    if (!mounted) return;
    if (row != null) { _title.text = row['title'] as String; _body.text = row['content'] as String; _lastSaved = _body.text; _lastSavedTitle = _title.text; }
    setState(() => _loading = false);
  }
  void _changed() {
    _timer?.cancel(); setState(() => _saving = true);
    _timer = Timer(const Duration(milliseconds: 700), _save);
  }
  Future<void> _save() async {
    await AuthorRepository.instance.saveChapter(widget.projectId, widget.chapterId,
      _title.text.trim().isEmpty ? 'Untitled chapter' : _title.text.trim(), _body.text);
    _lastSaved = _body.text; _lastSavedTitle = _title.text;
    if (mounted) setState(() => _saving = false);
  }
  @override
  void dispose() {
    _timer?.cancel();
    if (_body.text != _lastSaved || _title.text != _lastSavedTitle) {
      AuthorRepository.instance.saveChapter(widget.projectId, widget.chapterId,
        _title.text.trim().isEmpty ? 'Untitled chapter' : _title.text.trim(), _body.text);
    }
    _title.dispose(); _body.dispose(); super.dispose();
  }
  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Scaffold(appBar: AppBar(title: const Text('Manuscript editor'), actions: [
      Padding(padding: const EdgeInsets.only(right: 16), child: Center(child: Text(_saving ? 'Saving…' : 'Saved', style: theme.textTheme.labelMedium))),
    ]), body: _loading ? const Center(child: CircularProgressIndicator()) : Padding(
      padding: const EdgeInsets.fromLTRB(20, 12, 20, 20), child: Column(children: [
        TextField(controller: _title, onChanged: (_) => _changed(), style: theme.textTheme.titleLarge?.copyWith(fontWeight: FontWeight.bold),
          decoration: const InputDecoration(hintText: 'Chapter title', border: InputBorder.none)),
        const Divider(),
        Expanded(child: TextField(controller: _body, onChanged: (_) => _changed(), expands: true, maxLines: null, minLines: null,
          textAlignVertical: TextAlignVertical.top, keyboardType: TextInputType.multiline,
          decoration: const InputDecoration(hintText: 'Let the story unfold…', border: InputBorder.none))),
        Align(alignment: Alignment.centerLeft, child: Text('${_body.text.trim().isEmpty ? 0 : _body.text.trim().split(RegExp(r'\s+')).length} words', style: theme.textTheme.labelSmall)),
      ])));
  }
}

class _StudioItem extends StatelessWidget {
  final IconData icon; final String title, detail;
  const _StudioItem({required this.icon, required this.title, required this.detail});
  @override
  Widget build(BuildContext context) => ListTile(
    contentPadding: EdgeInsets.zero, leading: Icon(icon, color: Theme.of(context).colorScheme.primary),
    title: Text(title, style: const TextStyle(fontWeight: FontWeight.w700)), subtitle: Text(detail));
}

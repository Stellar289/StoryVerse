class StoryBook {
  final String id, title, author, description, coverUrl, category, source;
  final String? fullTextUrl, alternateFullTextUrl, previewUrl, purchaseUrl, localPath;
  final bool fullTextAvailable;
  const StoryBook({required this.id, required this.title, required this.author,
    required this.description, required this.coverUrl, required this.category,
    required this.source, this.fullTextUrl, this.previewUrl, this.purchaseUrl,
    this.localPath, this.alternateFullTextUrl, this.fullTextAvailable = false});

  factory StoryBook.fromGoogle(Map<String, dynamic> item) {
    final info = (item['volumeInfo'] as Map?)?.cast<String, dynamic>() ?? {};
    final access = (item['accessInfo'] as Map?)?.cast<String, dynamic>() ?? {};
    final sale = (item['saleInfo'] as Map?)?.cast<String, dynamic>() ?? {};
    final image = (info['imageLinks'] as Map?)?.cast<String, dynamic>() ?? {};
    final epub = (access['epub'] as Map?)?.cast<String, dynamic>() ?? {};
    final pdf = (access['pdf'] as Map?)?.cast<String, dynamic>() ?? {};
    final cats = (info['categories'] as List?)?.join(', ') ?? 'Books';
    String cover = (image['thumbnail'] ?? image['smallThumbnail'] ?? '').toString();
    cover = cover.replaceFirst('http://', 'https://').replaceAll('&edge=curl', '');
    final download = (epub['downloadLink'] ?? pdf['downloadLink'])?.toString();
    return StoryBook(id: 'google:${item['id']}', title: (info['title'] ?? 'Untitled').toString(),
      author: ((info['authors'] as List?)?.join(', ') ?? 'Unknown author'),
      description: (info['description'] ?? 'No description supplied by the catalogue.').toString(),
      coverUrl: cover, category: cats, source: 'Google Books', fullTextUrl: download,
      previewUrl: info['previewLink']?.toString(), purchaseUrl: sale['buyLink']?.toString(),
      fullTextAvailable: download != null && download.isNotEmpty);
  }

  factory StoryBook.fromGutendex(Map<String, dynamic> item) {
    final formats = (item['formats'] as Map?)?.cast<String, dynamic>() ?? {};
    final authors = (item['authors'] as List?) ?? [];
    final author = authors.isEmpty ? 'Unknown author' : (authors.first as Map)['name']?.toString() ?? 'Unknown author';
    String? epub, txt;
    formats.forEach((k, v) {
      final value = v?.toString() ?? '';
      if (k == 'application/epub+zip' && !value.toLowerCase().contains('.noimages')) epub = value;
      if (k.startsWith('text/plain') && !value.toLowerCase().contains('zip')) txt = value;
    });
    final bookId = item['id'].toString();
    final suppliedCover = formats['image/jpeg']?.toString() ?? '';
    // Project Gutenberg's stable cover endpoint fills the gap when Gutendex omits image/jpeg.
    final cover = suppliedCover.isNotEmpty ? suppliedCover : 'https://www.gutenberg.org/cache/epub/$bookId/pg$bookId.cover.medium.jpg';
    final url = epub ?? txt;
    return StoryBook(id: 'gutenberg:${item['id']}', title: (item['title'] ?? 'Untitled').toString(),
      author: author, description: 'Public-domain catalogue record. Full text is available from Project Gutenberg where permitted by local copyright law.',
      coverUrl: cover, category: 'Public-domain classic', source: 'Project Gutenberg', fullTextUrl: url,
      alternateFullTextUrl: epub != null && txt != null ? txt : null,
      fullTextAvailable: url != null,);
  }


  factory StoryBook.fromOpenLibrary(Map<String, dynamic> item) {
    final authors = (item['author_name'] as List?)?.whereType<String>().toList() ?? [];
    final coverId = item['cover_i'];
    final cover = coverId == null ? '' : 'https://covers.openlibrary.org/b/id/$coverId-M.jpg';
    final key = (item['key'] ?? '').toString();
    return StoryBook(
      id: 'openlibrary:$key',
      title: (item['title'] ?? 'Untitled').toString(),
      author: authors.isEmpty ? 'Unknown author' : authors.join(', '),
      description: 'Catalogue record from Open Library. Availability and reading access depend on the publisher or lending status.',
      coverUrl: cover,
      category: 'Books & graphic stories',
      source: 'Open Library',
      previewUrl: key.isEmpty ? null : 'https://openlibrary.org$key',
      fullTextAvailable: false,
    );
  }

  factory StoryBook.fromLocal(Map<String, Object?> row) => StoryBook(
    id: row['id'] as String, title: row['title'] as String, author: (row['author'] as String?) ?? 'Personal collection',
    description: 'Imported from your device. Stored for offline reading.', coverUrl: '', category: (row['format'] as String?) ?? 'Imported',
    source: 'Your Library', localPath: row['path'] as String, fullTextAvailable: true);
}

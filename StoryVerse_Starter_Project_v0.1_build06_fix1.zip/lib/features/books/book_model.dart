class StoryBook {
  final String id, title, author, description, coverUrl, category, source;
  final String? fullTextUrl, previewUrl, purchaseUrl, localPath;
  final bool fullTextAvailable;
  const StoryBook({required this.id, required this.title, required this.author,
    required this.description, required this.coverUrl, required this.category,
    required this.source, this.fullTextUrl, this.previewUrl, this.purchaseUrl,
    this.localPath, this.fullTextAvailable = false});

  factory StoryBook.fromGoogle(Map<String, dynamic> item) {
    final info = (item['volumeInfo'] as Map?)?.cast<String, dynamic>() ?? {};
    final access = (item['accessInfo'] as Map?)?.cast<String, dynamic>() ?? {};
    final sale = (item['saleInfo'] as Map?)?.cast<String, dynamic>() ?? {};
    final image = (info['imageLinks'] as Map?)?.cast<String, dynamic>() ?? {};
    final epub = (access['epub'] as Map?)?.cast<String, dynamic>() ?? {};
    final pdf = (access['pdf'] as Map?)?.cast<String, dynamic>() ?? {};
    final cats = (info['categories'] as List?)?.join(', ') ?? 'Books';
    String cover = (image['thumbnail'] ?? image['smallThumbnail'] ?? '').toString();
    cover = cover.replaceFirst('http://', 'https://').replaceAll('&edge=curl', '');
    final download = (epub['downloadLink'] ?? pdf['downloadLink'])?.toString();
    return StoryBook(id: 'google:${item['id']}', title: (info['title'] ?? 'Untitled').toString(),
      author: ((info['authors'] as List?)?.join(', ') ?? 'Unknown author'),
      description: (info['description'] ?? 'No description supplied by the catalogue.').toString(),
      coverUrl: cover, category: cats, source: 'Google Books', fullTextUrl: download,
      previewUrl: info['previewLink']?.toString(), purchaseUrl: sale['buyLink']?.toString(),
      fullTextAvailable: download != null && download.isNotEmpty);
  }

  factory StoryBook.fromGutendex(Map<String, dynamic> item) {
    final formats = (item['formats'] as Map?)?.cast<String, dynamic>() ?? {};
    final authors = (item['authors'] as List?) ?? [];
    final author = authors.isEmpty ? 'Unknown author' : (authors.first as Map)['name']?.toString() ?? 'Unknown author';
    String? epub, txt;
    formats.forEach((k, v) {
      final value = v?.toString() ?? '';
      if (k == 'application/epub+zip' && !value.toLowerCase().contains('.noimages')) epub = value;
      if (k.startsWith('text/plain') && !value.toLowerCase().contains('zip')) txt = value;
    });
    final cover = formats['image/jpeg']?.toString() ?? '';
    final url = epub ?? txt;
    return StoryBook(id: 'gutenberg:${item['id']}', title: (item['title'] ?? 'Untitled').toString(),
      author: author, description: 'Public-domain catalogue record. Full text is available from Project Gutenberg where permitted by local copyright law.',
      coverUrl: cover, category: 'Public-domain classic', source: 'Project Gutenberg', fullTextUrl: url,
      fullTextAvailable: url != null,);
  }

  factory StoryBook.fromLocal(Map<String, Object?> row) => StoryBook(
    id: row['id'] as String, title: row['title'] as String, author: (row['author'] as String?) ?? 'Personal collection',
    description: 'Imported from your device. Stored for offline reading.', coverUrl: '', category: (row['format'] as String?) ?? 'Imported',
    source: 'Your Library', localPath: row['path'] as String, fullTextAvailable: true);
}

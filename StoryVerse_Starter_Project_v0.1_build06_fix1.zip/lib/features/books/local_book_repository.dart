import 'dart:io';
import 'package:file_picker/file_picker.dart';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';
import 'package:uuid/uuid.dart';
import '../../core/database/storyverse_database.dart';

class LocalBookRepository {
  LocalBookRepository._();
  static final instance = LocalBookRepository._();
  static const _uuid = Uuid();

  Future<Map<String, Object?>?> importBook() async {
    final files = await FilePicker.pickFiles(
      type: FileType.custom,
      allowedExtensions: ['epub', 'pdf', 'txt'],
      allowMultiple: false,
    );
    if (files.isEmpty) return null;
    final picked = files.single;
    final ext = p.extension(picked.name).replaceFirst('.', '').toLowerCase();
    if (!['epub', 'pdf', 'txt'].contains(ext)) throw Exception('Choose an EPUB, PDF or TXT book.');
    // file_picker 12 can read the selected document from its native source
    // without eagerly loading the entire file into memory at picker time.
    final bytes = await picked.readAsBytes();
    if (bytes.isEmpty) {
      throw Exception('The selected file could not be read or is empty.');
    }
    final dir = await getApplicationDocumentsDirectory();
    final booksDir = Directory(p.join(dir.path, 'books'));
    if (!await booksDir.exists()) await booksDir.create(recursive: true);
    final id = _uuid.v4();
    final safeName = '${id}_${p.basename(picked.name).replaceAll(RegExp(r'[^A-Za-z0-9._-]'), '_')}';
    final file = File(p.join(booksDir.path, safeName));
    await file.writeAsBytes(bytes, flush: true);
    final row = <String, Object?>{'id': id, 'title': p.basenameWithoutExtension(picked.name), 'author': 'Personal collection', 'path': file.path, 'format': ext.toUpperCase(), 'added_at': DateTime.now().toUtc().toIso8601String(), 'last_position': 0, 'is_favorite': 0};
    final db = await StoryVerseDatabase.instance.database;
    await db.insert('library_books', row);
    return row;
  }

  Future<Map<String, Object?>> importBytes({required String title, required String author, required List<int> bytes, required String extension}) async {
    final ext = extension.toLowerCase().replaceFirst('.', '');
    if (!['epub', 'pdf', 'txt'].contains(ext)) throw Exception('Unsupported downloaded format: $ext');
    if (bytes.isEmpty) throw Exception('The downloaded book is empty.');
    final dir = await getApplicationDocumentsDirectory();
    final booksDir = Directory(p.join(dir.path, 'books'));
    if (!await booksDir.exists()) await booksDir.create(recursive: true);
    final id = _uuid.v4();
    final safeName = '${id}_${title.replaceAll(RegExp(r'[^A-Za-z0-9._-]'), '_')}.$ext';
    final file = File(p.join(booksDir.path, safeName));
    await file.writeAsBytes(bytes, flush: true);
    final row = <String, Object?>{'id': id, 'title': title, 'author': author, 'path': file.path, 'format': ext.toUpperCase(), 'added_at': DateTime.now().toUtc().toIso8601String(), 'last_position': 0, 'is_favorite': 0};
    final db = await StoryVerseDatabase.instance.database;
    await db.insert('library_books', row);
    return row;
  }

  Future<List<Map<String, Object?>>> books() async {
    final db = await StoryVerseDatabase.instance.database;
    return db.query('library_books', orderBy: 'added_at DESC');
  }
  Future<void> savePosition(String id, int position) async {
    final db = await StoryVerseDatabase.instance.database;
    await db.update('library_books', {'last_position': position}, where: 'id = ?', whereArgs: [id]);
  }
  Future<void> toggleFavorite(String id, bool value) async {
    final db = await StoryVerseDatabase.instance.database;
    await db.update('library_books', {'is_favorite': value ? 1 : 0}, where: 'id = ?', whereArgs: [id]);
  }
  Future<void> remove(String id, String path) async {
    final db = await StoryVerseDatabase.instance.database;
    await db.delete('library_books', where: 'id = ?', whereArgs: [id]);
    final file = File(path);
    if (await file.exists()) await file.delete();
  }
  Future<void> addBookmark(String bookId, String label, int position) async {
    final db = await StoryVerseDatabase.instance.database;
    await db.insert('bookmarks', {'id': _uuid.v4(), 'book_id': bookId, 'label': label, 'position': position, 'created_at': DateTime.now().toUtc().toIso8601String()});
  }
  Future<List<Map<String, Object?>>> bookmarks(String bookId) async {
    final db = await StoryVerseDatabase.instance.database;
    return db.query('bookmarks', where: 'book_id = ?', whereArgs: [bookId], orderBy: 'created_at DESC');
  }
}

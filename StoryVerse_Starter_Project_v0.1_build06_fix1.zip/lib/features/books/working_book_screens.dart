import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:url_launcher/url_launcher.dart';
import 'package:pdfrx/pdfrx.dart';
import '../../core/database/storyverse_database.dart';
import 'book_catalogue_service.dart';
import 'book_model.dart';
import 'local_book_repository.dart';
import 'epub_text_extractor.dart';


class WorkingHomeScreen extends StatefulWidget {
  const WorkingHomeScreen({super.key});

  @override
  State<WorkingHomeScreen> createState() => _WorkingHomeScreenState();
}

class _WorkingHomeScreenState extends State<WorkingHomeScreen> {
  List<StoryBook> _books = [];
  bool _busy = true;
  String? _error;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    try {
      final books = await BookCatalogueService.instance.searchPublicDomain('');
      if (mounted) setState(() => _books = books);
    } catch (_) {
      if (mounted) {
        setState(() => _error =
            'Connect to the internet to load current catalogue recommendations.');
      }
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final featured = _books.isEmpty ? null : _books.first;
    return RefreshIndicator(
      onRefresh: _load,
      child: CustomScrollView(
        slivers: [
          SliverPadding(
            padding: const EdgeInsets.fromLTRB(20, 20, 20, 12),
            sliver: SliverToBoxAdapter(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('YOUR STORYVERSE', style: TextStyle(
                    color: Theme.of(context).colorScheme.primary,
                    fontSize: 10, letterSpacing: 2.2,
                    fontWeight: FontWeight.w800,
                  )),
                  const SizedBox(height: 5),
                  const Text('Good evening, reader.', style: TextStyle(
                    fontSize: 24, fontWeight: FontWeight.w800,
                  )),
                  const SizedBox(height: 3),
                  Text('Discover a real book. Enter another world.',
                    style: TextStyle(color: Theme.of(context).colorScheme.onSurfaceVariant)),
                ],
              ),
            ),
          ),
          if (_busy)
            const SliverToBoxAdapter(child: LinearProgressIndicator())
          else if (_error != null)
            SliverToBoxAdapter(child: Padding(
              padding: const EdgeInsets.all(20), child: Text(_error!),
            ))
          else if (featured != null)
            SliverToBoxAdapter(
              child: Padding(
                padding: const EdgeInsets.fromLTRB(16, 8, 16, 10),
                child: InkWell(
                  onTap: () => Navigator.push(context, MaterialPageRoute(
                    builder: (_) => CatalogueBookDetail(book: featured),
                  )),
                  borderRadius: BorderRadius.circular(24),
                  child: Container(
                    height: 225,
                    padding: const EdgeInsets.all(18),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(24),
                      gradient: const LinearGradient(colors: [
                        Color(0xFF29233B), Color(0xFF10121B),
                      ]),
                    ),
                    child: Row(children: [
                      Expanded(child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisAlignment: MainAxisAlignment.end,
                        children: [
                          const Text('FEATURED CLASSIC', style: TextStyle(
                            color: Color(0xFFC9B5F2), fontSize: 9,
                            letterSpacing: 1.7, fontWeight: FontWeight.bold,
                          )),
                          const SizedBox(height: 9),
                          Text(featured.title, maxLines: 3,
                            overflow: TextOverflow.ellipsis,
                            style: const TextStyle(color: Colors.white,
                              fontSize: 22, fontWeight: FontWeight.w800)),
                          const SizedBox(height: 6),
                          Text(featured.author,
                            style: const TextStyle(color: Colors.white70, fontSize: 11)),
                          const SizedBox(height: 15),
                          const Text('Explore book  →', style: TextStyle(
                            color: Color(0xFFE1D6FA), fontWeight: FontWeight.bold,
                            fontSize: 11,
                          )),
                        ],
                      )),
                      const SizedBox(width: 16),
                      ClipRRect(
                        borderRadius: BorderRadius.circular(9),
                        child: SizedBox(
                          width: 116, height: 174,
                          child: featured.coverUrl.isEmpty
                              ? const ColoredBox(color: Colors.white10,
                                  child: Icon(Icons.menu_book, color: Colors.white, size: 45))
                              : Image.network(featured.coverUrl, fit: BoxFit.cover,
                                  errorBuilder: (_, __, ___) => const ColoredBox(
                                    color: Colors.white10,
                                    child: Icon(Icons.menu_book, color: Colors.white, size: 45),
                                  )),
                        ),
                      ),
                    ]),
                  ),
                ),
              ),
            ),
          SliverPadding(
            padding: const EdgeInsets.fromLTRB(20, 16, 20, 10),
            sliver: SliverToBoxAdapter(child: Row(children: [
              const Expanded(child: Text('Popular public-domain books',
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800))),
              TextButton(
                onPressed: () => Navigator.push(context, MaterialPageRoute(
                  builder: (_) => const WorkingDiscoverScreen(),
                )),
                child: const Text('Discover'),
              ),
            ])),
          ),
          if (_books.isNotEmpty)
            SliverToBoxAdapter(
              child: SizedBox(
                height: 205,
                child: ListView.separated(
                  padding: const EdgeInsets.symmetric(horizontal: 20),
                  scrollDirection: Axis.horizontal,
                  itemCount: _books.length,
                  separatorBuilder: (_, __) => const SizedBox(width: 13),
                  itemBuilder: (context, index) {
                    final book = _books[index];
                    return SizedBox(
                      width: 112,
                      child: InkWell(
                        onTap: () => Navigator.push(context, MaterialPageRoute(
                          builder: (_) => CatalogueBookDetail(book: book),
                        )),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Expanded(child: ClipRRect(
                              borderRadius: BorderRadius.circular(8),
                              child: Container(
                                width: 112,
                                color: Theme.of(context).colorScheme.surfaceContainerHighest,
                                child: book.coverUrl.isEmpty
                                    ? const Icon(Icons.menu_book, size: 40)
                                    : Image.network(book.coverUrl, fit: BoxFit.cover,
                                        errorBuilder: (_, __, ___) =>
                                            const Icon(Icons.menu_book, size: 40)),
                              ),
                            )),
                            const SizedBox(height: 7),
                            Text(book.title, maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                              style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 11)),
                            Text(book.author, maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                              style: TextStyle(color: Theme.of(context).colorScheme.onSurfaceVariant,
                                fontSize: 9)),
                          ],
                        ),
                      ),
                    );
                  },
                ),
              ),
            ),
          const SliverToBoxAdapter(child: Padding(
            padding: EdgeInsets.fromLTRB(20, 24, 20, 30),
            child: Text(
              'StoryVerse also gives you a private space to create your own stories. Open Create to start a project.',
              style: TextStyle(height: 1.5),
            ),
          )),
        ],
      ),
    );
  }
}

class WorkingLibraryScreen extends StatefulWidget {
  const WorkingLibraryScreen({super.key});
  @override State<WorkingLibraryScreen> createState() => _WorkingLibraryScreenState();
}
class _WorkingLibraryScreenState extends State<WorkingLibraryScreen> {
  List<Map<String,Object?>> _books=[]; bool _loading=true; String _query=''; String _filter='All';
  @override void initState(){super.initState();_load();}
  Future<void> _load() async { setState(()=>_loading=true); try { final rows=await LocalBookRepository.instance.books(); if(mounted)setState(()=>_books=rows); } catch(e){if(mounted)_toast('Could not load your library: $e');} finally {if(mounted)setState(()=>_loading=false);} }
  void _toast(String s)=>ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text(s)));
  Future<void> _import() async { try { final row=await LocalBookRepository.instance.importBook(); if(row==null)return; await _load(); if(!mounted)return; Navigator.push(context,MaterialPageRoute(builder:(_)=>ImportedBookReader(book:row))); } catch(e){_toast('Import failed: $e');} }
  @override Widget build(BuildContext context){ final rows=_books.where((b){final q='${b['title']} ${b['author']}'.toLowerCase(); return q.contains(_query.toLowerCase()) && (_filter=='All'||(_filter=='Favourites'?(b['is_favorite']==1):b['format']==_filter));}).toList();
    return Scaffold(floatingActionButton:FloatingActionButton.extended(onPressed:_import,icon:const Icon(Icons.add),label:const Text('Import book')),body:CustomScrollView(slivers:[SliverPadding(padding:const EdgeInsets.fromLTRB(20,22,20,14),sliver:SliverToBoxAdapter(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text('YOUR COLLECTION',style:TextStyle(color:Theme.of(context).colorScheme.primary,fontSize:10,letterSpacing:2,fontWeight:FontWeight.bold)),const SizedBox(height:6),const Text('The Library',style:TextStyle(fontSize:28,fontWeight:FontWeight.w800)),const SizedBox(height:5),Text('Your imported books, stored on this device.',style:TextStyle(color:Theme.of(context).colorScheme.onSurfaceVariant)),const SizedBox(height:16),TextField(onChanged:(v)=>setState(()=>_query=v),decoration:InputDecoration(hintText:'Search your books',prefixIcon:const Icon(Icons.search),filled:true,border:OutlineInputBorder(borderRadius:BorderRadius.circular(15),borderSide:BorderSide.none))),const SizedBox(height:12),Wrap(spacing:7,children:['All','Favourites','EPUB','PDF','TXT'].map((v)=>ChoiceChip(label:Text(v),selected:_filter==v,onSelected:(_)=>setState(()=>_filter=v))).toList()),const SizedBox(height:8),Text('${rows.length} books',style:const TextStyle(fontWeight:FontWeight.w700))]))),if(_loading)const SliverFillRemaining(child:Center(child:CircularProgressIndicator())) else if(rows.isEmpty)SliverFillRemaining(hasScrollBody:false,child:Center(child:Padding(padding:const EdgeInsets.all(30),child:Column(mainAxisSize:MainAxisSize.min,children:[const Icon(Icons.menu_book_outlined,size:54),const SizedBox(height:12),Text(_books.isEmpty?'Your library is waiting for its first book.':'No books match this filter.',textAlign:TextAlign.center,style:const TextStyle(fontWeight:FontWeight.w700)),const SizedBox(height:8),const Text('Import an EPUB, PDF or TXT file from your phone to begin reading.',textAlign:TextAlign.center)])))) else SliverPadding(padding:const EdgeInsets.fromLTRB(20,6,20,100),sliver:SliverList(delegate:SliverChildBuilderDelegate((context,i){final b=rows[i];return Card(margin:const EdgeInsets.only(bottom:10),child:ListTile(leading:Container(width:45,height:58,decoration:BoxDecoration(color:Theme.of(context).colorScheme.primaryContainer,borderRadius:BorderRadius.circular(7)),child:Icon(b['format']=='PDF'?Icons.picture_as_pdf:b['format']=='EPUB'?Icons.auto_stories:Icons.description)),title:Text('${b['title']}',maxLines:2,overflow:TextOverflow.ellipsis),subtitle:Text('${b['format']} · ${b['author']}'),trailing:PopupMenuButton<String>(onSelected:(v)async{if(v=='fav'){await LocalBookRepository.instance.toggleFavorite('${b['id']}',b['is_favorite']!=1);_load();}if(v=='delete'){final ok=await showDialog<bool>(context:context,builder:(c)=>AlertDialog(title:const Text('Remove book?'),content:const Text('This removes the imported copy from StoryVerse.'),actions:[TextButton(onPressed:()=>Navigator.pop(c,false),child:const Text('Cancel')),FilledButton(onPressed:()=>Navigator.pop(c,true),child:const Text('Remove'))]));if(ok==true){await LocalBookRepository.instance.remove('${b['id']}','${b['path']}');_load();}}},itemBuilder:(_)=>[PopupMenuItem(value:'fav',child:Text(b['is_favorite']==1?'Remove favourite':'Add favourite')),const PopupMenuItem(value:'delete',child:Text('Remove book'))]),onTap:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>ImportedBookReader(book:b))).then((_)=>_load())));},childCount:rows.length))) ])); }
}

class WorkingDiscoverScreen extends StatefulWidget {const WorkingDiscoverScreen({super.key});@override State<WorkingDiscoverScreen> createState()=>_WorkingDiscoverScreenState();}
class _WorkingDiscoverScreenState extends State<WorkingDiscoverScreen>{final _search=TextEditingController();List<StoryBook> _results=[];bool _busy=false;String? _error;String _source='Public-domain books';
 Future<void> _find([String? q])async{FocusScope.of(context).unfocus();setState(()=>_busy=true);_error=null;try{final found=_source=='Public-domain books'?await BookCatalogueService.instance.searchPublicDomain(q??_search.text):await BookCatalogueService.instance.searchGoogle(q??_search.text);if(mounted)setState(()=>_results=found);}catch(e){if(mounted)setState(()=>_error='Could not reach the catalogue. Check your connection and try again.');}finally{if(mounted)setState(()=>_busy=false);}}
 @override void initState(){super.initState();_find('');}
 @override void dispose(){_search.dispose();super.dispose();}
 @override Widget build(BuildContext context)=>CustomScrollView(slivers:[SliverPadding(padding:const EdgeInsets.fromLTRB(20,22,20,14),sliver:SliverToBoxAdapter(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text('EXPLORE REAL CATALOGUES',style:TextStyle(color:Theme.of(context).colorScheme.primary,fontSize:10,letterSpacing:2,fontWeight:FontWeight.bold)),const SizedBox(height:6),const Text('Discover',style:TextStyle(fontSize:29,fontWeight:FontWeight.w800)),const SizedBox(height:6),Text('Find books from public-domain and worldwide catalogues.',style:TextStyle(color:Theme.of(context).colorScheme.onSurfaceVariant)),const SizedBox(height:15),DropdownButtonFormField<String>(value:_source,items:const [DropdownMenuItem(value:'Public-domain books',child:Text('Public-domain books · Gutenberg')),DropdownMenuItem(value:'Worldwide catalogue',child:Text('Worldwide catalogue · Google Books'))],onChanged:(v){if(v!=null){setState(()=>_source=v);_find();}},decoration:const InputDecoration(border:OutlineInputBorder(),prefixIcon:Icon(Icons.collections_bookmark))),const SizedBox(height:10),TextField(controller:_search,onSubmitted:_find,decoration:InputDecoration(hintText:'Search title or author',prefixIcon:const Icon(Icons.search),suffixIcon:IconButton(onPressed:_find,icon:const Icon(Icons.arrow_forward)),border:OutlineInputBorder(borderRadius:BorderRadius.circular(14))))]))),if(_busy)const SliverToBoxAdapter(child:LinearProgressIndicator()) else if(_error!=null)SliverFillRemaining(hasScrollBody:false,child:Center(child:Padding(padding:const EdgeInsets.all(24),child:Text(_error!,textAlign:TextAlign.center)))) else if(_results.isEmpty)const SliverFillRemaining(child:Center(child:Text('No books found. Try another search.'))) else SliverPadding(padding:const EdgeInsets.fromLTRB(20,4,20,30),sliver:SliverList(delegate:SliverChildBuilderDelegate((context,i){final b=_results[i];return Card(margin:const EdgeInsets.only(bottom:11),child:ListTile(isThreeLine:true,leading:Container(width:48,height:68,decoration:BoxDecoration(color:Theme.of(context).colorScheme.surfaceContainerHighest,borderRadius:BorderRadius.circular(5)),clipBehavior:Clip.antiAlias,child:b.coverUrl.isEmpty?const Icon(Icons.menu_book):Image.network(b.coverUrl,fit:BoxFit.cover,errorBuilder:(_,__,___)=>const Icon(Icons.menu_book))),title:Text(b.title,maxLines:2,overflow:TextOverflow.ellipsis),subtitle:Text('${b.author}\n${b.fullTextAvailable?'Full text link available':'Metadata / preview only'}',maxLines:2),trailing:const Icon(Icons.chevron_right),onTap:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>CatalogueBookDetail(book:b)))));},childCount:_results.length)))]);
}

class CatalogueBookDetail extends StatelessWidget{final StoryBook book;const CatalogueBookDetail({super.key,required this.book});@override Widget build(BuildContext context)=>Scaffold(appBar:AppBar(title:const Text('Book details')),body:ListView(padding:const EdgeInsets.all(22),children:[Center(child:Container(width:150,height:220,decoration:BoxDecoration(borderRadius:BorderRadius.circular(9),boxShadow:[BoxShadow(color:Colors.black.withValues(alpha:.2),blurRadius:16)]),clipBehavior:Clip.antiAlias,child:book.coverUrl.isEmpty?const ColoredBox(color:Colors.black12,child:Icon(Icons.menu_book,size:60)):Image.network(book.coverUrl,fit:BoxFit.cover,errorBuilder:(_,__,___)=>const Icon(Icons.menu_book,size:60)))),const SizedBox(height:22),Text(book.title,style:const TextStyle(fontSize:25,fontWeight:FontWeight.w800)),Text(book.author,style:TextStyle(color:Theme.of(context).colorScheme.onSurfaceVariant)),const SizedBox(height:14),Text(book.description,style:const TextStyle(height:1.6)),const SizedBox(height:16),Text('Source: ${book.source}'),Text(book.fullTextAvailable?'Full-text link supplied by source. Check local rights and source terms.':'This record does not include a full-text download.'),const SizedBox(height:18),if(book.fullTextAvailable)FilledButton.icon(onPressed:()=>_download(context),icon:const Icon(Icons.download),label:const Text('Download full text')) else if(book.previewUrl!=null)OutlinedButton.icon(onPressed:()=>_open(context,book.previewUrl!),icon:const Icon(Icons.open_in_new),label:const Text('Open preview')) else if(book.purchaseUrl!=null)OutlinedButton.icon(onPressed:()=>_open(context,book.purchaseUrl!),icon:const Icon(Icons.shopping_bag_outlined),label:const Text('Purchase / access'))]));
 Future<void> _download(BuildContext context)async{try{final uri=Uri.parse(book.fullTextUrl!);final response=await http.get(uri).timeout(const Duration(seconds:35));if(response.statusCode!=200)throw Exception('Download failed (${response.statusCode}).');final path=uri.path.toLowerCase();final ext=path.endsWith('.epub')?'epub':path.endsWith('.pdf')?'pdf':'txt';await LocalBookRepository.instance.importBytes(title:book.title,author:book.author,bytes:response.bodyBytes,extension:ext);if(context.mounted){ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('Book downloaded to your Library.')));Navigator.pop(context);}}catch(e){if(context.mounted)ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text('Could not download this book: $e')));}}
 void _open(BuildContext c,String url)async{try{final ok=await launchUrl(Uri.parse(url),mode:LaunchMode.externalApplication);if(!ok)throw Exception('Link could not be opened.');}catch(e){if(c.mounted)ScaffoldMessenger.of(c).showSnackBar(SnackBar(content:Text('$e')));}}
}

class ImportedBookReader extends StatefulWidget{final Map<String,Object?> book;const ImportedBookReader({super.key,required this.book});@override State<ImportedBookReader> createState()=>_ImportedBookReaderState();}
class _ImportedBookReaderState extends State<ImportedBookReader>{String? _text;String? _error;bool _loading=true;double _font=19;int _position=0;final _scroll=ScrollController();
 @override void initState(){super.initState();_load();}
 Future<void> _load()async{try{final path='${widget.book['path']}';final ext='${widget.book['format']}';final file=File(path);if(!await file.exists())throw Exception('The imported file is missing.');_position=(widget.book['last_position'] as int?)??0;String text;if(ext=='TXT'){text=await file.readAsString();}else if(ext=='EPUB'){text=EpubTextExtractor.extract(await file.readAsBytes());}else{text='';}if(mounted)setState(()=>_text=text);if(ext!='PDF'&&_position>0){WidgetsBinding.instance.addPostFrameCallback((_){if(mounted&&_scroll.hasClients)_scroll.jumpTo(_position.toDouble().clamp(0,_scroll.position.maxScrollExtent).toDouble());});}if(ext=='PDF'&&mounted){setState(()=>_loading=false);return;} }catch(e){_error=e.toString();}finally{if(mounted)setState(()=>_loading=false);}}
 Future<void> _bookmark()async{await LocalBookRepository.instance.addBookmark('${widget.book['id']}','Position $_position',_position);if(mounted)ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('Bookmark saved.')));}
 @override void dispose(){_scroll.dispose();super.dispose();}
 Future<void> _lookup(String word)async{try{final r=await http.get(Uri.https('api.dictionaryapi.dev','/api/v2/entries/en/${Uri.encodeComponent(word)}')).timeout(const Duration(seconds:8));String definition='No definition found.';if(r.statusCode==200){final data=jsonDecode(r.body) as List;definition=(((data.first['meanings'] as List).first['definitions'] as List).first['definition']).toString();}if(!mounted)return;showModalBottomSheet(context:context,showDragHandle:true,builder:(_)=>Padding(padding:const EdgeInsets.all(22),child:Column(mainAxisSize:MainAxisSize.min,crossAxisAlignment:CrossAxisAlignment.start,children:[Text(word,style:const TextStyle(fontSize:22,fontWeight:FontWeight.bold)),const SizedBox(height:9),Text(definition,style:const TextStyle(height:1.5)),const SizedBox(height:18),FilledButton(onPressed:()async{final db=await StoryVerseDatabase.instance.database;await db.insert('vocabulary',{'id':'${DateTime.now().microsecondsSinceEpoch}','word':word,'definition':definition,'book_id':widget.book['id'],'context':'${widget.book['title']}','created_at':DateTime.now().toUtc().toIso8601String()});if(mounted)Navigator.pop(context);},child:const Text('Save to vocabulary'))])));}catch(_){if(mounted)ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('Dictionary lookup failed. Check your internet connection.')));}}
 @override Widget build(BuildContext context){final ext='${widget.book['format']}';return Scaffold(backgroundColor:const Color(0xFFF3EDE2),appBar:AppBar(backgroundColor:const Color(0xFFF3EDE2),foregroundColor:const Color(0xFF28231E),title:Text('${widget.book['title']}',maxLines:1,overflow:TextOverflow.ellipsis,style:const TextStyle(fontSize:15)),actions:[IconButton(onPressed:_bookmark,icon:const Icon(Icons.bookmark_add_outlined)),PopupMenuButton<String>(onSelected:(v){if(v=='larger')setState(()=>_font=(_font+1).clamp(14,32).toDouble());if(v=='smaller')setState(()=>_font=(_font-1).clamp(14,32).toDouble());},itemBuilder:(_)=>const [PopupMenuItem(value:'larger',child:Text('Increase text size')),PopupMenuItem(value:'smaller',child:Text('Decrease text size'))])]),body:_loading?const Center(child:CircularProgressIndicator()):_error!=null?Center(child:Text('Could not open book: $_error')):ext=='PDF'?PdfViewer.file('${widget.book['path']}'):_text==null?const Center(child:Text('No readable text found.')):NotificationListener<ScrollNotification>(onNotification:(n){if(n.metrics.axis==Axis.vertical&&n is ScrollEndNotification){_position=n.metrics.pixels.round();LocalBookRepository.instance.savePosition('${widget.book['id']}',_position);}return false;},child:ListView(controller:_scroll,padding:const EdgeInsets.fromLTRB(25,28,25,60),children:[Text('${widget.book['title']}',style:TextStyle(fontFamily:'serif',fontSize:_font+10,fontWeight:FontWeight.bold,color:const Color(0xFF29231D))),const SizedBox(height:25),SelectableText(_text!,onSelectionChanged:(selection,cause){if(cause==SelectionChangedCause.longPress&&selection.start>=0&&selection.end>selection.start){final selected=_text!.substring(selection.start,selection.end).trim();final word=selected.split(RegExp(r'\s+')).first.replaceAll(RegExp(r"[^A-Za-z']"),'');if(word.isNotEmpty)_lookup(word);}},style:TextStyle(fontFamily:'serif',fontSize:_font,height:1.85,color:const Color(0xFF39322B)))])));}

}

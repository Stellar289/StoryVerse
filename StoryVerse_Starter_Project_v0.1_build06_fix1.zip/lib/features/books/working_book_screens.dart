import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:url_launcher/url_launcher.dart';
import 'package:pdfrx/pdfrx.dart';
import '../../core/database/storyverse_database.dart';
import 'book_catalogue_service.dart';
import 'book_model.dart';
import 'local_book_repository.dart';
import 'epub_text_extractor.dart';
import '../create/author_studio.dart';


class WorkingHomeScreen extends StatefulWidget {
  const WorkingHomeScreen({super.key});
  @override State<WorkingHomeScreen> createState() => _WorkingHomeScreenState();
}

class _WorkingHomeScreenState extends State<WorkingHomeScreen> {
  List<StoryBook> _books = [];
  List<Map<String, Object?>> _recent = [];
  bool _busy = true;
  String? _error;

  @override void initState() { super.initState(); _load(); }

  Future<void> _load() async {
    setState(() { _busy = true; _error = null; });
    try {
      final results = await Future.wait([
        BookCatalogueService.instance.searchPublicDomain(''),
        LocalBookRepository.instance.books(),
      ]);
      if (mounted) setState(() {
        _books = results[0] as List<StoryBook>;
        _recent = results[1] as List<Map<String, Object?>>;
      });
    } catch (_) {
      if (mounted) setState(() => _error = 'Some shelves could not load. Check your connection and pull to refresh.');
    } finally { if (mounted) setState(() => _busy = false); }
  }

  void _openBook(StoryBook book) => Navigator.push(context, MaterialPageRoute(builder: (_) => CatalogueBookDetail(book: book)));
  void _openComics() => Navigator.push(context, MaterialPageRoute(builder: (_) => const ComicsScreen()));

  @override Widget build(BuildContext context) {
    final featured = _books.isEmpty ? null : _books.first;
    return RefreshIndicator(onRefresh: _load, child: CustomScrollView(slivers: [
      SliverPadding(padding: const EdgeInsets.fromLTRB(20, 18, 20, 10), sliver: SliverToBoxAdapter(child: Row(children: [
        const Icon(Icons.auto_stories_rounded, color: Color(0xFF55C9F2), size: 28),
        const SizedBox(width: 9), const Expanded(child: Text('StoryVerse', style: TextStyle(fontSize: 21, fontWeight: FontWeight.w900, letterSpacing: -.5))),
        IconButton(onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const WorkingDiscoverScreen())), icon: const Icon(Icons.search_rounded)),
        IconButton(onPressed: _openComics, icon: const Icon(Icons.grid_view_rounded)),
      ]))),
      SliverPadding(padding: const EdgeInsets.fromLTRB(20, 4, 20, 15), sliver: SliverToBoxAdapter(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text('YOUR NEXT WORLD IS WAITING', style: TextStyle(color: Theme.of(context).colorScheme.primary, fontSize: 10, letterSpacing: 2, fontWeight: FontWeight.w900)),
        const SizedBox(height: 5), const Text('Stories worth getting lost in.', style: TextStyle(fontSize: 25, fontWeight: FontWeight.w900, height: 1.12)),
        const SizedBox(height: 5), Text('Read novels, explore comics, or create your own universe.', style: TextStyle(color: Theme.of(context).colorScheme.onSurfaceVariant, fontSize: 12)),
      ]))),
      if (_busy) const SliverToBoxAdapter(child: LinearProgressIndicator(minHeight: 2)),
      if (featured != null) SliverToBoxAdapter(child: Padding(padding: const EdgeInsets.symmetric(horizontal: 16), child: _FeaturedStory(book: featured, onTap: () => _openBook(featured)))),
      if (_error != null) SliverToBoxAdapter(child: Padding(padding: const EdgeInsets.all(18), child: Text(_error!))),
      if (_recent.isNotEmpty) ...[
        _shelfHeading(context, 'Continue reading'),
        SliverToBoxAdapter(child: SizedBox(height: 104, child: ListView.separated(padding: const EdgeInsets.symmetric(horizontal: 18), scrollDirection: Axis.horizontal, itemCount: _recent.take(8).length, separatorBuilder: (_, __) => const SizedBox(width: 10), itemBuilder: (context, i) {
          final b = _recent[i];
          return SizedBox(width: 245, child: Card(child: InkWell(borderRadius: BorderRadius.circular(16), onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => ImportedBookReader(book: b))), child: Padding(padding: const EdgeInsets.all(10), child: Row(children: [
            Container(width: 52, height: 72, decoration: BoxDecoration(color: Theme.of(context).colorScheme.primaryContainer, borderRadius: BorderRadius.circular(8)), child: const Icon(Icons.menu_book_rounded, size: 27)),
            const SizedBox(width: 11), Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisAlignment: MainAxisAlignment.center, children: [Text('${b['title']}', maxLines: 2, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 12)), const SizedBox(height: 5), Text('${b['format']} · On this device', style: TextStyle(color: Theme.of(context).colorScheme.onSurfaceVariant, fontSize: 10)), const SizedBox(height: 8), Container(height: 3, decoration: BoxDecoration(color: Theme.of(context).colorScheme.primary.withValues(alpha: .2), borderRadius: BorderRadius.circular(5))) ])),
          ])))));
        }))),
      ],
      _shelfHeading(context, 'Comics & graphic stories', action: 'Explore all', onTap: _openComics),
      SliverToBoxAdapter(child: Padding(padding: const EdgeInsets.symmetric(horizontal: 18), child: InkWell(onTap: _openComics, borderRadius: BorderRadius.circular(20), child: Container(height: 116, decoration: BoxDecoration(borderRadius: BorderRadius.circular(20), gradient: const LinearGradient(colors: [Color(0xFF143A55), Color(0xFF17243A), Color(0xFF563323)])), child: const Row(children: [
        SizedBox(width: 18), Icon(Icons.auto_awesome_mosaic_rounded, color: Color(0xFF6DD8FF), size: 44), SizedBox(width: 15), Expanded(child: Column(mainAxisAlignment: MainAxisAlignment.center, crossAxisAlignment: CrossAxisAlignment.start, children: [Text('ENTER THE PANELS', style: TextStyle(color: Color(0xFFFFA45F), fontSize: 9, letterSpacing: 1.8, fontWeight: FontWeight.w900)), SizedBox(height: 5), Text('Comics, manga & graphic novels', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w900, fontSize: 16)), SizedBox(height: 4), Text('Discover a whole different kind of story.', style: TextStyle(color: Colors.white70, fontSize: 10))])), Icon(Icons.arrow_circle_right_rounded, color: Color(0xFFFFA45F), size: 31), SizedBox(width: 15),
      ]))))),
      _shelfHeading(context, 'Popular public-domain reads', action: 'See all', onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const WorkingDiscoverScreen()))),
      if (_books.isNotEmpty) SliverToBoxAdapter(child: SizedBox(height: 222, child: ListView.separated(padding: const EdgeInsets.symmetric(horizontal: 18), scrollDirection: Axis.horizontal, itemCount: _books.length.clamp(0, 16), separatorBuilder: (_, __) => const SizedBox(width: 13), itemBuilder: (context, i) => _StoryPoster(book: _books[i], onTap: () => _openBook(_books[i]))))),
      if (_books.isEmpty && !_busy) const SliverToBoxAdapter(child: Padding(padding: EdgeInsets.all(22), child: Text('Catalogue recommendations will appear here when a connection is available.'))),
      SliverToBoxAdapter(child: Padding(padding: const EdgeInsets.fromLTRB(18, 24, 18, 34), child: Card(child: ListTile(leading: const Icon(Icons.edit_note_rounded, color: Color(0xFFFFA45F), size: 30), title: const Text('Your story starts here', style: TextStyle(fontWeight: FontWeight.w800)), subtitle: const Text('Open Author Studio and build a world of your own.'), trailing: const Icon(Icons.arrow_forward_ios_rounded, size: 15), onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const CreateScreen())))))),
    ]));
  }
}

Widget _shelfHeading(BuildContext context, String title, {String? action, VoidCallback? onTap}) => SliverPadding(padding: const EdgeInsets.fromLTRB(20, 22, 14, 11), sliver: SliverToBoxAdapter(child: Row(children: [Expanded(child: Text(title, style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w900))), if (action != null) TextButton(onPressed: onTap, child: Text(action))])));

class _FeaturedStory extends StatelessWidget {
  final StoryBook book; final VoidCallback onTap;
  const _FeaturedStory({required this.book, required this.onTap});
  @override Widget build(BuildContext context) => InkWell(onTap: onTap, borderRadius: BorderRadius.circular(23), child: Container(height: 220, clipBehavior: Clip.antiAlias, decoration: BoxDecoration(borderRadius: BorderRadius.circular(23), gradient: const LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight, colors: [Color(0xFF183D59), Color(0xFF0A1727), Color(0xFF342A38)])), child: Stack(children: [
    Positioned(right: 0, top: 0, bottom: 0, width: 155, child: _CoverImage(url: book.coverUrl, radius: 0)),
    Positioned.fill(child: DecoratedBox(decoration: BoxDecoration(gradient: LinearGradient(colors: [const Color(0xFF0A1727).withValues(alpha: .98), const Color(0xFF0A1727).withValues(alpha: .75), Colors.transparent], begin: Alignment.centerLeft, end: Alignment.centerRight)))),
    Positioned(left: 18, top: 18, child: Container(padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6), decoration: BoxDecoration(color: const Color(0xFFFF914D), borderRadius: BorderRadius.circular(20)), child: const Text('✦ FEATURED STORY', style: TextStyle(color: Color(0xFF17202B), fontSize: 9, fontWeight: FontWeight.w900, letterSpacing: 1)))),
    Positioned(left: 18, bottom: 19, width: 205, child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisSize: MainAxisSize.min, children: [Text(book.title, maxLines: 3, overflow: TextOverflow.ellipsis, style: const TextStyle(color: Colors.white, fontSize: 21, fontWeight: FontWeight.w900, height: 1.08)), const SizedBox(height: 5), Text(book.author, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: Colors.white70, fontSize: 10)), const SizedBox(height: 12), const Row(children: [Icon(Icons.play_circle_fill_rounded, color: Color(0xFFFF914D), size: 24), SizedBox(width: 6), Text('Explore story', style: TextStyle(color: Colors.white, fontSize: 11, fontWeight: FontWeight.bold))])])),
  ])));
}

class _StoryPoster extends StatelessWidget {
  final StoryBook book; final VoidCallback onTap;
  const _StoryPoster({required this.book, required this.onTap});
  @override Widget build(BuildContext context) => SizedBox(width: 116, child: InkWell(onTap: onTap, child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Expanded(child: _CoverImage(url: book.coverUrl)), const SizedBox(height: 7), Text(book.title, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w800)), Text(book.author, maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(fontSize: 9, color: Theme.of(context).colorScheme.onSurfaceVariant))])));
}

class _CoverImage extends StatelessWidget {
  final String url; final double radius;
  const _CoverImage({required this.url, this.radius = 10});
  @override Widget build(BuildContext context) => ClipRRect(borderRadius: BorderRadius.circular(radius), child: Container(color: Theme.of(context).colorScheme.surfaceContainerHighest, child: url.isEmpty ? const Center(child: Icon(Icons.auto_stories_rounded, size: 38)) : Image.network(url.replaceFirst('http://', 'https://'), fit: BoxFit.cover, width: double.infinity, height: double.infinity, loadingBuilder: (c, child, progress) => progress == null ? child : const Center(child: SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2))), errorBuilder: (_, __, ___) => const Center(child: Icon(Icons.auto_stories_rounded, size: 38)))));
}

class ComicsScreen extends StatefulWidget {
  const ComicsScreen({super.key});
  @override State<ComicsScreen> createState() => _ComicsScreenState();
}
class _ComicsScreenState extends State<ComicsScreen> {
  final _controller = TextEditingController(); List<StoryBook> _items = []; bool _busy = true; String? _error; String _genre = 'All';
  @override void initState() { super.initState(); _load(); }
  Future<void> _load() async { setState(() { _busy = true; _error = null; }); try { final q = _genre == 'All' ? 'subject:comics' : (_genre == 'Manga' ? 'manga' : '$_genre comics graphic novels'); final rows = await BookCatalogueService.instance.searchGoogle(q); if (mounted) setState(() => _items = rows); } catch (_) { if (mounted) setState(() => _error = 'Comics catalogue could not load. Check your internet connection and try again.'); } finally { if (mounted) setState(() => _busy = false); } }
  @override void dispose() { _controller.dispose(); super.dispose(); }
  @override Widget build(BuildContext context) => Scaffold(appBar: AppBar(title: const Text('Comics & Graphic Stories', style: TextStyle(fontWeight: FontWeight.w900)), actions: [IconButton(onPressed: _load, icon: const Icon(Icons.refresh_rounded))]), body: CustomScrollView(slivers: [SliverPadding(padding: const EdgeInsets.fromLTRB(18, 4, 18, 16), sliver: SliverToBoxAdapter(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [const Text('A UNIVERSE IN EVERY PANEL', style: TextStyle(color: Color(0xFFFF914D), fontSize: 10, letterSpacing: 1.8, fontWeight: FontWeight.w900)), const SizedBox(height: 5), const Text('Comics, manga & more.', style: TextStyle(fontSize: 24, fontWeight: FontWeight.w900)), const SizedBox(height: 13), TextField(controller: _controller, onSubmitted: (v) { _genre = 'All'; _search(v); }, decoration: InputDecoration(hintText: 'Search comics, characters or creators', prefixIcon: const Icon(Icons.search), suffixIcon: IconButton(onPressed: () => _search(_controller.text), icon: const Icon(Icons.arrow_forward_rounded)))), const SizedBox(height: 12), Wrap(spacing: 7, children: ['All', 'Manga', 'Superhero', 'Fantasy', 'Graphic novels'].map((g) => ChoiceChip(label: Text(g), selected: _genre == g, onSelected: (_) { setState(() => _genre = g); _load(); })).toList())]))), if (_busy) const SliverFillRemaining(child: Center(child: CircularProgressIndicator())) else if (_error != null) SliverFillRemaining(child: Center(child: Padding(padding: const EdgeInsets.all(24), child: Text(_error!, textAlign: TextAlign.center)))) else if (_items.isEmpty) const SliverFillRemaining(child: Center(child: Text('No matching comics found. Try another search.'))) else SliverPadding(padding: const EdgeInsets.fromLTRB(16, 0, 16, 30), sliver: SliverGrid(delegate: SliverChildBuilderDelegate((context, i) { final b = _items[i]; return InkWell(onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => CatalogueBookDetail(book: b))), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Expanded(child: _CoverImage(url: b.coverUrl)), const SizedBox(height: 6), Text(b.title, maxLines: 2, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 11)), Text(b.author, maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(color: Theme.of(context).colorScheme.onSurfaceVariant, fontSize: 9))])); }, childCount: _items.length), gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 3, crossAxisSpacing: 12, mainAxisSpacing: 14, childAspectRatio: .58))) ]));
  Future<void> _search(String q) async { if (q.trim().isEmpty) return; setState(() { _busy = true; _error = null; }); try { final rows = await BookCatalogueService.instance.searchGoogle(q); if (mounted) setState(() => _items = rows); } catch (_) { if (mounted) setState(() => _error = 'Search failed. Please try again.'); } finally { if (mounted) setState(() => _busy = false); } }
}

class WorkingLibraryScreen extends StatefulWidget {
  const WorkingLibraryScreen({super.key});
  @override State<WorkingLibraryScreen> createState() => _WorkingLibraryScreenState();
}

class _WorkingLibraryScreenState extends State<WorkingLibraryScreen> {
  List<Map<String, Object?>> _books = [];
  bool _loading = true;
  String _query = '';
  String _filter = 'All';

  @override void initState() { super.initState(); _load(); }
  Future<void> _load() async {
    setState(() => _loading = true);
    try { final rows = await LocalBookRepository.instance.books(); if (mounted) setState(() => _books = rows); }
    catch (e) { if (mounted) _toast('Could not load your library: $e'); }
    finally { if (mounted) setState(() => _loading = false); }
  }
  void _toast(String value) => ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(value)));
  Future<void> _import() async {
    try { final row = await LocalBookRepository.instance.importBook(); if (row == null) return; await _load(); if (!mounted) return; Navigator.push(context, MaterialPageRoute(builder: (_) => ImportedBookReader(book: row))); }
    catch (e) { _toast('Import failed: $e'); }
  }
  List<Map<String, Object?>> get _visible => _books.where((b) {
    final matches = '${b['title']} ${b['author']}'.toLowerCase().contains(_query.toLowerCase());
    final format = '${b['format']}';
    final type = _filter == 'All' || (_filter == 'Favourites' && b['is_favorite'] == 1) || format == _filter;
    return matches && type;
  }).toList();

  @override Widget build(BuildContext context) {
    final visible = _visible;
    final favs = _books.where((b) => b['is_favorite'] == 1).length;
    return Scaffold(floatingActionButton: FloatingActionButton.extended(onPressed: _import, icon: const Icon(Icons.add_rounded), label: const Text('Import book')),
      body: RefreshIndicator(onRefresh: _load, child: CustomScrollView(slivers: [
        SliverPadding(padding: const EdgeInsets.fromLTRB(20, 22, 20, 12), sliver: SliverToBoxAdapter(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [const Expanded(child: Text('YOUR READING SPACE', style: TextStyle(color: Color(0xFF55C9F2), fontSize: 10, letterSpacing: 2, fontWeight: FontWeight.w900))), IconButton(onPressed: _load, icon: const Icon(Icons.sync_rounded))]),
          const Text('The Library', style: TextStyle(fontSize: 29, fontWeight: FontWeight.w900)),
          const SizedBox(height: 4), Text('Your books, saved and ready whenever you are.', style: TextStyle(color: Theme.of(context).colorScheme.onSurfaceVariant, fontSize: 12)),
          const SizedBox(height: 16),
          Container(padding: const EdgeInsets.symmetric(vertical: 13, horizontal: 8), decoration: BoxDecoration(color: Theme.of(context).colorScheme.surfaceContainer, borderRadius: BorderRadius.circular(17), border: Border.all(color: Theme.of(context).dividerColor.withValues(alpha: .18))), child: Row(children: [
            _LibraryStat(icon: Icons.bookmark_rounded, value: '${_books.length}', label: 'Saved'),
            _LibraryStat(icon: Icons.favorite_rounded, value: '$favs', label: 'Favourites'),
            _LibraryStat(icon: Icons.download_done_rounded, value: '${_books.length}', label: 'On device'),
          ])),
          const SizedBox(height: 15),
          TextField(onChanged: (v) => setState(() => _query = v), decoration: InputDecoration(hintText: 'Search your books', prefixIcon: const Icon(Icons.search_rounded), filled: true, border: OutlineInputBorder(borderRadius: BorderRadius.circular(15), borderSide: BorderSide.none))),
          const SizedBox(height: 12),
          SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            child: Row(
              children: ['All', 'Favourites', 'EPUB', 'PDF', 'TXT']
                  .map((v) => Padding(
                        padding: const EdgeInsets.only(right: 7),
                        child: ChoiceChip(
                          label: Text(v),
                          selected: _filter == v,
                          onSelected: (_) => setState(() => _filter = v),
                        ),
                      ))
                  .toList(),
            ),
          ),
          const SizedBox(height: 8),
          Row(children: [const Expanded(child: Text('My collection', style: TextStyle(fontSize: 17, fontWeight: FontWeight.w900))), Text('${visible.length} books', style: TextStyle(color: Theme.of(context).colorScheme.onSurfaceVariant, fontSize: 11))]),
        ]))),
        if (_loading) const SliverFillRemaining(child: Center(child: CircularProgressIndicator()))
        else if (visible.isEmpty) SliverFillRemaining(hasScrollBody: false, child: Center(child: Padding(padding: const EdgeInsets.all(30), child: Column(mainAxisSize: MainAxisSize.min, children: [Icon(Icons.auto_stories_outlined, size: 52, color: Theme.of(context).colorScheme.primary), const SizedBox(height: 12), Text(_books.isEmpty ? 'Your library is waiting for its first story.' : 'No books match this filter.', textAlign: TextAlign.center, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 16)), const SizedBox(height: 8), const Text('Import an EPUB, PDF or TXT file from your phone to read offline.', textAlign: TextAlign.center)]))))
        else SliverPadding(padding: const EdgeInsets.fromLTRB(16, 3, 16, 100), sliver: SliverList(delegate: SliverChildBuilderDelegate((context, i) {
          final b = visible[i]; final format = '${b['format']}';
          return Card(margin: const EdgeInsets.only(bottom: 10), child: InkWell(borderRadius: BorderRadius.circular(17), onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => ImportedBookReader(book: b))).then((_) => _load()), child: Padding(padding: const EdgeInsets.all(10), child: Row(children: [
            Container(width: 67, height: 91, decoration: BoxDecoration(borderRadius: BorderRadius.circular(9), gradient: LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight, colors: format == 'PDF' ? const [Color(0xFFB65C52), Color(0xFF512B3A)] : format == 'EPUB' ? const [Color(0xFF277D9C), Color(0xFF142D4A)] : const [Color(0xFF99714D), Color(0xFF49364A)])), child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [const Icon(Icons.auto_stories_rounded, color: Colors.white, size: 26), const SizedBox(height: 5), Text(format, style: const TextStyle(color: Colors.white, fontSize: 9, fontWeight: FontWeight.w900, letterSpacing: 1))])),
            const SizedBox(width: 12), Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('${b['title']}', maxLines: 2, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w900)), const SizedBox(height: 4), Text('${b['author']}', maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(color: Theme.of(context).colorScheme.onSurfaceVariant, fontSize: 10)), const SizedBox(height: 8), Text('Imported · Available offline', style: TextStyle(color: Theme.of(context).colorScheme.primary, fontSize: 9, fontWeight: FontWeight.w700))])),
            IconButton(onPressed: () async { await LocalBookRepository.instance.toggleFavorite('${b['id']}', b['is_favorite'] != 1); _load(); }, icon: Icon(b['is_favorite'] == 1 ? Icons.favorite_rounded : Icons.favorite_border_rounded, color: b['is_favorite'] == 1 ? const Color(0xFFFF914D) : null)),
            PopupMenuButton<String>(onSelected: (v) async { if (v == 'delete') { final ok = await showDialog<bool>(context: context, builder: (c) => AlertDialog(title: const Text('Remove book?'), content: const Text('This removes the imported copy from StoryVerse.'), actions: [TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('Cancel')), FilledButton(onPressed: () => Navigator.pop(c, true), child: const Text('Remove'))])); if (ok == true) { await LocalBookRepository.instance.remove('${b['id']}', '${b['path']}'); _load(); } } }, itemBuilder: (_) => const [PopupMenuItem(value: 'delete', child: Text('Remove book'))]),
          ]))));
        }, childCount: visible.length))),
      ])));
  }
}

class _LibraryStat extends StatelessWidget {
  final IconData icon; final String value, label;
  const _LibraryStat({required this.icon, required this.value, required this.label});
  @override Widget build(BuildContext context) => Expanded(child: Column(children: [Icon(icon, color: Theme.of(context).colorScheme.secondary, size: 18), const SizedBox(height: 4), Text(value, style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 16)), Text(label, style: TextStyle(color: Theme.of(context).colorScheme.onSurfaceVariant, fontSize: 9))]));
}

class WorkingDiscoverScreen extends StatefulWidget {
  const WorkingDiscoverScreen({super.key});
  @override State<WorkingDiscoverScreen> createState() => _WorkingDiscoverScreenState();
}
class _WorkingDiscoverScreenState extends State<WorkingDiscoverScreen> {
  final _search = TextEditingController();
  List<StoryBook> _results = [];
  bool _busy = true;
  String? _error;
  String _source = 'Public-domain books';
  String _category = 'For you';

  @override void initState() { super.initState(); _find(); }
  @override void dispose() { _search.dispose(); super.dispose(); }

  Future<void> _find() async {
    setState(() { _busy = true; _error = null; });
    try {
      final q = _search.text.trim().isNotEmpty ? _search.text.trim() : (_category == 'For you' ? '' : _category.toLowerCase());
      final rows = _source == 'Public-domain books'
          ? await BookCatalogueService.instance.searchPublicDomain(q)
          : await BookCatalogueService.instance.searchGoogle(q.isEmpty ? 'subject:fiction' : q);
      if (mounted) setState(() => _results = rows);
    } catch (_) { if (mounted) setState(() => _error = 'The catalogue could not be reached. Check your connection and try again.'); }
    finally { if (mounted) setState(() => _busy = false); }
  }

  @override Widget build(BuildContext context) => CustomScrollView(slivers: [
    SliverPadding(padding: const EdgeInsets.fromLTRB(18, 20, 18, 12), sliver: SliverToBoxAdapter(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Row(children: [
        const Expanded(
          child: Text(
            'EXPLORE YOUR NEXT OBSESSION',
            style: TextStyle(
              color: Color(0xFFFF914D),
              fontSize: 9,
              letterSpacing: 1.7,
              fontWeight: FontWeight.w900,
            ),
          ),
        ),
        IconButton(
          onPressed: () => Navigator.push(
            context,
            MaterialPageRoute(builder: (_) => const ComicsScreen()),
          ),
          icon: const Icon(Icons.auto_awesome_mosaic_rounded),
        ),
      ]),
      const Text('Discover', style: TextStyle(fontSize: 29, fontWeight: FontWeight.w900)),
      const SizedBox(height: 4), Text('Stories from real catalogues, ready to explore.', style: TextStyle(color: Theme.of(context).colorScheme.onSurfaceVariant, fontSize: 11)),
      const SizedBox(height: 14),
      TextField(controller: _search, onSubmitted: (_) => _find(), decoration: InputDecoration(hintText: 'Search title, author or keyword', prefixIcon: const Icon(Icons.search_rounded), suffixIcon: IconButton(onPressed: _find, icon: const Icon(Icons.arrow_forward_rounded)), border: OutlineInputBorder(borderRadius: BorderRadius.circular(15)))),
      const SizedBox(height: 11),
      SingleChildScrollView(
        scrollDirection: Axis.horizontal,
        child: Row(
          children: [
            'For you', 'Adventure', 'Fantasy', 'Mystery',
            'Romance', 'Science fiction', 'History'
          ].map((v) => Padding(
            padding: const EdgeInsets.only(right: 7),
            child: ChoiceChip(
              label: Text(v),
              selected: _category == v,
              onSelected: (_) {
                setState(() {
                  _category = v;
                  _search.clear();
                });
                _find();
              },
            ),
          )).toList(),
        ),
      ),
      const SizedBox(height: 10),
      DropdownButtonFormField<String>(value: _source, items: const [DropdownMenuItem(value: 'Public-domain books', child: Text('Public-domain books · Gutenberg')), DropdownMenuItem(value: 'Worldwide catalogue', child: Text('Worldwide catalogue · Google Books'))], onChanged: (v) { if (v != null) { setState(() => _source = v); _find(); } }, decoration: const InputDecoration(prefixIcon: Icon(Icons.collections_bookmark_rounded), border: OutlineInputBorder())),
      const SizedBox(height: 10),
      SizedBox(width: double.infinity, child: OutlinedButton.icon(onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const ComicsScreen())), icon: const Icon(Icons.auto_awesome_mosaic_rounded), label: const Text('Explore dedicated Comics & Manga'))),
      Row(children: [const Expanded(child: Text('Picked for your next read', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w900))), Text('${_results.length} titles', style: TextStyle(color: Theme.of(context).colorScheme.onSurfaceVariant, fontSize: 10))]),
    ]))),
    if (_busy) const SliverToBoxAdapter(child: LinearProgressIndicator(minHeight: 2))
    else if (_error != null) SliverFillRemaining(hasScrollBody: false, child: Center(child: Padding(padding: const EdgeInsets.all(25), child: Text(_error!, textAlign: TextAlign.center))))
    else if (_results.isEmpty) const SliverFillRemaining(hasScrollBody: false, child: Center(child: Text('No titles found. Try another search.')))
    else SliverPadding(padding: const EdgeInsets.fromLTRB(16, 8, 16, 30), sliver: SliverGrid(delegate: SliverChildBuilderDelegate((context, i) { final b = _results[i]; return InkWell(onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => CatalogueBookDetail(book: b))), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Expanded(child: _CoverImage(url: b.coverUrl)), const SizedBox(height: 6), Text(b.title, maxLines: 2, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 11)), Text(b.author, maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(color: Theme.of(context).colorScheme.onSurfaceVariant, fontSize: 9))])); }, childCount: _results.length), gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 3, crossAxisSpacing: 12, mainAxisSpacing: 14, childAspectRatio: .58))),
  ]);
}

class CatalogueBookDetail extends StatelessWidget{final StoryBook book;const CatalogueBookDetail({super.key,required this.book});@override Widget build(BuildContext context)=>Scaffold(appBar:AppBar(title:const Text('Book details')),body:ListView(padding:const EdgeInsets.all(22),children:[Center(child:Container(width:150,height:220,decoration:BoxDecoration(borderRadius:BorderRadius.circular(9),boxShadow:[BoxShadow(color:Colors.black.withValues(alpha:.2),blurRadius:16)]),clipBehavior:Clip.antiAlias,child:book.coverUrl.isEmpty?const ColoredBox(color:Colors.black12,child:Icon(Icons.menu_book,size:60)):Image.network(book.coverUrl,fit:BoxFit.cover,errorBuilder:(_,__,___)=>const Icon(Icons.menu_book,size:60)))),const SizedBox(height:22),Text(book.title,style:const TextStyle(fontSize:25,fontWeight:FontWeight.w800)),Text(book.author,style:TextStyle(color:Theme.of(context).colorScheme.onSurfaceVariant)),const SizedBox(height:14),Text(book.description,style:const TextStyle(height:1.6)),const SizedBox(height:16),Text('Source: ${book.source}'),Text(book.fullTextAvailable?'Full-text link supplied by source. Check local rights and source terms.':'This record does not include a full-text download.'),const SizedBox(height:18),if(book.fullTextAvailable)FilledButton.icon(onPressed:()=>_download(context),icon:const Icon(Icons.download),label:const Text('Download full text')) else if(book.previewUrl!=null)OutlinedButton.icon(onPressed:()=>_open(context,book.previewUrl!),icon:const Icon(Icons.open_in_new),label:const Text('Open preview')) else if(book.purchaseUrl!=null)OutlinedButton.icon(onPressed:()=>_open(context,book.purchaseUrl!),icon:const Icon(Icons.shopping_bag_outlined),label:const Text('Purchase / access'))]));
 Future<void> _download(BuildContext context)async{try{final uri=Uri.parse(book.fullTextUrl!);final response=await http.get(uri).timeout(const Duration(seconds:35));if(response.statusCode!=200)throw Exception('Download failed (${response.statusCode}).');final path=uri.path.toLowerCase();final ext=path.endsWith('.epub')?'epub':path.endsWith('.pdf')?'pdf':'txt';await LocalBookRepository.instance.importBytes(title:book.title,author:book.author,bytes:response.bodyBytes,extension:ext);if(context.mounted){ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('Book downloaded to your Library.')));Navigator.pop(context);}}catch(e){if(context.mounted)ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text('Could not download this book: $e')));}}
 void _open(BuildContext c,String url)async{try{final ok=await launchUrl(Uri.parse(url),mode:LaunchMode.externalApplication);if(!ok)throw Exception('Link could not be opened.');}catch(e){if(c.mounted)ScaffoldMessenger.of(c).showSnackBar(SnackBar(content:Text('$e')));}}
}

class ImportedBookReader extends StatefulWidget{final Map<String,Object?> book;const ImportedBookReader({super.key,required this.book});@override State<ImportedBookReader> createState()=>_ImportedBookReaderState();}
class _ImportedBookReaderState extends State<ImportedBookReader>{String? _text;String? _error;bool _loading=true;double _font=19;int _position=0;final _scroll=ScrollController();
 @override void initState(){super.initState();_load();}
 Future<void> _load()async{try{final path='${widget.book['path']}';final ext='${widget.book['format']}';final file=File(path);if(!await file.exists())throw Exception('The imported file is missing.');_position=(widget.book['last_position'] as int?)??0;String text;if(ext=='TXT'){text=await file.readAsString();}else if(ext=='EPUB'){text=EpubTextExtractor.extract(await file.readAsBytes());}else{text='';}if(mounted)setState(()=>_text=text);if(ext!='PDF'&&_position>0){WidgetsBinding.instance.addPostFrameCallback((_){if(mounted&&_scroll.hasClients)_scroll.jumpTo(_position.toDouble().clamp(0,_scroll.position.maxScrollExtent).toDouble());});}if(ext=='PDF'&&mounted){setState(()=>_loading=false);return;} }catch(e){_error=e.toString();}finally{if(mounted)setState(()=>_loading=false);}}
 Future<void> _bookmark()async{await LocalBookRepository.instance.addBookmark('${widget.book['id']}','Position $_position',_position);if(mounted)ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('Bookmark saved.')));}
 @override void dispose(){_scroll.dispose();super.dispose();}
 Future<void> _lookup(String word)async{try{final r=await http.get(Uri.https('api.dictionaryapi.dev','/api/v2/entries/en/${Uri.encodeComponent(word)}')).timeout(const Duration(seconds:8));String definition='No definition found.';if(r.statusCode==200){final data=jsonDecode(r.body) as List;definition=(((data.first['meanings'] as List).first['definitions'] as List).first['definition']).toString();}if(!mounted)return;showModalBottomSheet(context:context,showDragHandle:true,builder:(_)=>Padding(padding:const EdgeInsets.all(22),child:Column(mainAxisSize:MainAxisSize.min,crossAxisAlignment:CrossAxisAlignment.start,children:[Text(word,style:const TextStyle(fontSize:22,fontWeight:FontWeight.bold)),const SizedBox(height:9),Text(definition,style:const TextStyle(height:1.5)),const SizedBox(height:18),FilledButton(onPressed:()async{final db=await StoryVerseDatabase.instance.database;await db.insert('vocabulary',{'id':'${DateTime.now().microsecondsSinceEpoch}','word':word,'definition':definition,'book_id':widget.book['id'],'context':'${widget.book['title']}','created_at':DateTime.now().toUtc().toIso8601String()});if(mounted)Navigator.pop(context);},child:const Text('Save to vocabulary'))])));}catch(_){if(mounted)ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('Dictionary lookup failed. Check your internet connection.')));}}
 @override Widget build(BuildContext context){final ext='${widget.book['format']}';return Scaffold(backgroundColor:const Color(0xFFF3EDE2),appBar:AppBar(backgroundColor:const Color(0xFFF3EDE2),foregroundColor:const Color(0xFF28231E),title:Text('${widget.book['title']}',maxLines:1,overflow:TextOverflow.ellipsis,style:const TextStyle(fontSize:15)),actions:[IconButton(onPressed:_bookmark,icon:const Icon(Icons.bookmark_add_outlined)),PopupMenuButton<String>(onSelected:(v){if(v=='larger')setState(()=>_font=(_font+1).clamp(14,32).toDouble());if(v=='smaller')setState(()=>_font=(_font-1).clamp(14,32).toDouble());},itemBuilder:(_)=>const [PopupMenuItem(value:'larger',child:Text('Increase text size')),PopupMenuItem(value:'smaller',child:Text('Decrease text size'))])]),body:_loading?const Center(child:CircularProgressIndicator()):_error!=null?Center(child:Text('Could not open book: $_error')):ext=='PDF'?PdfViewer.file('${widget.book['path']}'):_text==null?const Center(child:Text('No readable text found.')):NotificationListener<ScrollNotification>(onNotification:(n){if(n.metrics.axis==Axis.vertical&&n is ScrollEndNotification){_position=n.metrics.pixels.round();LocalBookRepository.instance.savePosition('${widget.book['id']}',_position);}return false;},child:ListView(controller:_scroll,padding:const EdgeInsets.fromLTRB(25,28,25,60),children:[Text('${widget.book['title']}',style:TextStyle(fontFamily:'serif',fontSize:_font+10,fontWeight:FontWeight.bold,color:const Color(0xFF29231D))),const SizedBox(height:25),SelectableText(_text!,onSelectionChanged:(selection,cause){if(cause==SelectionChangedCause.longPress&&selection.start>=0&&selection.end>selection.start){final selected=_text!.substring(selection.start,selection.end).trim();final word=selected.split(RegExp(r'\s+')).first.replaceAll(RegExp(r"[^A-Za-z']"),'');if(word.isNotEmpty)_lookup(word);}},style:TextStyle(fontFamily:'serif',fontSize:_font,height:1.85,color:const Color(0xFF39322B)))])));}

}

import 'dart:convert';
import 'package:http/http.dart' as http;
import 'book_model.dart';

class BookCatalogueService {
  BookCatalogueService._();
  static final instance = BookCatalogueService._();
  final _client = http.Client();

  Future<List<StoryBook>> searchGoogle(String query, {int start = 0}) async {
    final cleanQuery = query.trim().isEmpty ? 'subject:fiction' : query.trim();
    final uri = Uri.https('www.googleapis.com', '/books/v1/volumes', {
      'q': cleanQuery, 'maxResults': '20', 'startIndex': '$start',
      'printType': 'books', 'orderBy': 'relevance'
    });
    try {
      final response = await _client.get(uri, headers: {
        'Accept': 'application/json',
        'User-Agent': 'StoryVerse/0.1 (Android; book discovery)',
      }).timeout(const Duration(seconds: 18));
      if (response.statusCode == 200) {
        final json = jsonDecode(response.body) as Map<String, dynamic>;
        final rows = ((json['items'] as List?) ?? []).whereType<Map>()
            .map((e) => StoryBook.fromGoogle(e.cast<String, dynamic>())).toList();
        if (rows.isNotEmpty) return rows;
      }
    } catch (_) {
      // Try the independent Open Library catalogue below.
    }
    return searchOpenLibrary(cleanQuery);
  }

  Future<List<StoryBook>> searchOpenLibrary(String query) async {
    final uri = Uri.https('openlibrary.org', '/search.json', {
      'q': query, 'limit': '24',
      'fields': 'key,title,author_name,cover_i,first_publish_year'
    });
    final response = await _client.get(uri, headers: {
      'Accept': 'application/json',
      'User-Agent': 'StoryVerse/0.1 (Android; book discovery)',
    }).timeout(const Duration(seconds: 20));
    if (response.statusCode != 200) {
      throw Exception('Book catalogues unavailable (${response.statusCode}).');
    }
    final json = jsonDecode(response.body) as Map<String, dynamic>;
    return ((json['docs'] as List?) ?? []).whereType<Map>()
        .map((e) => StoryBook.fromOpenLibrary(e.cast<String, dynamic>())).toList();
  }

  Future<List<StoryBook>> searchPublicDomain(String query) async {
    final uri = Uri.https('gutendex.com', '/books/', query.trim().isEmpty ? {'sort': 'popular'} : {'search': query.trim()});
    final response = await _client.get(uri, headers: {'Accept': 'application/json', 'User-Agent': 'StoryVerse/0.1 (Android; public-domain book reader)'}).timeout(const Duration(seconds: 18));
    if (response.statusCode != 200) throw Exception('Public-domain catalogue returned ${response.statusCode}.');
    final json = jsonDecode(response.body) as Map<String, dynamic>;
    return ((json['results'] as List?) ?? []).whereType<Map>().map((e) => StoryBook.fromGutendex(e.cast<String, dynamic>())).toList();
  }
}

import 'dart:convert';
import 'package:http/http.dart' as http;
import 'book_model.dart';

class BookCatalogueService {
  BookCatalogueService._();
  static final instance = BookCatalogueService._();
  final _client = http.Client();

  Future<List<StoryBook>> searchGoogle(String query, {int start = 0}) async {
    final uri = Uri.https('www.googleapis.com', '/books/v1/volumes', {
      'q': query.trim().isEmpty ? 'subject:fiction' : query.trim(),
      'maxResults': '20', 'startIndex': '$start', 'printType': 'books', 'orderBy': 'relevance'
    });
    final response = await _client.get(uri, headers: {'Accept': 'application/json'}).timeout(const Duration(seconds: 18));
    if (response.statusCode != 200) throw Exception('Book catalogue returned ${response.statusCode}.');
    final json = jsonDecode(response.body) as Map<String, dynamic>;
    return ((json['items'] as List?) ?? []).whereType<Map>().map((e) => StoryBook.fromGoogle(e.cast<String, dynamic>())).toList();
  }

  Future<List<StoryBook>> searchPublicDomain(String query) async {
    final uri = Uri.https('gutendex.com', '/books/', query.trim().isEmpty ? {'sort': 'popular'} : {'search': query.trim()});
    final response = await _client.get(uri, headers: {'Accept': 'application/json'}).timeout(const Duration(seconds: 18));
    if (response.statusCode != 200) throw Exception('Public-domain catalogue returned ${response.statusCode}.');
    final json = jsonDecode(response.body) as Map<String, dynamic>;
    return ((json['results'] as List?) ?? []).whereType<Map>().map((e) => StoryBook.fromGutendex(e.cast<String, dynamic>())).toList();
  }
}

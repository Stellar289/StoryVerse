import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../navigation/main_navigation.dart';
import '../features/visual_experience.dart';
import 'theme/app_theme.dart';

class StoryVerseApp extends StatefulWidget {
 const StoryVerseApp({super.key});
 @override State<StoryVerseApp> createState()=>_StoryVerseAppState();
}
class _StoryVerseAppState extends State<StoryVerseApp>{
 ThemeMode _themeMode=ThemeMode.dark;bool _introComplete=false;bool _hasSeenIntro=false;
 @override void initState(){super.initState();_restoreSettings();}
 Future<void> _restoreSettings()async{
  final prefs=await SharedPreferences.getInstance();if(!mounted)return;
  setState((){
   _hasSeenIntro=prefs.getBool('storyverse_intro_seen')??false;
   final value=prefs.getString('theme_mode');
   _themeMode=ThemeMode.values.firstWhere((m)=>m.name==value,orElse:()=>ThemeMode.dark);
  });
 }
 void _finishIntro()async{
  final prefs=await SharedPreferences.getInstance();await prefs.setBool('storyverse_intro_seen',true);
  if(mounted)setState(()=>_introComplete=true);
 }
 void _setThemeMode(ThemeMode mode){
  setState(()=>_themeMode=mode);
  SharedPreferences.getInstance().then((prefs)=>prefs.setString('theme_mode',mode.name));
 }
 @override Widget build(BuildContext context)=>MaterialApp(
  title:'StoryVerse',debugShowCheckedModeBanner:false,theme:StoryVerseTheme.light(),
  darkTheme:StoryVerseTheme.dark(),themeMode:_themeMode,
  home:_introComplete?MainNavigation(themeMode:_themeMode,onThemeChanged:_setThemeMode):
   StoryVerseLaunch(key:ValueKey(_hasSeenIntro),showWelcome:!_hasSeenIntro,onFinished:_finishIntro)
 );
}

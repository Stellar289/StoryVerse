import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../features/foundation_screens.dart';
import '../navigation/main_navigation.dart';
import 'theme/app_theme.dart';

class StoryVerseApp extends StatefulWidget {
  const StoryVerseApp({super.key});
  @override
  State<StoryVerseApp> createState() => _StoryVerseAppState();
}

class _StoryVerseAppState extends State<StoryVerseApp> {
  ThemeMode _themeMode = ThemeMode.dark;
  bool _introComplete = false;
  @override
  void initState() { super.initState(); _restoreTheme(); }
  Future<void> _restoreTheme() async {
    final prefs = await SharedPreferences.getInstance();
    final value = prefs.getString('theme_mode');
    if (!mounted || value == null) return;
    setState(() => _themeMode = ThemeMode.values.firstWhere((m) => m.name == value, orElse: () => ThemeMode.dark));
  }
  void _setThemeMode(ThemeMode mode) {
    setState(() => _themeMode = mode);
    SharedPreferences.getInstance().then((prefs) => prefs.setString('theme_mode', mode.name));
  }

  @override
  Widget build(BuildContext context) => MaterialApp(
    title: 'StoryVerse',
    debugShowCheckedModeBanner: false,
    theme: StoryVerseTheme.light(),
    darkTheme: StoryVerseTheme.dark(),
    themeMode: _themeMode,
    home: _introComplete
      ? MainNavigation(themeMode: _themeMode, onThemeChanged: _setThemeMode)
      : StoryVerseIntro(onFinished: () { if (mounted) setState(() => _introComplete = true); }),
  );
}

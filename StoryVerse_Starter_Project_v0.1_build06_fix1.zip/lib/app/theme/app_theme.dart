import 'package:flutter/material.dart';

class StoryVerseTheme {
  static const navy = Color(0xFF071321);
  static const navyRaised = Color(0xFF102338);
  static const cyan = Color(0xFF55C9F2);
  static const orange = Color(0xFFFF914D);
  static const ink = Color(0xFF15243A);

  static ThemeData light() {
    const bg = Color(0xFFF4F7FB);
    const surface = Color(0xFFFFFFFF);
    final scheme = ColorScheme.fromSeed(
      seedColor: const Color(0xFF168FC4),
      brightness: Brightness.light,
      surface: surface,
      primary: const Color(0xFF087FAF),
      secondary: const Color(0xFFF08A3C),
    );
    return ThemeData(
      useMaterial3: true,
      colorScheme: scheme,
      scaffoldBackgroundColor: bg,
      appBarTheme: const AppBarTheme(backgroundColor: bg, elevation: 0, surfaceTintColor: Colors.transparent),
      cardTheme: CardThemeData(color: surface, elevation: 0, surfaceTintColor: Colors.transparent,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20))),
      navigationBarTheme: NavigationBarThemeData(
        height: 70, backgroundColor: surface,
        indicatorColor: const Color(0xFFD9F1FC),
        labelTextStyle: WidgetStateProperty.resolveWith((s) => TextStyle(
          fontSize: 10, fontWeight: s.contains(WidgetState.selected) ? FontWeight.w800 : FontWeight.w500,
          color: s.contains(WidgetState.selected) ? const Color(0xFF087FAF) : const Color(0xFF64748B))),
      ),
      inputDecorationTheme: InputDecorationTheme(
        filled: true, fillColor: const Color(0xFFEAF0F6),
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(15), borderSide: BorderSide.none)),
    );
  }

  static ThemeData dark() {
    final scheme = ColorScheme.fromSeed(
      seedColor: cyan, brightness: Brightness.dark,
      surface: const Color(0xFF0C1B2B),
      primary: cyan, secondary: orange,
    );
    return ThemeData(
      useMaterial3: true,
      colorScheme: scheme,
      scaffoldBackgroundColor: navy,
      appBarTheme: const AppBarTheme(backgroundColor: navy, elevation: 0, surfaceTintColor: Colors.transparent),
      cardTheme: CardThemeData(color: const Color(0xFF102338), elevation: 0,
        surfaceTintColor: Colors.transparent,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20))),
      navigationBarTheme: NavigationBarThemeData(
        height: 70, backgroundColor: const Color(0xFF091827),
        indicatorColor: const Color(0xFF173D55),
        labelTextStyle: WidgetStateProperty.resolveWith((s) => TextStyle(
          fontSize: 10, fontWeight: s.contains(WidgetState.selected) ? FontWeight.w800 : FontWeight.w500,
          color: s.contains(WidgetState.selected) ? orange : const Color(0xFF91A4B8))),
      ),
      inputDecorationTheme: InputDecorationTheme(
        filled: true, fillColor: const Color(0xFF14283B),
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(15), borderSide: BorderSide.none)),
    );
  }
}

import 'package:flutter/material.dart';

class StoryVerseTheme {
  static const _violet = Color(0xFF9B82E8);
  static ThemeData light() {
    final scheme = ColorScheme.fromSeed(seedColor: _violet, brightness: Brightness.light, surface: const Color(0xFFF7F4EF));
    return ThemeData(useMaterial3: true, colorScheme: scheme, scaffoldBackgroundColor: const Color(0xFFF7F4EF),
      appBarTheme: const AppBarTheme(backgroundColor: Color(0xFFF7F4EF), elevation: 0),
      cardTheme: CardThemeData(elevation: 0, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(22))),
      inputDecorationTheme: InputDecorationTheme(filled: true, border: OutlineInputBorder(borderRadius: BorderRadius.circular(15), borderSide: BorderSide.none)));
  }
  static ThemeData dark() {
    final scheme = ColorScheme.fromSeed(seedColor: _violet, brightness: Brightness.dark, surface: const Color(0xFF171822));
    return ThemeData(useMaterial3: true, colorScheme: scheme, scaffoldBackgroundColor: const Color(0xFF101119),
      appBarTheme: const AppBarTheme(backgroundColor: Color(0xFF101119), elevation: 0),
      cardTheme: CardThemeData(elevation: 0, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(22))),
      inputDecorationTheme: InputDecorationTheme(filled: true, border: OutlineInputBorder(borderRadius: BorderRadius.circular(15), borderSide: BorderSide.none)));
  }
}

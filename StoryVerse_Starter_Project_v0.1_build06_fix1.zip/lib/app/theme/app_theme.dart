import 'package:flutter/material.dart';

class StoryVerseTheme {
  static const navy = Color(0xFF102B49);
  static const navyDeep = Color(0xFF08182A);
  static const navyRaised = Color(0xFF183B5D);
  static const cyan = Color(0xFF78D5F1);
  static const orange = Color(0xFFF4A653);
  static const ink = Color(0xFF102B49);

  static ThemeData light() {
    const bg = Color(0xFFF7F9FC);
    const surface = Color(0xFFFFFFFF);
    const blue = Color(0xFF247EAD);
    const orangeLight = Color(0xFFF0A04E);
    final scheme = ColorScheme.fromSeed(seedColor: blue, brightness: Brightness.light,
      surface: surface, primary: blue, secondary: orangeLight);
    return ThemeData(useMaterial3:true,colorScheme:scheme,scaffoldBackgroundColor:bg,
      appBarTheme:const AppBarTheme(backgroundColor:bg,elevation:0,surfaceTintColor:Colors.transparent),
      cardTheme:CardThemeData(color:surface,elevation:0,surfaceTintColor:Colors.transparent,
        shape:RoundedRectangleBorder(borderRadius:BorderRadius.circular(19))),
      navigationBarTheme:NavigationBarThemeData(height:70,backgroundColor:surface,
        indicatorColor:const Color(0xFFDDEFF7),
        labelTextStyle:WidgetStateProperty.resolveWith((s)=>TextStyle(fontSize:10,
          fontWeight:s.contains(WidgetState.selected)?FontWeight.w800:FontWeight.w500,
          color:s.contains(WidgetState.selected)?blue:const Color(0xFF667789)))),
      inputDecorationTheme:InputDecorationTheme(filled:true,fillColor:const Color(0xFFEDF2F6),
        border:OutlineInputBorder(borderRadius:BorderRadius.circular(15),borderSide:BorderSide.none)));
  }
  static ThemeData dark() {
    final scheme=ColorScheme.fromSeed(seedColor:cyan,brightness:Brightness.dark,
      surface:const Color(0xFF122B43),primary:cyan,secondary:orange);
    return ThemeData(useMaterial3:true,colorScheme:scheme,scaffoldBackgroundColor:navyDeep,
      appBarTheme:const AppBarTheme(backgroundColor:navyDeep,elevation:0,surfaceTintColor:Colors.transparent),
      cardTheme:CardThemeData(color:const Color(0xFF122B43),elevation:0,surfaceTintColor:Colors.transparent,
        shape:RoundedRectangleBorder(borderRadius:BorderRadius.circular(19))),
      navigationBarTheme:NavigationBarThemeData(height:70,backgroundColor:const Color(0xFF0A1D31),
        indicatorColor:const Color(0xFF1C4564),
        labelTextStyle:WidgetStateProperty.resolveWith((s)=>TextStyle(fontSize:10,
          fontWeight:s.contains(WidgetState.selected)?FontWeight.w800:FontWeight.w500,
          color:s.contains(WidgetState.selected)?orange:const Color(0xFF9FB2C4)))),
      inputDecorationTheme:InputDecorationTheme(filled:true,fillColor:const Color(0xFF17334D),
        border:OutlineInputBorder(borderRadius:BorderRadius.circular(15),borderSide:BorderSide.none)));
  }
}

# StoryVerse Continuity Record — Build 06

## Product north star
StoryVerse remains a real, local-first reading and authoring app for Android first. It is not intended to be a prototype. The supplied reference video is the primary visual direction, interpreted as original StoryVerse design rather than copied screens or copyrighted cover artwork. Original planned features remain in scope.

## Reference visual direction
- Animated book-cover opening; avoid a blank black startup screen.
- Cinematic dark home with layered real covers, featured content and horizontal shelves.
- Attractive book detail pages and immersive, calm reader.
- Fully designed Light and Dark modes.
- Three distinct environments: Library, Reader and Author Studio.

## Original product requirements retained
- Reading: import EPUB/PDF/TXT, actual book content, offline files, progress, bookmarks, notes, vocabulary, press/hold word lookup, passage explanation, reader customization.
- Discovery: real book metadata/covers, catalogue search, genre discovery, full-text availability labels, legitimate previews and purchase/access routes.
- Author Studio: independent projects; chapters, manuscript editor, characters, worlds, plots, timelines, notes, research, project-scoped search, autosave and later AI assistance.
- Profile: editable personal details/photo, appearance, reading preferences, storage, notifications, privacy/account controls.
- AI-dependent features may be honestly marked Coming Soon; achievable non-AI functions should be implemented and tested.

## Build history
- Build 01: Flutter Material 3 shell, themes and five-tab navigation.
- Build 02: richer foundation screens; multiple controls were placeholders.
- Build 03: SQLite persistence, project creation/list, project workspace, chapters, editor/autosave.
- Build 04: corrected CreateScreen import and generated Android platform files during CI; first APK build succeeded.
- Build 05: cinematic redesign, book-cover animation, curated shelves and demo reader. The catalogue and reader were still demonstration content.
- Build 06: live Gutendex/Google Books catalogue services; working Discover search and details; SQLite-backed local Library; EPUB/PDF/TXT import; TXT/EPUB reader; PDF viewer; long-press dictionary lookup for text reader; vocabulary save; bookmarks; reading-position writes; catalogue download; real public-domain cover art in intro; expanded persistent local Profile preferences.

## Architecture
Flutter UI; SQLite in app documents directory; local files in app documents/books; UUID identifiers; repository/service layers; Gutendex and Google Books catalogue adapters; replaceable dictionary/AI service boundaries. Author records must always remain scoped to their owning project_id. Reading and writing must remain usable without Firebase or an AI provider.

## Build 06 remaining work (priority order)
1. Compile and analyze with GitHub Actions; fix every error before delivering APK.
2. Test real EPUB, PDF and TXT files on Android; verify import, open, close/reopen, storage and deletion.
3. Improve EPUB rendering: table of contents, chapter navigation, typography/images and exact reading-position restoration.
4. Implement PDF text selection, page bookmarks and page-position restoration where supported by the viewer engine.
5. Finish bookmark/vocabulary management screens and passage notes/highlights.
6. Complete Library collections/sorting and download status/error handling.
7. Finish Author Studio characters, worldbuilding, plot/timeline, project search and editor recovery tests.
8. Complete Profile data-management/privacy options; camera capture and authentication only if justified.
9. Integrate AI/cloud features only with clear service/provider boundaries and honest Coming Soon states until available.

## Build 06 verification honesty
Not yet compiled, analyzed, APK-built or device-tested at the time this record was written. Source code presence is not proof of a working feature. Each feature must pass its acceptance test before being marked tested.

## Build 06 Fix 1 — CI corrections (18 November 2026)
The first Build 06 CI run successfully checked out the repository, extracted the ZIP, set up Flutter, generated Android files, and resolved dependencies. It failed at `flutter analyze` due to two uses of the removed `FilePicker.platform` API (file_picker 11 uses static `FilePicker.pickFiles`), malformed syntax in the compressed `WorkingHomeScreen` widget tree, and a generated default widget test referring to `MyApp`. Fix 1 migrates both picker calls to the v11 static API, rewrites the Home screen widget tree in formatted Dart, and supplies a StoryVerse-specific smoke test. These corrections are pending a fresh CI run; compilation and device testing are not yet verified.


## Build 06 Fix 2 — file import API correction (18 November 2026)
The Fix 1 CI run passed checkout, ZIP extraction, Flutter setup, Android platform generation and dependency resolution, but `flutter analyze` stopped on one blocking error: `PlatformFile.readAsBytes()` does not exist in `file_picker` 11.0.3. Fix 2 reads the nullable `PlatformFile.bytes` value (provided because `withData: true` is enabled), with a safe fallback to `File(picked.path).readAsBytes()` when a path is available. It reports a clear import error if neither route yields bytes. The EPUB extractor's unsupported inline regex flags were also replaced with Dart `RegExp` constructor flags (`caseSensitive: false`, `dotAll: true`). Fix 2 is prepared locally; CI and device verification remain pending.


## Build 06 Fix 3 — Android file-picker plugin compatibility (18 November 2026)
The Fix 2 GitHub Actions run passed `flutter analyze` but failed during Android Java compilation: the generated plugin registrant could not find `com.mr.flutter.plugin.filepicker.FilePickerPlugin`. The CI environment uses AGP 9 with `file_picker` 11.0.3; the plugin's documented 11.x Android build issue is fixed in its 12.x federated implementation. Fix 3 upgrades `file_picker` to `^12.0.0` and migrates both picker call sites to the v12 direct `List<PlatformFile>` result. Book import now uses `PlatformFile.readAsBytes()`; profile-photo selection uses the returned file list. This source has not yet been compiled or device-tested; a fresh GitHub Actions run is required.

## Build 07 — Cinematic StoryVerse UI reconstruction (19 November 2026)

### Reference review
- The 95-second walkthrough was reviewed as the functional baseline. It shows the existing app flow across Home, Discover, Author Studio, Library and Profile, including the current sparse Discover results, project-creation landing state, imported-book Library, and Profile preferences.
- The 23-second visual reference was reviewed as the cinematic direction: dark story-streaming presentation, large artwork-led hero, cover shelves, compact navigation and strong visual hierarchy.
- The two supplied static designs add a full-bleed illustrated onboarding composition and a dark navy/cyan/orange streaming-style Discover and Library treatment.

### UI changes assembled
- Reworked Home into an artwork-led StoryVerse landing screen with branded header, search shortcut, featured catalogue story, continue-reading shelf for local imports, dedicated Comics & Graphic Stories entry, public-domain cover shelf and Author Studio entry.
- Added a dedicated Comics & Graphic Stories page with search, genre chips and a responsive three-column cover grid sourced from Google Books metadata.
- Added a direct Comics shortcut from Discover and Home while retaining the five primary destinations: Home, Library, Discover, Create and Profile.
- Added a reusable network cover widget with HTTPS normalization, loading state and a deliberate fallback instead of blank image areas.
- Kept the dark palette in deep navy with cyan and orange accents; light mode remains a deliberately light blue-white surface with blue primary and warm orange secondary accents.
- Existing import, local Library, catalogue details, reader, Author Studio and Profile routes are retained rather than replaced with static mock screens.

### Important limitations and honest status
- This is a UI source revision, not yet a verified release. Flutter formatting, static analysis, APK compilation and physical-device acceptance tests are still required.
- The Comics page uses Google Books catalogue metadata and cover thumbnails. It does not imply that complete comic issues are freely available; preview and purchase/access routes remain governed by each catalogue record.
- Actual cover availability depends on the source catalogue returning a valid image URL and the device having network access. Error and loading fallbacks are present, but image loading must be checked on-device.
- Local imported files currently show a designed format placeholder rather than extracting embedded cover art from EPUB/PDF metadata. Embedded-cover extraction remains a separate reader/library improvement.
- The app walkthrough showed Author Studio sections that are still incomplete; this UI pass preserves the existing authoring foundation but does not claim characters, worldbuilding, timeline, notes and recovery are all finished.
- The Reader still requires device acceptance testing for progress restoration, bookmarks, PDF selection and advanced EPUB rendering. The old demo reader screen remains in the source but is not the local imported-book reader path.

### Next acceptance gate
1. Package this source as Build 07 and upload it to the repository using the workflow's required archive filename.
2. Run GitHub Actions and fix every analyzer or build error.
3. Install the new APK and test Home shelf cover loading, Comics search/genre filters, Discover details, Library import/open/reopen, Create project/chapter autosave and Profile theme persistence.
4. Only mark features tested after they pass on the Android device.
- Continued the Build 07 pass by rebuilding Library as a compact collection dashboard with saved/favourite/on-device counts, search, format/favourite filters, readable imported-book cards, import, favourite toggle, open and remove actions.
- Rebuilt Discover to load catalogue suggestions immediately, show category chips, allow source switching between Gutendex and Google Books, render cover grids, and link directly to the dedicated Comics page.


## Build 07 Fix 2 — catalogue, covers, downloads and Author Studio crash (19 November 2026)

### Device recording inspection
The 82-second Android screen recording shows:
- Home and Discover do return public-domain titles from Gutendex, but the visible shelves render generic book icons because many Gutendex records omit `image/jpeg`.
- The dedicated Comics page displays its catalogue connection error; it is backed only by Google Books, so a failure of that one provider leaves the page empty.
- The Pride and Prejudice detail screen offers a full-text download, but the download request returns HTTP 503 and is not saved to the local Library.
- Opening Author Studio shows a Flutter framework error: `No Material widget found` for a `ListTile` inside `_StudioItem`. The same screen reports a huge bottom overflow as a consequence of the failed layout.

### Source corrections prepared
- Added Project Gutenberg's standard per-book cover endpoint as a fallback when Gutendex omits a cover URL.
- Added Open Library as an independent catalogue fallback when Google Books errors or returns no results. It supplies title/author metadata and cover IDs; it does not claim free full-text availability.
- Added an alternate Gutenberg plain-text URL where both EPUB and text formats are supplied.
- Hardened in-app downloads with a StoryVerse User-Agent, retry for transient server errors, empty-file validation, and alternate-format fallback. HTTP 503 remains an upstream publisher/server failure if all source URLs refuse the request; the app must report that honestly rather than mark a failed download as complete.
- Wrapped Author Studio's `_StudioItem` ListTile in a Card/Material ancestor to remove the missing-Material crash and related overflow.

### Verification status
These are source-level corrections prepared for a new CI run. They have not yet been compiled or device-tested. Acceptance requires: Home/Discover cover art loads; Comics returns actual catalogue records; a Gutenberg title downloads into Library and opens offline; Create screen opens without a Flutter error; and project creation/chapter autosave still work.


## Build 07 — Visual direction update (source implementation prepared)
Reference study:
- The supplied 23-second screen recording begins with a compact animated book-cover mosaic that converges around the StoryVerse identity, then transitions to a dark editorial home screen with horizontal shelves. The later shots show a quiet, dark reading surface with restrained typography and reading controls.
- The COMIX reference uses a large, centre-focused featured carousel with neighbouring covers peeking from behind, then Continue Reading, genre tiles and Popular Now shelves.
- The supplied palette reference calls for sky blue + midnight navy + warm amber in dark mode, and white + blue + orange in light mode.
- StoryVerse uses these interaction patterns as inspiration, not copied branding or copyrighted cover art. No glassmorphism, neon or purple gradient styling.

Implemented in this source pass:
- New Flutter-coded animated opening: cover mosaic converges into the StoryVerse mark; first-run welcome screen follows. Returning users see the short opening and proceed to Home.
- First-run welcome screen has a single Get started action and Continue as guest / Skip path.
- New Discover page with a true layered, centre-focused swipe carousel: the active card sits above partially visible neighbouring cards; swiping promotes the next card into the centre while the previous card moves behind. Includes book search, horizontal story shelves and a route to Comics Universe.
- Dedicated Comics Universe page with its own hero, genre filters and responsive catalogue grid.
- Premium Profile & Settings page with persisted profile name/bio/photo, reading goal, notifications and a single light/dark action button.
- Dark theme changed to midnight navy / sky blue / warm amber; light theme changed to white / blue / orange.
- Home catalogue and local-library loading are now independent so a catalogue network failure does not prevent local books from appearing.
- Home, Discover and Comics use the new colour direction and the new Comics page.

Verification status:
- ZIP source integrity and delimiter-balance checks are performed before delivery.
- Flutter/Dart SDK is not available in the packaging environment; source has not been compiled locally.
- GitHub Actions is configured to run `flutter analyze`, `flutter test`, and `flutter build apk --debug`. A successful CI run is still required before installation.
- Live catalogue results and cover image availability depend on the user's network and third-party APIs. The carousel uses actual catalogue results, not bundled commercial comic artwork.
- Existing deeper Reader annotations, EPUB embedded-cover extraction, complete Author Studio character/world/timeline modules, robust offline catalogue caching and end-to-end device tests remain future milestones.


## Build 10 source repair (2026-11-20)
- Fixed `_FeaturedStoryCard` to accept and forward `super.key`, required by `AnimatedSwitcher` child identity.
- Corrected profile image picker handling for file_picker 12.3.0: `FilePicker.pickFiles` returns a nullable list of `PlatformFile`, so the code now checks `isEmpty` and reads `single.path` directly.
- These changes address the four reported Flutter analyzer errors from GitHub Actions run 44632476382. A new CI run is still required to verify the complete Android build.

import 'package:flutter_test/flutter_test.dart';
import 'package:storyverse/app/storyverse_app.dart';

void main() {
  testWidgets('StoryVerse app starts and shows its intro', (tester) async {
    await tester.pumpWidget(const StoryVerseApp());
    await tester.pump();
    expect(find.text('STORYVERSE'), findsOneWidget);
    expect(find.text('Every cover opens a universe.'), findsOneWidget);
  });
}

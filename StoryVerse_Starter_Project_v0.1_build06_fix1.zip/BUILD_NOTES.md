# StoryVerse Build 06 — Real Catalogue and Local Reading Foundation

## Product direction preserved
This build continues the original StoryVerse plan: a premium, cinematic reading and authoring app. It does not replace or narrow the product vision. The reference video remains the visual direction: animated covers on launch, cinematic home, actual cover art, shelves, book details and an immersive reader.

## Build 06 implementation work
- Replaced the home tab's demonstration catalogue with live public-domain catalogue results from Gutendex, including real title/author metadata and source-provided cover images.
- Added a second catalogue source using Google Books API for broader metadata, previews and legitimate purchase/access links.
- Added live search and source switching on Discover. Book details now distinguish full-text source availability from metadata/preview-only entries.
- Added a real local Library backed by SQLite. Users can import EPUB, PDF and TXT files through Android's document picker, search/filter the collection, mark favourites, remove imported copies, and reopen them.
- Added a local reader path for TXT and EPUB content. EPUB reading extracts text from the package's reading order. PDF opens in the integrated pdfrx viewer.
- Added long-press word selection in the text reader with dictionary lookup and an option to save the word to the vocabulary table.
- Added persistent reading-position storage, bookmark insertion, and adjustable reader text size. (Resume-to-position and bookmark navigation still need completion.)
- Added full-text catalogue download into the local Library where the catalogue provides a direct EPUB/PDF/TXT URL.
- Changed the opening cover animation to use real Project Gutenberg cover images, with an offline gradient fallback.
- Expanded Profile with editable display name and bio, local profile photo selection, persistent theme choice, daily reading goal, notification preference and compact-reader preference.
- Preserved the original five-tab navigation and Author Studio project/chapter architecture.

## Important limitations still outstanding
- The launch covers are real public-domain cover images fetched from Project Gutenberg; a connection is needed to load them. An original fallback renders when images cannot load.
- Google Books records may be metadata or previews only. A catalogue record or cover image is not permission to host a complete book. Only source-provided full-text files, legally public-domain/appropriately licensed works, user imports, or legitimate external access routes may be used.
- The first reader pass extracts EPUB text into a continuous reading view; advanced EPUB layout, images, footnotes, table of contents, typography fidelity and chapter navigation need a dedicated renderer pass.
- PDF text selection/dictionary integration is not yet wired. The PDF viewer is integrated, but PDF-specific text selection, bookmarks and progress restoration require further work.
- TXT/EPUB word lookup uses a public dictionary endpoint and therefore needs internet access. Offline dictionary packs are not included yet.
- Passage explanations, AI story assistant, cloud sync, full account/authentication, recommendations and notifications delivery remain Coming Soon until their service integrations are built.
- Profile picture currently uses the phone file picker/gallery path; camera capture, account sync and cloud backup are not included yet.
- The old sample UI classes remain in the source for reference, but the main Home, Library and Discover navigation tabs now point to the working catalogue/library screens.

## Verification status
This source has not yet been compiled with Flutter or installed/tested on a physical Android device in this session. Do not describe Build 06 as a verified release. The next required gate is GitHub Actions: dependency resolution, `flutter analyze`, and debug APK build. Fix all compile/analyzer errors before APK distribution, then perform the acceptance tests on the user's Android phone.

## Build 06 Fix 1 (18 November 2026)

Corrected issues identified by the first GitHub Actions Build 06 analyzer run:
- Migrated `file_picker` calls to the static API required by file_picker 11.x (`FilePicker.pickFiles`).
- Rebuilt the Home screen widget tree with balanced, readable Dart syntax; the prior compressed expression had unmatched/incorrect widget arguments.
- Added a StoryVerse-specific widget smoke test so Flutter project generation no longer leaves the default `MyApp` test in place.

Verification status: source corrections are prepared, but the revised source still requires a fresh GitHub Actions analyzer/build run. Do not describe this revision as compiled or device-tested until that run succeeds and the APK is installed and exercised.


## Build 06 Fix 2 (18 November 2026)
The latest CI log isolated the remaining blocking analyzer error to `PlatformFile.readAsBytes()` in `local_book_repository.dart`. Replaced it with `PlatformFile.bytes` and a file-path fallback, retaining the existing `withData: true` picker configuration. Also replaced unsupported inline regex modifiers in the EPUB extractor with Dart `RegExp` constructor options. This patch is prepared but has not yet been run through Flutter CI; no APK or device test is claimed.


## Build 06 Fix 3 — Android file-picker plugin compatibility (18 November 2026)
The Fix 2 GitHub Actions run passed `flutter analyze` but failed during Android Java compilation: the generated plugin registrant could not find `com.mr.flutter.plugin.filepicker.FilePickerPlugin`. The CI environment uses AGP 9 with `file_picker` 11.0.3; the plugin's documented 11.x Android build issue is fixed in its 12.x federated implementation. Fix 3 upgrades `file_picker` to `^12.0.0` and migrates both picker call sites to the v12 direct `List<PlatformFile>` result. Book import now uses `PlatformFile.readAsBytes()`; profile-photo selection uses the returned file list. This source has not yet been compiled or device-tested; a fresh GitHub Actions run is required.

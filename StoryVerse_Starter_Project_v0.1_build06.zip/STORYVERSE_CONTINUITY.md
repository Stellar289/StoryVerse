# StoryVerse Continuity Record — Build 06

## Product north star
StoryVerse remains a real, local-first reading and authoring app for Android first. It is not intended to be a prototype. The supplied reference video is the primary visual direction, interpreted as original StoryVerse design rather than copied screens or copyrighted cover artwork. Original planned features remain in scope.

## Reference visual direction
- Animated book-cover opening; avoid a blank black startup screen.
- Cinematic dark home with layered real covers, featured content and horizontal shelves.
- Attractive book detail pages and immersive, calm reader.
- Fully designed Light and Dark modes.
- Three distinct environments: Library, Reader and Author Studio.

## Original product requirements retained
- Reading: import EPUB/PDF/TXT, actual book content, offline files, progress, bookmarks, notes, vocabulary, press/hold word lookup, passage explanation, reader customization.
- Discovery: real book metadata/covers, catalogue search, genre discovery, full-text availability labels, legitimate previews and purchase/access routes.
- Author Studio: independent projects; chapters, manuscript editor, characters, worlds, plots, timelines, notes, research, project-scoped search, autosave and later AI assistance.
- Profile: editable personal details/photo, appearance, reading preferences, storage, notifications, privacy/account controls.
- AI-dependent features may be honestly marked Coming Soon; achievable non-AI functions should be implemented and tested.

## Build history
- Build 01: Flutter Material 3 shell, themes and five-tab navigation.
- Build 02: richer foundation screens; multiple controls were placeholders.
- Build 03: SQLite persistence, project creation/list, project workspace, chapters, editor/autosave.
- Build 04: corrected CreateScreen import and generated Android platform files during CI; first APK build succeeded.
- Build 05: cinematic redesign, book-cover animation, curated shelves and demo reader. The catalogue and reader were still demonstration content.
- Build 06: live Gutendex/Google Books catalogue services; working Discover search and details; SQLite-backed local Library; EPUB/PDF/TXT import; TXT/EPUB reader; PDF viewer; long-press dictionary lookup for text reader; vocabulary save; bookmarks; reading-position writes; catalogue download; real public-domain cover art in intro; expanded persistent local Profile preferences.

## Architecture
Flutter UI; SQLite in app documents directory; local files in app documents/books; UUID identifiers; repository/service layers; Gutendex and Google Books catalogue adapters; replaceable dictionary/AI service boundaries. Author records must always remain scoped to their owning project_id. Reading and writing must remain usable without Firebase or an AI provider.

## Build 06 remaining work (priority order)
1. Compile and analyze with GitHub Actions; fix every error before delivering APK.
2. Test real EPUB, PDF and TXT files on Android; verify import, open, close/reopen, storage and deletion.
3. Improve EPUB rendering: table of contents, chapter navigation, typography/images and exact reading-position restoration.
4. Implement PDF text selection, page bookmarks and page-position restoration where supported by the viewer engine.
5. Finish bookmark/vocabulary management screens and passage notes/highlights.
6. Complete Library collections/sorting and download status/error handling.
7. Finish Author Studio characters, worldbuilding, plot/timeline, project search and editor recovery tests.
8. Complete Profile data-management/privacy options; camera capture and authentication only if justified.
9. Integrate AI/cloud features only with clear service/provider boundaries and honest Coming Soon states until available.

## Build 06 verification honesty
Not yet compiled, analyzed, APK-built or device-tested at the time this record was written. Source code presence is not proof of a working feature. Each feature must pass its acceptance test before being marked tested.

import 'dart:math' as math;
import 'dart:io';
import 'package:file_picker/file_picker.dart';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:flutter/material.dart';
import 'create/author_studio.dart';

const _ink = Color(0xFF10121B);
const _muted = Color(0xFF9CA3B5);

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});
  @override
  Widget build(BuildContext context) {
    final dark = Theme.of(context).brightness == Brightness.dark;
    return CustomScrollView(slivers: [
      SliverPadding(padding: const EdgeInsets.fromLTRB(20, 18, 20, 8), sliver: SliverToBoxAdapter(child: Row(children: [
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text('YOUR STORYVERSE', style: TextStyle(color: Theme.of(context).colorScheme.primary, fontSize: 10, letterSpacing: 2.2, fontWeight: FontWeight.w800)),
          const SizedBox(height: 5), const Text('Good evening, reader.', style: TextStyle(fontSize: 23, fontWeight: FontWeight.w800, letterSpacing: -.6)),
          const SizedBox(height: 3), Text('A new world is only a page away.', style: TextStyle(color: Theme.of(context).colorScheme.onSurfaceVariant, fontSize: 12)),
        ])),
        _CircleAction(icon: Icons.search_rounded, onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const LibraryScreen()))),
        const SizedBox(width: 9), _CircleAction(icon: Icons.notifications_none_rounded, onTap: () => _message(context, 'You are all caught up.')),
      ]))),
      SliverToBoxAdapter(child: SizedBox(height: 248, child: PageView.builder(itemCount: _books.length, controller: PageController(viewportFraction: .88), itemBuilder: (context, i) {
        final b = _books[i];
        return Padding(padding: const EdgeInsets.only(right: 12, top: 10, bottom: 10), child: GestureDetector(onTap: () => _openBook(context, b), child: Container(
          decoration: BoxDecoration(borderRadius: BorderRadius.circular(25), gradient: LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight, colors: [b.colors.first, const Color(0xFF171925), const Color(0xFF101119)]), boxShadow: [BoxShadow(color: b.colors.first.withValues(alpha: .24), blurRadius: 22, offset: const Offset(0, 9))]),
          child: Stack(children: [
            Positioned(right: 12, top: 12, bottom: 12, child: SizedBox(width: 142, child: Transform.rotate(angle: -.055, child: _Cover(b: b)))),
            Positioned(left: 20, top: 22, child: Container(padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 5), decoration: BoxDecoration(color: Colors.white.withValues(alpha: .12), borderRadius: BorderRadius.circular(30)), child: const Text('EDITOR’S PICK', style: TextStyle(color: Colors.white, fontSize: 8, letterSpacing: 1.4, fontWeight: FontWeight.bold)))),
            Positioned(left: 20, bottom: 23, width: 170, child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(b.title, maxLines: 2, style: const TextStyle(color: Colors.white, fontSize: 22, fontWeight: FontWeight.w800, height: 1.05)), const SizedBox(height: 6), Text(b.author, style: const TextStyle(color: Colors.white70, fontSize: 11)), const SizedBox(height: 12), const Row(children: [Text('Explore book', style: TextStyle(color: Color(0xFFE5D8FF), fontSize: 11, fontWeight: FontWeight.w700)), SizedBox(width: 6), Icon(Icons.arrow_forward_rounded, color: Color(0xFFE5D8FF), size: 15)])]))
          ]),
        )));
      }))),
      SliverToBoxAdapter(child: _ShelfHeading(title: 'Top this week', subtitle: 'Stories readers can’t put down', action: 'See all', onTap: () => _message(context, 'More weekly picks are coming.'))),
      SliverToBoxAdapter(child: _HorizontalBooks(items: _books.take(4).toList())),
      SliverToBoxAdapter(child: _CategoryBanner(title: 'Kids Books', count: 'A little magic for young minds', colors: const [Color(0xFF315F62), Color(0xFF172E39)], icon: Icons.auto_awesome_rounded, onTap: () => _message(context, 'Kids Books collection selected.'))),
      SliverToBoxAdapter(child: _ShelfHeading(title: 'Horror & fiction', subtitle: 'For the beautifully restless', action: 'Explore', onTap: () => _message(context, 'Horror & fiction collection selected.'))),
      SliverToBoxAdapter(child: _HorizontalBooks(items: [_books[1], _books[3], _books[4]])),
      SliverToBoxAdapter(child: _ShelfHeading(title: 'New releases', subtitle: 'Fresh pages, new possibilities', action: 'See all', onTap: () => _message(context, 'New releases collection selected.'))),
      SliverToBoxAdapter(child: _HorizontalBooks(items: [_books[2], _books[0], _books[5], _books[4]])),
      SliverToBoxAdapter(child: _CategoryBanner(title: 'Your creative universe', count: 'Build a world. Shape its characters. Tell its story.', colors: const [Color(0xFF55417A), Color(0xFF25213D)], icon: Icons.edit_note_rounded, onTap: () => _message(context, 'Open Create from the navigation bar to start a project.'))),
      SliverToBoxAdapter(child: _ShelfHeading(title: 'Popular reads', subtitle: 'Beloved across StoryVerse', action: 'View all', onTap: () => _message(context, 'Popular reads selected.'))),
      SliverToBoxAdapter(child: _HorizontalBooks(items: _books.reversed.take(4).toList())),
      const SliverToBoxAdapter(child: SizedBox(height: 34)),
    ]);
  }
}

class LibraryScreen extends StatefulWidget { const LibraryScreen({super.key}); @override State<LibraryScreen> createState() => _LibraryScreenState(); }
class _LibraryScreenState extends State<LibraryScreen> {
  String filter = 'All'; String query = '';
  @override Widget build(BuildContext context) {
    final visible = _books.where((b) => (filter == 'All' || b.category == filter) && ('${b.title} ${b.author}'.toLowerCase().contains(query.toLowerCase()))).toList();
    return CustomScrollView(slivers: [
      SliverPadding(padding: const EdgeInsets.fromLTRB(20, 22, 20, 14), sliver: SliverToBoxAdapter(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text('YOUR COLLECTION', style: TextStyle(color: Theme.of(context).colorScheme.primary, fontSize: 10, letterSpacing: 2, fontWeight: FontWeight.bold)), const SizedBox(height: 6), const Text('The Library', style: TextStyle(fontSize: 28, fontWeight: FontWeight.w800)), const SizedBox(height: 5), Text('A home for the worlds you love.', style: TextStyle(color: Theme.of(context).colorScheme.onSurfaceVariant)), const SizedBox(height: 18),
        TextField(onChanged: (v) => setState(() => query = v), decoration: InputDecoration(hintText: 'Search titles or authors', prefixIcon: const Icon(Icons.search), filled: true, fillColor: Theme.of(context).colorScheme.surfaceContainerHighest.withValues(alpha: .5), border: OutlineInputBorder(borderRadius: BorderRadius.circular(16), borderSide: BorderSide.none))), const SizedBox(height: 13),
        SingleChildScrollView(scrollDirection: Axis.horizontal, child: Row(children: ['All','Novel','Thriller','Fantasy','Classic'].map((v) => Padding(padding: const EdgeInsets.only(right: 7), child: ChoiceChip(label: Text(v), selected: filter == v, onSelected: (_) => setState(() => filter = v)))).toList())),
        const SizedBox(height: 12), Row(children: [Text('${visible.length} titles', style: const TextStyle(fontWeight: FontWeight.w700)), const Spacer(), TextButton.icon(onPressed: () => _message(context, 'Book import is being built. EPUB, PDF and TXT support is planned.'), icon: const Icon(Icons.add, size: 18), label: const Text('Import book'))]),
      ]))),
      if (visible.isEmpty) const SliverFillRemaining(child: Center(child: Text('No books match your search.')))
      else SliverPadding(padding: const EdgeInsets.symmetric(horizontal: 20), sliver: SliverGrid(delegate: SliverChildBuilderDelegate((context, i) => GestureDetector(onTap: () => _openBook(context, visible[i]), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Expanded(child: _Cover(b: visible[i])), const SizedBox(height: 8), Text(visible[i].title, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 12)), Text(visible[i].author, maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(color: Theme.of(context).colorScheme.onSurfaceVariant, fontSize: 10))])), childCount: visible.length), gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 2, childAspectRatio: .62, crossAxisSpacing: 15, mainAxisSpacing: 17))),
      const SliverToBoxAdapter(child: SizedBox(height: 30)),
    ]);
  }
}

class DiscoverScreen extends StatelessWidget { const DiscoverScreen({super.key}); @override Widget build(BuildContext context) => CustomScrollView(slivers: [SliverPadding(padding: const EdgeInsets.fromLTRB(20,22,20,12), sliver: SliverToBoxAdapter(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('FIND YOUR NEXT WORLD', style: TextStyle(color: Theme.of(context).colorScheme.primary, fontSize: 10, letterSpacing: 2, fontWeight: FontWeight.bold)), const SizedBox(height: 7), const Text('Discover', style: TextStyle(fontSize: 29, fontWeight: FontWeight.w800)), const SizedBox(height: 5), Text('Explore stories and trusted open libraries.', style: TextStyle(color: Theme.of(context).colorScheme.onSurfaceVariant))]))), SliverPadding(padding: const EdgeInsets.symmetric(horizontal: 20), sliver: SliverList(delegate: SliverChildListDelegate([
  _CategoryBanner(title:'Public-domain classics', count:'Timeless books you can read legally for free', colors:const [Color(0xFF76543B),Color(0xFF30241F)], icon:Icons.account_balance_rounded, onTap:()=>_message(context,'Public-domain catalogue connection is planned.')),
  _CategoryBanner(title:'Novels & novellas', count:'Find your next long read', colors:const [Color(0xFF37577A),Color(0xFF1D263A)], icon:Icons.menu_book_rounded, onTap:()=>_message(context,'Novel discovery selected.')),
  _CategoryBanner(title:'Comics & graphic stories', count:'Visual storytelling from trusted sources', colors:const [Color(0xFF73506C),Color(0xFF2A2035)], icon:Icons.draw_rounded, onTap:()=>_message(context,'Comics discovery selected.')),
  _CategoryBanner(title:'Open libraries', count:'Explore legitimate digital collections', colors:const [Color(0xFF38675D),Color(0xFF1C2D2B)], icon:Icons.public_rounded, onTap:()=>_message(context,'Open library integrations are planned.')),
  const SizedBox(height:30),
])))]); }

class ProfileScreen extends StatefulWidget {
  final ThemeMode themeMode;
  final ValueChanged<ThemeMode> onThemeChanged;
  const ProfileScreen({super.key, required this.themeMode, required this.onThemeChanged});
  @override State<ProfileScreen> createState() => _ProfileScreenState();
}
class _ProfileScreenState extends State<ProfileScreen> {
  String _name = 'Your StoryVerse';
  String _bio = 'Reader · Creator · Dreamer';
  String? _photo;
  int _dailyGoal = 30;
  bool _notifications = true;
  bool _compactReader = false;
  bool _loaded = false;
  @override void initState() { super.initState(); _load(); }
  Future<void> _load() async {
    final p = await SharedPreferences.getInstance();
    if (!mounted) return;
    setState(() { _name=p.getString('profile_name')??_name; _bio=p.getString('profile_bio')??_bio; _photo=p.getString('profile_photo'); _dailyGoal=p.getInt('daily_reading_goal')??30; _notifications=p.getBool('notifications_enabled')??true; _compactReader=p.getBool('compact_reader')??false; _loaded=true; });
  }
  Future<void> _edit(String key, String title, String initial) async {
    final controller=TextEditingController(text:initial);
    final value=await showDialog<String>(context:context,builder:(c)=>AlertDialog(title:Text(title),content:TextField(controller:controller,autofocus:true,maxLines:key=='profile_bio'?3:1,decoration:InputDecoration(hintText:title)),actions:[TextButton(onPressed:()=>Navigator.pop(c),child:const Text('Cancel')),FilledButton(onPressed:()=>Navigator.pop(c,controller.text.trim()),child:const Text('Save'))]));
    if(value==null||value.isEmpty)return;
    final prefs=await SharedPreferences.getInstance();await prefs.setString(key,value);
    if(mounted)setState(()=>key=='profile_name'?_name=value:_bio=value);
  }
  Future<void> _pickPhoto() async {
    try { final result=await FilePicker.platform.pickFiles(type:FileType.image,allowMultiple:false); if(result==null||result.files.single.path==null)return; final source=File(result.files.single.path!); final dir=await getApplicationDocumentsDirectory(); final targetDir=Directory(p.join(dir.path,'profile')); if(!await targetDir.exists())await targetDir.create(recursive:true); final target=await source.copy(p.join(targetDir.path,'avatar${p.extension(source.path)}')); final prefs=await SharedPreferences.getInstance(); await prefs.setString('profile_photo',target.path); if(mounted)setState(()=>_photo=target.path); } catch(e) { if(mounted)_message(context,'Could not update profile picture: $e'); }
  }
  Future<void> _goal() async { final c=TextEditingController(text:'$_dailyGoal'); final value=await showDialog<int>(context:context,builder:(ctx)=>AlertDialog(title:const Text('Daily reading goal'),content:TextField(controller:c,keyboardType:TextInputType.number,decoration:const InputDecoration(suffixText:'minutes')),actions:[TextButton(onPressed:()=>Navigator.pop(ctx),child:const Text('Cancel')),FilledButton(onPressed:()=>Navigator.pop(ctx,int.tryParse(c.text)),child:const Text('Save'))])); if(value==null||value<1||value>1440)return; final prefs=await SharedPreferences.getInstance();await prefs.setInt('daily_reading_goal',value);if(mounted)setState(()=>_dailyGoal=value); }
  @override Widget build(BuildContext context) => ListView(padding:const EdgeInsets.fromLTRB(20,22,20,34),children:[Text('YOUR SPACE',style:TextStyle(color:Theme.of(context).colorScheme.primary,fontSize:10,letterSpacing:2,fontWeight:FontWeight.bold)),const SizedBox(height:7),const Text('Profile',style:TextStyle(fontSize:29,fontWeight:FontWeight.w800)),const SizedBox(height:18),Container(padding:const EdgeInsets.all(17),decoration:BoxDecoration(borderRadius:BorderRadius.circular(22),gradient:const LinearGradient(colors:[Color(0xFF40365F),Color(0xFF1B1D2B)])),child:Row(children:[GestureDetector(onTap:_pickPhoto,child:Stack(children:[CircleAvatar(radius:29,backgroundColor:const Color(0xFFB9A6E9),backgroundImage:_photo!=null&&File(_photo!).existsSync()?FileImage(File(_photo!)):null,child:_photo==null?const Icon(Icons.person,color:Color(0xFF27213A),size:30):null),const Positioned(right:-2,bottom:-2,child:CircleAvatar(radius:11,backgroundColor:Colors.white,child:Icon(Icons.camera_alt,size:12,color:Color(0xFF40365F))))])),const SizedBox(width:14),Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text(_loaded?_name:'Loading profile…',style:const TextStyle(color:Colors.white,fontSize:17,fontWeight:FontWeight.bold)),Text(_bio,style:const TextStyle(color:Colors.white70,fontSize:11),maxLines:2,overflow:TextOverflow.ellipsis)])),IconButton(onPressed:()=>_edit('profile_name','Display name',_name),icon:const Icon(Icons.edit,color:Colors.white70))])),const SizedBox(height:9),Row(children:[Expanded(child:OutlinedButton.icon(onPressed:_pickPhoto,icon:const Icon(Icons.photo_camera_back_outlined),label:const Text('Change picture'))),const SizedBox(width:8),Expanded(child:OutlinedButton.icon(onPressed:()=>_edit('profile_bio','About you',_bio),icon:const Icon(Icons.edit_note),label:const Text('Edit bio')))]),const SizedBox(height:24),const Text('APPEARANCE',style:TextStyle(fontWeight:FontWeight.bold,letterSpacing:1.3,fontSize:11)),const SizedBox(height:10),SegmentedButton<ThemeMode>(segments:const [ButtonSegment(value:ThemeMode.light,label:Text('Light'),icon:Icon(Icons.light_mode_outlined)),ButtonSegment(value:ThemeMode.dark,label:Text('Dark'),icon:Icon(Icons.dark_mode_outlined)),ButtonSegment(value:ThemeMode.system,label:Text('System'),icon:Icon(Icons.phone_android))],selected:{widget.themeMode},onSelectionChanged:(v)=>widget.onThemeChanged(v.first)),const SizedBox(height:24),const Text('READING PREFERENCES',style:TextStyle(fontWeight:FontWeight.bold,letterSpacing:1.3,fontSize:11)),Card(child:ListTile(leading:const Icon(Icons.flag_outlined),title:const Text('Daily reading goal'),subtitle:Text('$_dailyGoal minutes per day'),trailing:const Icon(Icons.chevron_right),onTap:_goal)),Card(child:SwitchListTile(value:_compactReader,onChanged:(v)async{final p=await SharedPreferences.getInstance();await p.setBool('compact_reader',v);setState(()=>_compactReader=v);},secondary:const Icon(Icons.text_fields),title:const Text('Compact reading layout'),subtitle:const Text('Prefer a tighter reading layout'))),const SizedBox(height:18),const Text('APP PREFERENCES',style:TextStyle(fontWeight:FontWeight.bold,letterSpacing:1.3,fontSize:11)),Card(child:SwitchListTile(value:_notifications,onChanged:(v)async{final p=await SharedPreferences.getInstance();await p.setBool('notifications_enabled',v);setState(()=>_notifications=v);},secondary:const Icon(Icons.notifications_outlined),title:const Text('Notifications'),subtitle:const Text('Reading reminders and app updates'))),Card(child:ListTile(leading:const Icon(Icons.storage_outlined),title:const Text('Storage and downloads'),subtitle:const Text('Manage imported books in Library'),trailing:const Icon(Icons.chevron_right),onTap:()=>_message(context,'Open Library to manage imported books and offline files.'))),Card(child:ListTile(leading:const Icon(Icons.bookmark_outline),title:const Text('Bookmarks and vocabulary'),subtitle:const Text('Your saved reading references'),trailing:const Icon(Icons.chevron_right),onTap:()=>_message(context,'Saved vocabulary and bookmark management will be added to the next reader milestone.'))),Card(child:ListTile(leading:const Icon(Icons.info_outline),title:const Text('About StoryVerse'),subtitle:const Text('Version 0.1.0 · Reading and writing studio'),onTap:()=>showAboutDialog(context:context,applicationName:'StoryVerse',applicationVersion:'0.1.0',applicationLegalese:'A reading and writing studio.'))),]);
}

class StoryVerseIntro extends StatefulWidget { final VoidCallback onFinished; const StoryVerseIntro({super.key, required this.onFinished}); @override State<StoryVerseIntro> createState()=>_StoryVerseIntroState(); }
class _StoryVerseIntroState extends State<StoryVerseIntro> with SingleTickerProviderStateMixin {
 late final AnimationController _controller;
 @override void initState(){super.initState();_controller=AnimationController(vsync:this,duration:const Duration(milliseconds:2600))..forward().then((_){if(mounted) widget.onFinished();});}
 @override void dispose(){_controller.dispose();super.dispose();}
 @override Widget build(BuildContext context){return Scaffold(backgroundColor:const Color(0xFF10111A),body:AnimatedBuilder(animation:_controller,builder:(context,child){final t=Curves.easeOutCubic.transform(_controller.value);return Stack(children:[Positioned.fill(child:DecoratedBox(decoration:BoxDecoration(gradient:RadialGradient(center:const Alignment(0,-.25),radius:1.1,colors:[const Color(0xFF28243C),const Color(0xFF10111A)])))),Center(child:SizedBox(width:300,height:390,child:Stack(alignment:Alignment.center,children:[for(int i=0;i<12;i++) _IntroCover(index:i,progress:t)]))),Positioned(left:24,right:24,bottom:76,child:Column(children:[Text('STORYVERSE',style:TextStyle(color:Colors.white.withValues(alpha:t),fontSize:12,letterSpacing:5,fontWeight:FontWeight.w800)),const SizedBox(height:12),Text('Every cover opens a universe.',textAlign:TextAlign.center,style:TextStyle(color:Colors.white.withValues(alpha:t*.88),fontSize:20,fontWeight:FontWeight.w600))])),Positioned(right:18,top:48,child:TextButton(onPressed:widget.onFinished,child:const Text('SKIP',style:TextStyle(color:Colors.white70,letterSpacing:1.5,fontSize:10))))]);}));}
}
class _IntroCover extends StatelessWidget {
  final int index;
  final double progress;
  const _IntroCover({required this.index, required this.progress});

  @override
  Widget build(BuildContext context) {
    const palettes = [
      [Color(0xFFCF8A55), Color(0xFF55333B)],
      [Color(0xFF547E8B), Color(0xFF202B4A)],
      [Color(0xFFB7A36E), Color(0xFF4B4032)],
      [Color(0xFF9B6484), Color(0xFF3E2B4D)],
      [Color(0xFF6E8A65), Color(0xFF273C35)],
      [Color(0xFFBE6550), Color(0xFF512B37)],
    ];
    const titles = ['PRIDE &\nPREJUDICE', 'FRANKENSTEIN', 'ALICE IN\nWONDERLAND', 'DRACULA', 'MOBY-DICK', 'SHERLOCK\nHOLMES'];
    const covers = ['https://www.gutenberg.org/cache/epub/1342/pg1342.cover.medium.jpg','https://www.gutenberg.org/cache/epub/84/pg84.cover.medium.jpg','https://www.gutenberg.org/cache/epub/11/pg11.cover.medium.jpg','https://www.gutenberg.org/cache/epub/345/pg345.cover.medium.jpg','https://www.gutenberg.org/cache/epub/2701/pg2701.cover.medium.jpg','https://www.gutenberg.org/cache/epub/1661/pg1661.cover.medium.jpg'];
    final angle = (index % 4 - 1.5) * .10 * (1 - progress);
    final dx = math.cos(index * 2.4) * 90 * (1 - progress) + ((index % 3) - 1) * 18;
    final dy = math.sin(index * 1.8) * 115 * (1 - progress);
    return Transform.translate(
      offset: Offset(dx, dy),
      child: Transform.rotate(
        angle: angle,
        child: Transform.scale(
          scale: .72 + progress * .30,
          child: Opacity(
            opacity: (.55 + progress * .45).clamp(0.0, 1.0).toDouble(),
            child: SizedBox(
              width: 76,
              height: 112,
              child: DecoratedBox(
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(7),
                  gradient: LinearGradient(colors: palettes[index % palettes.length]),
                  boxShadow: [BoxShadow(color: Colors.black.withValues(alpha: .35), blurRadius: 14, offset: const Offset(4, 7))],
                ),
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(7),
                  child: Stack(fit: StackFit.expand, children: [
                    Image.network(covers[index % covers.length], fit: BoxFit.cover,
                      errorBuilder: (_, __, ___) => DecoratedBox(decoration: BoxDecoration(gradient: LinearGradient(colors: palettes[index % palettes.length])))),
                    DecoratedBox(decoration: BoxDecoration(gradient: LinearGradient(begin: Alignment.topCenter, end: Alignment.bottomCenter, colors: [Colors.black.withValues(alpha: .08), Colors.black.withValues(alpha: .72)]))),
                    Padding(padding: const EdgeInsets.all(6), child: Column(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                      Icon(Icons.auto_stories_rounded, color: Colors.white.withValues(alpha: .8), size: 15),
                      Text(titles[index % titles.length], textAlign: TextAlign.center, style: const TextStyle(color: Colors.white, fontSize: 7, fontWeight: FontWeight.w900, letterSpacing: .4)),
                      Container(height: 2, width: 22, color: Colors.white70),
                    ])),
                  ]),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class _Book {final String title,author,category,description;final List<Color> colors;final String mark;final double rating;const _Book(this.title,this.author,this.category,this.description,this.colors,this.mark,this.rating);}
const _books=[
 _Book('The Midnight Library','Matt Haig','Fantasy','Between life and death there is a library, and within that library, the shelves go on forever. Every book offers a chance to try another life.',[Color(0xFF5C6E89),Color(0xFF1B2438)],'M',4.8),
 _Book('The Silent Patient','Alex Michaelides','Thriller','A painter’s silence becomes the centre of a mystery that refuses to stay buried.',[Color(0xFF4E6C72),Color(0xFF172B36)],'S',4.7),
 _Book('Dune','Frank Herbert','Science fiction','On the desert planet Arrakis, a young heir is drawn into a struggle that will change an empire.',[Color(0xFFC17A45),Color(0xFF4D3026)],'D',4.9),
 _Book('Pride & Prejudice','Jane Austen','Classic','A witty and enduring story of first impressions, family, pride and affection.',[Color(0xFF879477),Color(0xFF344438)],'P',4.6),
 _Book('The Last House','M. R. Vale','Thriller','A house at the edge of town keeps the secrets of everyone who has ever entered.',[Color(0xFF72516C),Color(0xFF28243D)],'H',4.5),
 _Book('Beyond the Blue','N. A. Rivers','Novel','A journey across unfamiliar places becomes a journey toward home.',[Color(0xFF4C7890),Color(0xFF1D3448)],'B',4.4),
];
class _Cover extends StatelessWidget {final _Book b;const _Cover({required this.b});@override Widget build(BuildContext context)=>Container(width:double.infinity,decoration:BoxDecoration(borderRadius:BorderRadius.circular(13),gradient:LinearGradient(begin:Alignment.topLeft,end:Alignment.bottomRight,colors:b.colors),boxShadow:[BoxShadow(color:b.colors.first.withValues(alpha:.22),blurRadius:12,offset:const Offset(0,6))]),child:Stack(children:[Positioned(right:-16,top:-20,child:Container(width:100,height:100,decoration:BoxDecoration(shape:BoxShape.circle,color:Colors.white.withValues(alpha:.08)))),Center(child:Text(b.mark,style:const TextStyle(color:Colors.white,fontSize:65,fontFamily:'serif',fontWeight:FontWeight.w300))),Positioned(left:9,right:9,bottom:12,child:Column(children:[Container(width:28,height:1,color:Colors.white70),const SizedBox(height:7),Text(b.title.toUpperCase(),textAlign:TextAlign.center,maxLines:2,style:const TextStyle(color:Colors.white,fontSize:9,fontWeight:FontWeight.w900,letterSpacing:1.1))]))]));}
class _HorizontalBooks extends StatelessWidget {final List<_Book> items;const _HorizontalBooks({required this.items});@override Widget build(BuildContext context)=>SizedBox(height:190,child:ListView.separated(padding:const EdgeInsets.symmetric(horizontal:20),scrollDirection:Axis.horizontal,itemCount:items.length,separatorBuilder:(_,__)=>const SizedBox(width:13),itemBuilder:(context,i)=>SizedBox(width:112,child:GestureDetector(onTap:()=>_openBook(context,items[i]),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Expanded(child:_Cover(b:items[i])),const SizedBox(height:7),Text(items[i].title,maxLines:1,overflow:TextOverflow.ellipsis,style:const TextStyle(fontSize:11,fontWeight:FontWeight.w700)),Text(items[i].author,maxLines:1,overflow:TextOverflow.ellipsis,style:TextStyle(fontSize:9,color:Theme.of(context).colorScheme.onSurfaceVariant))])))));}
class _ShelfHeading extends StatelessWidget {final String title,subtitle,action;final VoidCallback onTap;const _ShelfHeading({required this.title,required this.subtitle,required this.action,required this.onTap});@override Widget build(BuildContext context)=>Padding(padding:const EdgeInsets.fromLTRB(20,20,16,12),child:Row(children:[Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text(title,style:const TextStyle(fontSize:17,fontWeight:FontWeight.w800)),const SizedBox(height:2),Text(subtitle,style:TextStyle(fontSize:10,color:Theme.of(context).colorScheme.onSurfaceVariant))])),TextButton(onPressed:onTap,child:Text(action,style:const TextStyle(fontSize:11)))]));}
class _CategoryBanner extends StatelessWidget {final String title,count;final List<Color> colors;final IconData icon;final VoidCallback onTap;const _CategoryBanner({required this.title,required this.count,required this.colors,required this.icon,required this.onTap});@override Widget build(BuildContext context)=>Padding(padding:const EdgeInsets.fromLTRB(20,19,20,0),child:InkWell(onTap:onTap,borderRadius:BorderRadius.circular(19),child:Container(height:91,padding:const EdgeInsets.symmetric(horizontal:17),decoration:BoxDecoration(borderRadius:BorderRadius.circular(19),gradient:LinearGradient(colors:colors)),child:Row(children:[Container(width:48,height:48,decoration:BoxDecoration(color:Colors.white.withValues(alpha:.12),borderRadius:BorderRadius.circular(15)),child:Icon(icon,color:Colors.white,size:25)),const SizedBox(width:14),Expanded(child:Column(mainAxisAlignment:MainAxisAlignment.center,crossAxisAlignment:CrossAxisAlignment.start,children:[Text(title,style:const TextStyle(color:Colors.white,fontWeight:FontWeight.w800,fontSize:14)),const SizedBox(height:4),Text(count,style:const TextStyle(color:Colors.white70,fontSize:10),maxLines:2)])),const Icon(Icons.arrow_forward_ios_rounded,color:Colors.white70,size:14)]))));}
class _CircleAction extends StatelessWidget {final IconData icon;final VoidCallback onTap;const _CircleAction({required this.icon,required this.onTap});@override Widget build(BuildContext context)=>IconButton(onPressed:onTap,icon:Icon(icon,size:20),style:IconButton.styleFrom(backgroundColor:Theme.of(context).colorScheme.surfaceContainerHighest.withValues(alpha:.5),fixedSize:const Size(40,40)));}
void _openBook(BuildContext context,_Book b)=>Navigator.push(context,MaterialPageRoute(builder:(_)=>BookDetailScreen(book:b)));
void _message(BuildContext context,String message)=>ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text(message),behavior:SnackBarBehavior.floating));
class BookDetailScreen extends StatelessWidget {final _Book book;const BookDetailScreen({super.key,required this.book});@override Widget build(BuildContext context)=>Scaffold(body:CustomScrollView(slivers:[SliverAppBar(pinned:true,expandedHeight:310,backgroundColor:book.colors.last,leading:IconButton(onPressed:()=>Navigator.pop(context),icon:const Icon(Icons.arrow_back)),flexibleSpace:FlexibleSpaceBar(background:Container(decoration:BoxDecoration(gradient:LinearGradient(begin:Alignment.topLeft,end:Alignment.bottomRight,colors:book.colors)),child:Center(child:SizedBox(width:145,height:220,child:Transform.rotate(angle:-.035,child:_Cover(b:book))))))),SliverPadding(padding:const EdgeInsets.fromLTRB(22,22,22,36),sliver:SliverToBoxAdapter(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text(book.category.toUpperCase(),style:TextStyle(color:Theme.of(context).colorScheme.primary,fontSize:10,letterSpacing:2,fontWeight:FontWeight.bold)),const SizedBox(height:7),Text(book.title,style:const TextStyle(fontSize:27,fontWeight:FontWeight.w800)),Text('by ${book.author}',style:TextStyle(color:Theme.of(context).colorScheme.onSurfaceVariant)),const SizedBox(height:16),Row(children:[_Meta(icon:Icons.star_rounded,value:'${book.rating}'),_Meta(icon:Icons.menu_book_rounded,value:'Novel'),_Meta(icon:Icons.schedule_rounded,value:'6–8 hrs')]),const SizedBox(height:22),const Text('The story',style:TextStyle(fontSize:17,fontWeight:FontWeight.bold)),const SizedBox(height:8),Text(book.description,style:const TextStyle(height:1.7)),const SizedBox(height:25),SizedBox(width:double.infinity,child:FilledButton.icon(onPressed:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>ReaderScreen(book:book))),icon:const Icon(Icons.menu_book_rounded),label:const Text('Start reading'),style:FilledButton.styleFrom(padding:const EdgeInsets.symmetric(vertical:16)))),const SizedBox(height:12),Text('Demo catalogue entry · Full book text is not included.',style:TextStyle(fontSize:10,color:Theme.of(context).colorScheme.onSurfaceVariant))])))]));}
class _Meta extends StatelessWidget {final IconData icon;final String value;const _Meta({required this.icon,required this.value});@override Widget build(BuildContext context)=>Expanded(child:Row(children:[Icon(icon,size:16,color:Theme.of(context).colorScheme.primary),const SizedBox(width:5),Text(value,style:const TextStyle(fontSize:11,fontWeight:FontWeight.w600))]));}
class ReaderScreen extends StatefulWidget {final _Book book;const ReaderScreen({super.key,required this.book});@override State<ReaderScreen> createState()=>_ReaderScreenState();}
class _ReaderScreenState extends State<ReaderScreen>{double size=18;bool settings=false;@override Widget build(BuildContext context)=>Scaffold(backgroundColor:const Color(0xFFF4EFE6),appBar:AppBar(backgroundColor:const Color(0xFFF4EFE6),foregroundColor:const Color(0xFF27231F),title:Text(widget.book.title,style:const TextStyle(fontSize:14)),actions:[IconButton(onPressed:()=>setState(()=>settings=!settings),icon:const Icon(Icons.tune_rounded)),IconButton(onPressed:()=>_message(context,'Bookmark saved for this demo session.'),icon:const Icon(Icons.bookmark_border))]),body:Column(children:[if(settings)Container(color:const Color(0xFFE8E0D4),padding:const EdgeInsets.all(16),child:Row(children:[const Icon(Icons.text_fields),const SizedBox(width:12),const Text('Text size'),Expanded(child:Slider(min:14,max:28,value:size,onChanged:(v)=>setState(()=>size=v)))])),Expanded(child:ListView(padding:const EdgeInsets.fromLTRB(27,30,27,40),children:[const Text('CHAPTER ONE',style:TextStyle(color:Color(0xFF8D7963),letterSpacing:2,fontSize:10,fontWeight:FontWeight.bold)),const SizedBox(height:20),Text('A Door Between\nPossibilities',style:TextStyle(color:const Color(0xFF29241F),fontSize:size+10,fontWeight:FontWeight.w700,height:1.2,fontFamily:'serif')),const SizedBox(height:28),for(final p in ['There are moments when the world seems to pause. A quiet breath between what was and what might yet be. In that small space, a story begins to unfold.','The room was still, but the pages were alive with possibility. Every line carried the faint echo of another place, another time, another version of a life not yet lived.','Outside, the evening gathered softly against the windows. Inside, the words waited. And for the first time in a long while, the next step did not feel like a mystery to fear, but a door worth opening.'])Padding(padding:const EdgeInsets.only(bottom:22),child:Text(p,style:TextStyle(color:const Color(0xFF39322B),fontSize:size,height:1.85,fontFamily:'serif')))]))]));}

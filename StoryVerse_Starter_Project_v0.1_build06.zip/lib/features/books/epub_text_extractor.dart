import 'dart:convert';
import 'package:archive/archive.dart';
import 'package:xml/xml.dart';

class EpubTextExtractor {
  static String extract(List<int> bytes) {
    final archive = ZipDecoder().decodeBytes(bytes);
    ArchiveFile? find(String name) {
      for (final file in archive.files) {
        if (file.name == name || file.name.endsWith('/$name')) return file;
      }
      return null;
    }
    final container = find('container.xml');
    if (container == null) throw Exception('This EPUB is missing its container.xml file.');
    final containerDoc = XmlDocument.parse(utf8.decode(container.content as List<int>));
    final rootfile = containerDoc.findAllElements('rootfile').firstOrNull;
    final opfPath = rootfile?.getAttribute('full-path');
    if (opfPath == null) throw Exception('This EPUB package could not be read.');
    final opfFile = archive.findFile(opfPath);
    if (opfFile == null) throw Exception('The EPUB package file is missing.');
    final opf = XmlDocument.parse(utf8.decode(opfFile.content as List<int>));
    final base = opfPath.contains('/') ? opfPath.substring(0, opfPath.lastIndexOf('/') + 1) : '';
    final manifest = <String, String>{};
    for (final item in opf.findAllElements('item')) {
      final id = item.getAttribute('id'), href = item.getAttribute('href');
      if (id != null && href != null) manifest[id] = '$base$href';
    }
    final out = StringBuffer();
    for (final itemref in opf.findAllElements('itemref')) {
      final idref = itemref.getAttribute('idref');
      final path = idref == null ? null : manifest[idref];
      if (path == null) continue;
      final chapter = archive.findFile(Uri.decodeFull(path));
      if (chapter == null) continue;
      final html = utf8.decode(chapter.content as List<int>, allowMalformed: true);
      final text = html.replaceAll(RegExp(r'(?is)<(script|style)[^>]*>.*?</\1>'), ' ')
        .replaceAll(RegExp(r'(?i)<br\s*/?>|</p>|</div>|</h[1-6]>|</li>'), '\n\n')
        .replaceAll(RegExp(r'<[^>]+>'), ' ')
        .replaceAll('&nbsp;', ' ').replaceAll('&amp;', '&').replaceAll('&lt;', '<')
        .replaceAll('&gt;', '>').replaceAll('&quot;', '"').replaceAll('&#39;', "'");
      out.writeln(text.replaceAll(RegExp(r'[ \t]+'), ' ').replaceAll(RegExp(r'\n{3,}'), '\n\n').trim());
    }
    final result = out.toString().trim();
    if (result.isEmpty) throw Exception('No readable text was found in this EPUB.');
    return result;
  }
}
